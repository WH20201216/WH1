var myChart = echarts.init(document.getElementById('main'));
var geoCoordMap = {
'p1':[114.368107,30.543083],
'p2':[114.368107,30.543083],
'p3':[114.368107,31.543083],
'p4':[114.368107,32.543083],
'p5':[115.33104,23.120135],
'p6':[118.3342,23.1222135],
'p7':[117.3333,25.1235],
'p8':[126.332288,43.124435],
'p9':[123.334588,13.120035],
'p10':[116.317489,39.998812],
'p11':[120.335688,15.11835],
'p12':[116.317489,39.998812],
'p13':[114.368107,30.543083],
'p14':[114.368107,30.543083],
'p15':[121.510999,31.301528],
'p16':[114.368107,30.543083],
'p17':[116.317489,39.998812],
'p18':[114.368107,30.543083],
'p19':[113.334488,23.125535],
'p20':[116.417489,39.998812],
'p21':[113.331788,23.121235],
'p22':[113.332788,23.121335],
'p23':[113.330188,23.122135],
'p24':[114.368107,30.543083],
'p25':[116.317489,39.998812],
'p26':[114.368107,30.543083],
'p27':[121.510999,31.301528],
'p28':[116.317489,39.998812],
'p29':[113.334588,23.120035],
'p30':[113.333288,23.119935],
'p31':[116.317489,39.998812],
'p32':[121.510999,31.301528],
'p33':[113.330188,23.121935],
'p34':[114.368107,30.543083],
'p35':[116.717489,39.998812],
'p36':[114.368107,30.543083],
'p37':[121.510999,31.301528],
'p38':[113.633388,23.324435],
'p39':[121.310999,31.501528],
'p40':[116.317489,39.998812],
};
var value = [
{name:'p1',value:100},
{name:'p2',value:120},
{name:'p3',value:130},
{name:'p4',value:122},
{name:'p5',value:144},
{name:'p6',value:100},
{name:'p7',value:156},
{name:'p8',value:199},
{name:'p9',value:122},
{name:'p10',value:100},
{name:'p11',value:140},
{name:'p12',value:140},
{name:'p13',value:143},
{name:'p14',value:199},
{name:'p15',value:111},
{name:'p16',value:133},
{name:'p17',value:155},
{name:'p18',value:135},
{name:'p19',value:210},
{name:'p20',value:229},
{name:'p21',value:100},
{name:'p22',value:120},
{name:'p23',value:130},
{name:'p24',value:122},
{name:'p25',value:144},
{name:'p26',value:100},
{name:'p27',value:156},
{name:'p28',value:199},
{name:'p29',value:122},
{name:'p30',value:100},
{name:'p31',value:100},
{name:'p32',value:120},
{name:'p33',value:130},
{name:'p34',value:122},
{name:'p35',value:144},
{name:'p36',value:100},
{name:'p37',value:156},
{name:'p38',value:199},
{name:'p39',value:122},
{name:'p40',value:100}
];

var convertData = function (data,n) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord = geoCoordMap[data[i].name];
        if (geoCoord) {
            res.push(geoCoord.concat(data[i].value+ (Math.random()-0.5)*n ));
        }
    }
    return res;
};

var option = {
    baseOption: {
        title:{
            text: "校友分布热点图-",
            subtext: "数据模拟,仅为测试",
            left: 'center',
            top: 20,
            textStyle:{
                color: 'red',
                fontSize: 20
            },
            subtextStyle:{
                color: 'white',
                fontSize: 16
            }
        },
        timeline: {
            autoPlay:true,
            data: ["2009","2010","2011","2012","2013"],
            axisType: 'category',
            padding: [5,5,5,5],
            playInterval:2000,
            lineStyle:{color:'white'},
            label:{
                normal:{
                    textStyle:{
                        color: 'white',
                        fontSize: 13
                    }
                }
            }
        },
        bmap: {
        center: [113.65,34.76],
        zoom: 5,
        roam: true,
        /*mapStyle: {
                       styleJson: [
          {
                    'featureType': 'land',     //调整土地颜色
                    'elementType': 'geometry',
                    'stylers': {
                              'color': '#081734'
                    }
          },
          {
                    'featureType': 'building',   //调整建筑物颜色
                    'elementType': 'geometry',
                    'stylers': {
                              'color': '#04406F'
                    }
          },
         {
                    'featureType': 'building',   //调整建筑物标签是否可视
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'highway',     //调整高速道路颜色
                    'elementType': 'geometry',
                    'stylers': {
                    'color': '#015B99'
                    }
          },
          {
                    'featureType': 'highway',    //调整高速名字是否可视
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'arterial',   //调整一些干道颜色
                    'elementType': 'geometry',
                    'stylers': {
                    'color':'#003051'
                    }
          },
          {
                    'featureType': 'arterial',
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'green',
                    'elementType': 'geometry',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'water',
                    'elementType': 'geometry',
                    'stylers': {
                              'color': '#044161'
                    }
          },
          {
                    'featureType': 'subway',    //调整地铁颜色
                    'elementType': 'geometry.stroke',
                    'stylers': {
                    'color': '#003051'
                    }
          },
          {
                    'featureType': 'subway',
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'railway',
                    'elementType': 'geometry',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'railway',
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'all',     //调整所有的标签的边缘颜色
                    'elementType': 'labels.text.stroke',
                    'stylers': {
                              'color': '#313131'
                    }
          },
          {
                    'featureType': 'all',     //调整所有标签的填充颜色
                    'elementType': 'labels.text.fill',
                    'stylers': {
                              'color': '#FFFFFF'
                    }
          },
          {
                    'featureType': 'manmade',   
                    'elementType': 'geometry',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'manmade',
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'local',
                    'elementType': 'geometry',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'local',
                    'elementType': 'labels',
                    'stylers': {
                    'visibility': 'off'
                    }
          },
          {
                    'featureType': 'subway',
                    'elementType': 'geometry',
                    'stylers': {
                              'lightness': -65
                    }
          },
          {
                    'featureType': 'railway',
                    'elementType': 'all',
                    'stylers': {
                              'lightness': -40
                    }
          },
          {
                    'featureType': 'boundary',
                    'elementType': 'geometry',
                    'stylers': {
                              'color': '#8b8787',
                              'weight': '1',
                              'lightness': -29
                    }
          }]
		}*/
        },
		
        visualMap: {
           min: 0,
           max: 500,
           splitNumber: 5,
           inRange: {
               color: ['blue', 'green', 'yellow', 'red']
           },
           textStyle: {
               color: '#fff'
           },
           bottom: 30
        },
        series: [{
            type: 'heatmap',
            mapType: 'china',
            coordinateSystem: 'bmap',
            blurSize:30
        }]
    },
    options: [
        {
            series:[{
                data : convertData(value,900)
            }]
        },
        {
            series:[{
                data : convertData(value,700)
            }]
        },
        {
            series:[{
                data : convertData(value,600)
            }]
        },
        {
            series:[{
                data : convertData(value,500)
            }]
        },
        {
            series:[{
                data: convertData(value,300)
            }]
        }
    ]
}
// 使用刚指定的配置项和数据显示图表。
myChart.setOption(option);