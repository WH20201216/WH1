<?php
$start_time=$_POST["start_time"];
$end_time=$_POST["end_time"];
try{
	$servername = "localhost";

	$port=3306;

	$username = "root";

	$password = "Ling0.0";

	$dbname="bus";
//    $sql="select abroad_site from trip where id<10000";
//,alight_flow,sum_flow as 总流量,adname as 所在区,abroad_site as absite_name
    $sql='select ab_lng as lng,ab_lat as lat,count(abroad_site) cnt from (select abroad_site,ab_lng,ab_lat from 404_trip where abroad_datetime between '."'".$start_time."'".' and '."'".$end_time."'".')aa group by abroad_site;';
//	$sql='SELECT abroad_flow,satisfics.lnglat as lnglat FROM trip,satisfics WHERE abroad_datetime BETWEEN '."'".$start_time."'".' AND '."'".$end_time."'".' AND abroad_site=satisfics.sites;';
	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname, $port);

	$conn->set_charset('utf8');

    //结果返回
    $result=$conn->query($sql);

    while($row = $result->fetch_assoc())
    {
        $array[]=$row;
    }

     //进行json编码
    $json=json_encode($array,JSON_UNESCAPED_UNICODE);

	print_r($json);

	if ($conn->connect_error) {
    		die("连接失败: " . $conn->connect_error);
    	}

    $conn->close();

}
catch(Exception $e)
{
	echo '异常信息: ' .$e->getMessage();
}
?>


