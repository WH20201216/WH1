! function(t, e) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = e();
    else if ("function" == typeof define && define.amd) define([], e);
    else {
        var n = e();
        for (var r in n)("object" == typeof exports ? exports : t)[r] = n[r]
    }
}(this, function() {
    return function(t) {
        function e(r) {
            if (n[r]) return n[r].exports;
            var i = n[r] = {
                i: r,
                l: !1,
                exports: {}
            };
            return t[r].call(i.exports, i, i.exports, e), i.l = !0, i.exports
        }
        var n = {};
        return e.m = t, e.c = n, e.i = function(t) {
            return t
        }, e.d = function(t, n, r) {
            e.o(t, n) || Object.defineProperty(t, n, {
                configurable: !1,
                enumerable: !0,
                get: r
            })
        }, e.n = function(t) {
            var n = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return e.d(n, "a", n), n
        }, e.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, e.p = "/asset/", e(e.s = 244)
    }([
        function(t, e, n) {
            "use strict";

            function r(t) {
                if (t.getBoundingClientRect) return t.getBoundingClientRect();
                if ("BODY" !== t.tagName) {
                    var e = t.offsetTop,
                        n = t.offsetLeft,
                        i = r(t.parentElement);
                    return {
                        top: e + i.top,
                        left: n + i.left
                    }
                }
                return {
                    top: t.offsetTop,
                    left: t.offsetLeft
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.lo = void 0;
            var i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(130)),
                o = function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                    return e.default = t, e
                }(n(3)),
                a = a || {
                    ELEMENT_NODE: 1
                },
                u = Object.prototype.toString,
                c = i.default.noConflict();
            c.mixin({
                createElement: function(t, e, n) {
                    var r = document.createElement(t);
                    for (var i in e) r[i] = e[i];
                    for (var o in n) r.style[o] = n[o];
                    return r
                },
                getElement: function(t) {
                    if (t) {
                        var e = t;
                        return c.isString(e) && (e = document.getElementById(e)), e && e.nodeType === a.ELEMENT_NODE ? e : void 0
                    }
                },
                getPixelRatio: function() {
                    return window.devicePixelRatio || 1
                },
                median: function(t, e) {
                    var n = t.length,
                        r = c.isFn(e) ? e : c.isString(e) ? function(t) {
                            return t[e]
                        } : function(t) {
                            return t
                        };
                    if (n > 0) {
                        if (n % 2 == 0) {
                            var i = n / 2;
                            return (r(t[i - 1]) + r(t[i])) / 2
                        }
                        return r(t[(n - 1) / 2])
                    }
                },
                convert2Array: function(t) {
                    return Array.isArray(t) ? t : [t]
                },
                extent: o.extent,
                offset: function(t) {
                    return r(t)
                },
                assign: function(t) {
                    for (var e = arguments.length, n = Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                    for (var i = 0, o = n.length; i < o; i++) {
                        var a = n[i];
                        for (var u in a) a.hasOwnProperty(u) && (t[u] = a[u])
                    }
                    return t
                },
                callFn: function(t, e) {
                    if (c.isFn(t)) {
                        for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                        return t.apply(e, r)
                    }
                },
                isImg: function(t) {
                    return "[object HTMLImageElement]" === c.toStr(t)
                },
                isCanvas: function(t) {
                    return "[object HTMLCanvasElement]" === c.toStr(t)
                },
                isFn: function(t) {
                    return "function" == typeof t
                },
                isNul: function(t) {
                    return void 0 == t
                },
                isStr: function(t) {
                    return "string" == typeof t
                },
                toStr: function(t) {
                    return u.call(t)
                },
                nativeArrCheck: function(t) {
                    return Array.isArray(t)
                },
                forMap: function(t, e, n) {
                    for (var r in t)
                        if (t.hasOwnProperty(r)) {
                            var i = t[r];
                            e.call(n || this, i, r, t)
                        }
                },
                is2DimArr: function(t) {
                    return c.isArray(t[0]) && !c.isArray(t[0][0])
                },
                log: function() {
                    console && console.log
                },
                time: function() {
                    console && console.time
                },
                timeEnd: function() {
                    console && console.timeEnd
                }
            });
            e.lo = c;
            e.default = c
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Color = e.hexHelper = e.hexbin = e.gridbin = e.Scale = e.amapLoader = void 0;
            var i = n(135);
            Object.keys(i).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return i[t]
                    }
                })
            });
            var o = n(132);
            Object.keys(o).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return o[t]
                    }
                })
            });
            var a = n(28);
            Object.keys(a).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return a[t]
                    }
                })
            });
            var u = n(55);
            Object.keys(u).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return u[t]
                    }
                })
            });
            var c = n(56);
            Object.keys(c).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return c[t]
                    }
                })
            });
            var f = n(136);
            Object.keys(f).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return f[t]
                    }
                })
            });
            var s = n(137);
            Object.keys(s).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return s[t]
                    }
                })
            });
            var l = n(138);
            Object.keys(l).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return l[t]
                    }
                })
            });
            var h = r(n(133)),
                p = r(n(57)),
                d = r(n(51)),
                v = r(n(53)),
                y = r(n(52)),
                _ = r(n(54));
            e.amapLoader = h.default, e.Scale = p.default, e.gridbin = d.default, e.hexbin = v.default, e.hexHelper = y.default, e.Color = _.default
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n, a) {
                function u(e) {
                    return t(e = new Date(+e)), e
                }
                return u.floor = u, u.ceil = function(n) {
                    return t(n = new Date(n - 1)), e(n, 1), t(n), n
                }, u.round = function(t) {
                    var e = u(t),
                        n = u.ceil(t);
                    return t - e < n - t ? e : n
                }, u.offset = function(t, n) {
                    return e(t = new Date(+t), null == n ? 1 : Math.floor(n)), t
                }, u.range = function(n, r, i) {
                    var o, a = [];
                    if (n = u.ceil(n), i = null == i ? 1 : Math.floor(i), !(n < r && i > 0)) return a;
                    do {
                        a.push(o = new Date(+n)), e(n, i), t(n)
                    } while (o < n && n < r);
                    return a
                }, u.filter = function(n) {
                    return r(function(e) {
                        if (e >= e)
                            for (; t(e), !n(e);) e.setTime(e - 1)
                    }, function(t, r) {
                        if (t >= t)
                            if (r < 0)
                                for (; ++r <= 0;)
                                    for (; e(t, -1), !n(t););
                            else
                                for (; --r >= 0;)
                                    for (; e(t, 1), !n(t););
                    })
                }, n && (u.count = function(e, r) {
                    return i.setTime(+e), o.setTime(+r), t(i), t(o), Math.floor(n(i, o))
                }, u.every = function(t) {
                    return t = Math.floor(t), isFinite(t) && t > 0 ? t > 1 ? u.filter(a ? function(e) {
                        return a(e) % t == 0
                    } : function(e) {
                        return u.count(0, e) % t == 0
                    }) : u : null
                }), u
            }
            e.a = r;
            var i = new Date,
                o = new Date
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(68);
            n.d(e, "bisect", function() {
                return r.a
            }), n.d(e, "bisectRight", function() {
                return r.b
            }), n.d(e, "bisectLeft", function() {
                return r.c
            });
            var i = n(13);
            n.d(e, "ascending", function() {
                return i.a
            });
            var o = n(69);
            n.d(e, "bisector", function() {
                return o.a
            });
            var a = n(156);
            n.d(e, "cross", function() {
                return a.a
            });
            var u = n(157);
            n.d(e, "descending", function() {
                return u.a
            });
            var c = n(70);
            n.d(e, "deviation", function() {
                return c.a
            });
            var f = n(71);
            n.d(e, "extent", function() {
                return f.a
            });
            var s = n(158);
            n.d(e, "histogram", function() {
                return s.a
            });
            var l = n(168);
            n.d(e, "thresholdFreedmanDiaconis", function() {
                return l.a
            });
            var h = n(169);
            n.d(e, "thresholdScott", function() {
                return h.a
            });
            var p = n(75);
            n.d(e, "thresholdSturges", function() {
                return p.a
            });
            var d = n(160);
            n.d(e, "max", function() {
                return d.a
            });
            var v = n(161);
            n.d(e, "mean", function() {
                return v.a
            });
            var y = n(162);
            n.d(e, "median", function() {
                return y.a
            });
            var _ = n(163);
            n.d(e, "merge", function() {
                return _.a
            });
            var g = n(72);
            n.d(e, "min", function() {
                return g.a
            });
            var b = n(73);
            n.d(e, "pairs", function() {
                return b.a
            });
            var m = n(164);
            n.d(e, "permute", function() {
                return m.a
            });
            var w = n(30);
            n.d(e, "quantile", function() {
                return w.a
            });
            var O = n(74);
            n.d(e, "range", function() {
                return O.a
            });
            var x = n(165);
            n.d(e, "scan", function() {
                return x.a
            });
            var M = n(166);
            n.d(e, "shuffle", function() {
                return M.a
            });
            var j = n(167);
            n.d(e, "sum", function() {
                return j.a
            });
            var k = n(76);
            n.d(e, "ticks", function() {
                return k.a
            }), n.d(e, "tickIncrement", function() {
                return k.b
            }), n.d(e, "tickStep", function() {
                return k.c
            });
            var P = n(77);
            n.d(e, "transpose", function() {
                return P.a
            });
            var E = n(78);
            n.d(e, "variance", function() {
                return E.a
            });
            var A = n(170);
            n.d(e, "zip", function() {
                return A.a
            })
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            e.Event = {
                ADD: "add",
                RM: "remove",
                LOAD: "load",
                MAP_LOAD: "mapload",
                LEGEND_UPDATE: "legendupdate",
                ADD_LAYER: "layeradd",
                RM_LAYER: "layerremove",
                CLICK: "click",
                DB_CLICK: "dblclick",
                MOUSE_MOVE: "mousemove",
                MOUSE_WHEEL: "mousewheel",
                MOUSE_ENTER: "mouseenter",
                MOUSE_LEAVE: "mouseleave",
                MOUSE_OVER: "mouseover",
                MOUSE_OUT: "mouseout",
                CONTEXT_MENU: "contextmenu",
                TOUCH_START: "touchstart",
                TOUCH_MOVE: "touchmove",
                TOUCH_END: "touchend",
                TOUCH_CANCEL: "touchcancel",
                MOVE_START: "movestart",
                MOVE: "move",
                MOVE_END: "moveend",
                ZOOM_CHANGE: "zoomchange",
                ZOOM: "zoom",
                ZOOM_END: "zoomend",
                MAP_MOVE: "mapmove",
                DRAG_START: "dragstart",
                DRAG_ING: "dragging",
                DRAG_END: "dragend",
                RESIZE: "resize",
                RENDER: "render"
            }, e.Defaults = {
                OL_TYPE: "point",
                SCALE: "scaleLinear",
                size: [1, 10]
            }, e.ScaleMap = {
                continuous: ["linear", "power", "sqrt", "time", "utc", "log", "identity", "sequential"],
                ordinal: ["ordinal", "band", "point", "color", "category"],
                scaleOrdinal: ["color", "borderColor"],
                scaleLinear: ["size", "radius", "width", "borderWidth", "opacity", "zIndex", "offsetX", "offsetY"]
            }, e.SupportEvents = "click dblclick contextmenu \n mousemove mouseover mouseout mouseenter mouseleave mousedown mouseup  \n touchstart touchmove touchend touchcancel"
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(105);
            Object.keys(r).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return r[t]
                    }
                })
            });
            var i = n(43);
            Object.keys(i).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return i[t]
                    }
                })
            })
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = n(47);
            Object.defineProperty(e, "OverlayGroup", {
                enumerable: !0,
                get: function() {
                    return r(i).default
                }
            });
            var o = n(24);
            Object.keys(o).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return o[t]
                    }
                })
            });
            var a = n(46);
            Object.keys(a).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return a[t]
                    }
                })
            });
            var u = n(121);
            Object.keys(u).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return u[t]
                    }
                })
            });
            var c = n(120);
            Object.keys(c).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return c[t]
                    }
                })
            });
            var f = n(25);
            Object.defineProperty(e, "MapGroup", {
                enumerable: !0,
                get: function() {
                    return r(f).default
                }
            });
            var s = n(27);
            Object.defineProperty(e, "Overlay", {
                enumerable: !0,
                get: function() {
                    return r(s).default
                }
            });
            var l = n(48);
            Object.keys(l).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return l[t]
                    }
                })
            });
            var h = n(128);
            Object.keys(h).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return h[t]
                    }
                })
            });
            var p = n(49);
            Object.keys(p).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return p[t]
                    }
                })
            });
            var d = n(129);
            Object.keys(d).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return d[t]
                    }
                })
            });
            var v = n(125);
            Object.keys(v).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return v[t]
                    }
                })
            });
            var y = n(126);
            Object.keys(y).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return y[t]
                    }
                })
            });
            var _ = n(124);
            Object.keys(_).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return _[t]
                    }
                })
            });
            var g = n(127);
            Object.keys(g).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return g[t]
                    }
                })
            });
            var b = n(122);
            Object.keys(b).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return b[t]
                    }
                })
            });
            var m = n(26);
            Object.keys(m).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return m[t]
                    }
                })
            });
            var w = n(123);
            Object.keys(w).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return w[t]
                    }
                })
            });
            var O = n(115);
            Object.keys(O).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return O[t]
                    }
                })
            });
            var x = n(116);
            Object.keys(x).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return x[t]
                    }
                })
            });
            var M = n(118);
            Object.keys(M).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return M[t]
                    }
                })
            });
            var j = n(119);
            Object.keys(j).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return j[t]
                    }
                })
            });
            var k = n(117);
            Object.keys(k).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return k[t]
                    }
                })
            })
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "e", function() {
                return r
            }), n.d(e, "d", function() {
                return i
            }), n.d(e, "c", function() {
                return o
            }), n.d(e, "b", function() {
                return a
            }), n.d(e, "a", function() {
                return u
            });
            var r = 1e3,
                i = 6e4,
                o = 36e5,
                a = 864e5,
                u = 6048e5
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t.replace(/^\s+|\s+$/g, "")
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)).default.assign,
                a = -1,
                u = /\s+/,
                c = function() {
                    function t() {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.__events__ = {}, this.__id__ = ++a
                    }
                    return i(t, [{
                        key: "on",
                        value: function(t, e, n) {
                            for (var i = -1, o = (t = r(t).split(u)).length; ++i < o;) {
                                var a = t[i];
                                this._on(a, e, n)
                            }
                            return this
                        }
                    }, {
                        key: "_on",
                        value: function(t, e, n) {
                            var r = this.__events__,
                                i = r[t] = r[t] || [];
                            n === this && (n = void 0);
                            for (var o = -1, a = i; ++o < a;) {
                                var u = i[o],
                                    c = u.fn,
                                    f = u.ctx;
                                if (c === e && f === n) return this
                            }
                            var s = {
                                fn: e,
                                ctx: n
                            };
                            return i.push(s), this
                        }
                    }, {
                        key: "once",
                        value: function(t, e, n) {
                            function r(n) {
                                this.off(t, r), e.call(this, n)
                            }
                            return r.listener = e, this.on(t, r, n)
                        }
                    }, {
                        key: "off",
                        value: function(t, e, n) {
                            if (!t) return this.__events__ = {}, this;
                            for (var i = -1, o = (t = r(t).split(u)).length; ++i < o;) {
                                var a = t[i];
                                a && this._off(a, e, n)
                            }
                            return this
                        }
                    }, {
                        key: "_off",
                        value: function(t, e, n) {
                            if (!t) return this.__events__ = {}, this;
                            var r = this.__events__;
                            if (!e) return delete r[t], this;
                            var i = r[t];
                            if (i)
                                for (var o = i.length; --o >= 0;) {
                                    var a = i[o],
                                        u = a.fn;
                                    a.ctx === n && (u !== e && u !== u.listener || (i.splice(o, 1), u = function() {}))
                                }
                            return this
                        }
                    }, {
                        key: "emit",
                        value: function(t, e, n) {
                            if (!this._listens(t, n)) return this;
                            var r = this.__events__[t],
                                i = o({}, e, {
                                    target: this,
                                    type: t
                                });
                            if (r)
                                for (var a = -1, u = r.length; ++a < u;) {
                                    var c = r[a],
                                        f = c.fn,
                                        s = c.ctx;
                                    f.call(s || this, i)
                                }
                            return n && this._propagateEvent(i), this
                        }
                    }, {
                        key: "addEventParent",
                        value: function(t, e) {
                            return this._eventParents = this._eventParents || {}, this._eventParents[t.__id__] = {
                                target: t,
                                fn: e
                            }, this
                        }
                    }, {
                        key: "removeEventParent",
                        value: function(t) {
                            return this._eventParents && delete this._eventParents[t.__id__], this
                        }
                    }, {
                        key: "_propagateEvent",
                        value: function(t) {
                            var e = this._eventParents;
                            for (var n in e) {
                                var r = e[n],
                                    i = r.target,
                                    a = r.fn,
                                    u = o({}, {
                                        propagatedFrom: t.target
                                    }, t);
                                u = a ? a.call(this, u) : u, i.emit(t.type, u, !0)
                            }
                        }
                    }, {
                        key: "_listens",
                        value: function(t, e) {
                            var n = this.__events__ && this.__events__[t];
                            if (n && n.length) return !0;
                            if (e) {
                                var r = this._eventParents;
                                for (var i in r)
                                    if (r[i].target._listens(t, e)) return !0
                            }
                            return !1
                        }
                    }, {
                        key: "events",
                        get: function() {
                            return this.__events__
                        }
                    }, {
                        key: "id",
                        get: function() {
                            return this.__id__
                        }
                    }]), t
                }();
            e.default = c
        },
        function(t, e, n) {
            "use strict";
            var r = n(32);
            n.d(e, "f", function() {
                return r.h
            }), n.d(e, "e", function() {
                return r.g
            }), n.d(e, "d", function() {
                return r.f
            });
            var i = n(178);
            n.d(e, "c", function() {
                return i.b
            }), n.d(e, "b", function() {
                return i.a
            });
            var o = n(177);
            n.d(e, "a", function() {
                return o.a
            })
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(106)),
                u = r(n(23)),
                c = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_draw",
                        value: function() {
                            var t = this._ctx,
                                e = this._attr,
                                n = e.borderWidth,
                                r = e.borderColor,
                                i = e.color,
                                o = e.fillImage,
                                a = e.shadowBlur,
                                c = e.shadowColor,
                                f = e.shadowOffsetX,
                                s = e.shadowOffsetY,
                                l = e.lineWidth,
                                h = void 0 === l ? n : l,
                                p = e.stroke,
                                d = void 0 === p ? r : p,
                                v = e.opacity,
                                y = e.fill,
                                _ = void 0 === y ? i : y,
                                g = e.fillOpacity,
                                b = void 0 === g ? v : g,
                                m = e.dashArray,
                                w = e.lineDashOffset,
                                O = e.lineCap,
                                x = e.lineJoin,
                                M = e.fillRule,
                                j = e.content,
                                k = e.tX,
                                P = e.tY;
                            return t.shadowOffsetX = f, t.shadowOffsetY = s, t.shadowBlur = a, t.shadowColor = c, _ && (t.fillStyle = _, t.globalAlpha = b, t.fill(M || "nonzero")), d && (t.setLineDash && m && (t.setLineDash(m), t.lineDashOffset = w), t.strokeStyle = d, t.globalAlpha = v, t.lineWidth = h, t.lineCap = O, t.lineJoin = x, t.stroke()), j && t.fillText(j, k, P), o && u.default.fillImage(t, o, this._bounds), this
                        }
                    }, {
                        key: "_renderBounds",
                        value: function() {
                            var t = this._ctx,
                                e = this._bounds;
                            if (e.isValid() && t) {
                                var n = e.valueOf(),
                                    r = i(n, 2),
                                    o = i(r[0], 2),
                                    a = o[0],
                                    u = o[1],
                                    c = i(r[1], 2),
                                    f = c[0] - a,
                                    s = c[1] - u;
                                t.beginPath(), t.rect(a, u, f, s), t.closePath(), t.save(), t.fillStyle = "rgba(0, 238, 0, 0.2)", t.strokeStyle = "rgba(255, 69, 0, 0.3)", t.lineWidth = .5, t.fill(), t.stroke(), t.restore()
                            }
                        }
                    }]), e
                }();
            e.default = c
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return i
            }), n.d(e, "b", function() {
                return o
            });
            var r = Array.prototype,
                i = r.map,
                o = r.slice
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(27)),
                o = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, i["default"]), r(e, [{
                        key: "_initProperties",
                        value: function() {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._obj3D = []
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this.getContainer();
                            return t && t.setBounds(this.getBounds()), this
                        }
                    }, {
                        key: "onAdd",
                        value: function() {
                            this._owner && this.render()
                        }
                    }, {
                        key: "onRemove",
                        value: function() {
                            var t = this;
                            this._obj3D.forEach(function(e) {
                                t._owner._3DLayer.remove(e)
                            }), this._obj3D = []
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = this.getContainer().getMap().getObject3DByContainerPos({
                                x: t,
                                y: e
                            }, [this._owner._3DLayer]);
                            if (!n) return !1;
                            var r = n.object;
                            if (r)
                                for (var i = this._obj3D, o = i.length; --o > -1;) {
                                    var a = i[o];
                                    if (r.id === a.id) return !0
                                }
                            return !1
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function() {}
                    }]), e
                }();
            e.default = o
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(37);
            n.d(e, "interpolate", function() {
                return r.a
            });
            var i = n(88);
            n.d(e, "interpolateArray", function() {
                return i.a
            });
            var o = n(36);
            n.d(e, "interpolateBasis", function() {
                return o.a
            });
            var a = n(89);
            n.d(e, "interpolateBasisClosed", function() {
                return a.a
            });
            var u = n(91);
            n.d(e, "interpolateDate", function() {
                return u.a
            });
            var c = n(20);
            n.d(e, "interpolateNumber", function() {
                return c.a
            });
            var f = n(92);
            n.d(e, "interpolateObject", function() {
                return f.a
            });
            var s = n(203);
            n.d(e, "interpolateRound", function() {
                return s.a
            });
            var l = n(94);
            n.d(e, "interpolateString", function() {
                return l.a
            });
            var h = n(205);
            n.d(e, "interpolateTransformCss", function() {
                return h.a
            }), n.d(e, "interpolateTransformSvg", function() {
                return h.b
            });
            var p = n(207);
            n.d(e, "interpolateZoom", function() {
                return p.a
            });
            var d = n(93);
            n.d(e, "interpolateRgb", function() {
                return d.a
            }), n.d(e, "interpolateRgbBasis", function() {
                return d.b
            }), n.d(e, "interpolateRgbBasisClosed", function() {
                return d.c
            });
            var v = n(200);
            n.d(e, "interpolateHsl", function() {
                return v.a
            }), n.d(e, "interpolateHslLong", function() {
                return v.b
            });
            var y = n(201);
            n.d(e, "interpolateLab", function() {
                return y.a
            });
            var _ = n(199);
            n.d(e, "interpolateHcl", function() {
                return _.a
            }), n.d(e, "interpolateHclLong", function() {
                return _.b
            });
            var g = n(198);
            n.d(e, "interpolateCubehelix", function() {
                return g.b
            }), n.d(e, "interpolateCubehelixLong", function() {
                return g.a
            });
            var b = n(202);
            n.d(e, "quantize", function() {
                return b.a
            })
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return null === t ? NaN : +t
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return function(n) {
                    return t + n * e
                }
            }

            function i(t, e) {
                var i = e - t;
                return i ? r(t, i) : n.i(o.a)(isNaN(t) ? e : t)
            }
            e.b = function(t, e) {
                var i = e - t;
                return i ? r(t, i > 180 || i < -180 ? i - 360 * Math.round(i / 360) : i) : n.i(o.a)(isNaN(t) ? e : t)
            }, e.c = function(t) {
                return 1 == (t = +t) ? i : function(e, r) {
                    return r - e ? function(t, e, n) {
                        return t = Math.pow(t, n), e = Math.pow(e, n) - t, n = 1 / n,
                            function(r) {
                                return Math.pow(t + r * e, n)
                            }
                    }(e, r, t) : n.i(o.a)(isNaN(e) ? r : e)
                }
            }, e.a = i;
            var o = n(90)
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return t.match(/.{6}/g).map(function(t) {
                    return "#" + t
                })
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                var e = t.domain;
                return t.ticks = function(t) {
                    var r = e();
                    return n.i(o.ticks)(r[0], r[r.length - 1], null == t ? 10 : t)
                }, t.tickFormat = function(t, r) {
                    return n.i(c.a)(e(), t, r)
                }, t.nice = function(r) {
                    null == r && (r = 10);
                    var i, a = e(),
                        u = 0,
                        c = a.length - 1,
                        f = a[u],
                        s = a[c];
                    return s < f && (i = f, f = s, s = i, i = u, u = c, c = i), (i = n.i(o.tickIncrement)(f, s, r)) > 0 ? (f = Math.floor(f / i) * i, s = Math.ceil(s / i) * i, i = n.i(o.tickIncrement)(f, s, r)) : i < 0 && (f = Math.ceil(f * i) / i, s = Math.floor(s * i) / i, i = n.i(o.tickIncrement)(f, s, r)), i > 0 ? (a[u] = Math.floor(f / i) * i, a[c] = Math.ceil(s / i) * i, e(a)) : i < 0 && (a[u] = Math.ceil(f * i) / i, a[c] = Math.floor(s * i) / i, e(a)), t
                }, t
            }

            function i() {
                var t = n.i(u.a)(u.b, a.interpolateNumber);
                return t.copy = function() {
                    return n.i(u.c)(t, i())
                }, r(t)
            }
            e.b = r, e.a = i;
            var o = n(3),
                a = n(14),
                u = n(21),
                c = n(223)
        },
        function(t, e, n) {
            "use strict";
            var r = n(35);
            e.a = function(t) {
                return (t = n.i(r.a)(Math.abs(t))) ? t[1] : NaN
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return t = +t, e -= t,
                    function(n) {
                        return t + e * n
                    }
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return (e -= t = +t) ? function(n) {
                    return (n - t) / e
                } : n.i(f.a)(e)
            }

            function i(t, e, n, r) {
                var i = t[0],
                    o = t[1],
                    a = e[0],
                    u = e[1];
                return o < i ? (i = n(o, i), a = r(u, a)) : (i = n(i, o), a = r(a, u)),
                    function(t) {
                        return a(i(t))
                    }
            }

            function o(t, e, r, i) {
                var o = Math.min(t.length, e.length) - 1,
                    u = new Array(o),
                    c = new Array(o),
                    f = -1;
                for (t[o] < t[0] && (t = t.slice().reverse(), e = e.slice().reverse()); ++f < o;) u[f] = r(t[f], t[f + 1]), c[f] = i(e[f], e[f + 1]);
                return function(e) {
                    var r = n.i(a.bisect)(t, e, 1, o) - 1;
                    return c[r](u[r](e))
                }
            }
            e.b = r, e.c = function(t, e) {
                return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp())
            }, e.a = function(t, e) {
                function n() {
                    return f = Math.min(d.length, v.length) > 2 ? o : i, h = p = null, a
                }

                function a(e) {
                    return (h || (h = f(d, v, _ ? function(t) {
                        return function(e, n) {
                            var r = t(e = +e, n = +n);
                            return function(t) {
                                return t <= e ? 0 : t >= n ? 1 : r(t)
                            }
                        }
                    }(t) : t, y)))(+e)
                }
                var f, h, p, d = l,
                    v = l,
                    y = u.interpolate,
                    _ = !1;
                return a.invert = function(t) {
                    return (p || (p = f(v, d, r, _ ? function(t) {
                        return function(e, n) {
                            var r = t(e = +e, n = +n);
                            return function(t) {
                                return t <= 0 ? e : t >= 1 ? n : r(t)
                            }
                        }
                    }(e) : e)))(+t)
                }, a.domain = function(t) {
                    return arguments.length ? (d = c.a.call(t, s.a), n()) : d.slice()
                }, a.range = function(t) {
                    return arguments.length ? (v = c.b.call(t), n()) : v.slice()
                }, a.rangeRound = function(t) {
                    return v = c.b.call(t), y = u.interpolateRound, n()
                }, a.clamp = function(t) {
                    return arguments.length ? (_ = !!t, n()) : _
                }, a.interpolate = function(t) {
                    return arguments.length ? (y = t, n()) : y
                }, n()
            };
            var a = n(3),
                u = n(14),
                c = n(11),
                f = n(38),
                s = n(96),
                l = [0, 1]
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = {};
            r.Coordinate = {
                distance2LineString: function(t, e) {
                    for (var n = 1 / 0, i = 0, o = 1, a = e.length; o < a; i = o, o += 1) n = Math.min(n, r.Coordinate.squaredDistanceToSegment(t, [e[i], e[o]]));
                    return Math.sqrt(n)
                },
                squaredDistanceToSegment: function(t, e) {
                    return this.squaredDistance(t, this.closestOnSegment(t, e))
                },
                squaredDistance: function(t, e) {
                    var n = t[0] - e[0],
                        r = t[1] - e[1];
                    return n * n + r * r
                },
                closestOnSegment: function(t, e) {
                    var n, r, i = t[0],
                        o = t[1],
                        a = e[0],
                        u = e[1],
                        c = a[0],
                        f = a[1],
                        s = u[0],
                        l = u[1],
                        h = s - c,
                        p = l - f,
                        d = 0 === h && 0 === p ? 0 : (h * (i - c) + p * (o - f)) / (h * h + p * p || 0);
                    return d <= 0 ? (n = c, r = f) : d >= 1 ? (n = s, r = l) : (n = c + d * h, r = f + d * p), [n, r]
                },
                isClockwise: function(t) {
                    for (var e, n, r, i = t.length, o = 0, a = t[i - 1], u = a[0], c = a[1], f = 0; f < i; f += 1) o += ((e = (r = t[f])[0]) - u) * ((n = r[1]) + c), u = e, c = n;
                    return o > 0
                },
                containsCoordinate: function(t, e, n) {
                    for (var r, i, o, a, u = t[0], c = t[1], f = !1, s = e.length, l = 0, h = s - 1; l < s; h = l, l += 1) {
                        var p = !1;
                        if (r = e[l][0], i = e[l][1], o = e[h][0], a = e[h][1], r === u && i === c || o === u && a === c) return !!n;
                        if (i < c == a >= c) {
                            var d = (o - r) * (c - i) / (a - i) + r;
                            if (u === d) return !!n;
                            p = u < d
                        }
                        p && (f = !f)
                    }
                    return f
                }
            }, e.default = r
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = r(n(54)),
                o = r(n(0)),
                a = {},
                u = {
                    _tempCav: null,
                    _getTempCav: function() {
                        return this._tempCav || (this._tempCav = this.createCanvas()), this._tempCav
                    },
                    createCanvas: function(t) {
                        var e = t || {},
                            n = e.width,
                            r = e.height,
                            i = document.createElement("canvas");
                        return n && (i.width = n), r && (i.height = r), i
                    },
                    fillImage: function(t, e, n) {
                        var r = e.image,
                            i = e.type,
                            o = void 0 === i ? "stretch" : i,
                            a = e.size,
                            u = e.noClip,
                            c = n || {},
                            f = c.x,
                            s = c.y,
                            l = c.width,
                            h = c.height,
                            p = r.width,
                            d = r.height,
                            v = void 0;
                        switch (o.toLocaleLowerCase()) {
                            case "center":
                                f += (l - p) / 2, s += (h - d) / 2, l = p, h = d;
                                break;
                            case "tile":
                                v = t.createPattern(r, "repeat");
                                break;
                            case "size":
                                var y = a.x,
                                    _ = void 0 === y ? 0 : y,
                                    g = a.y,
                                    b = void 0 === g ? 0 : g,
                                    m = a.width,
                                    w = void 0 === m ? l : m,
                                    O = a.height;
                                l = w, h = void 0 === O ? h : O, f += _, s += b;
                                break;
                            case "auto":
                                l = p, h = d
                        }
                        t.save(), v ? (t.fillStyle = v, t.fill()) : (!u && t.clip(), t.drawImage(r, f, s, l, h)), t.restore()
                    },
                    fillPattern: function(t, e) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "repeat";
                        t.fillStyle = t.createPattern(e, n)
                    },
                    measureText: function(t, e, n) {
                        var r = e.content,
                            i = e.fontFamily,
                            o = e.fontSize,
                            a = (n || {}).size;
                        a = void 0 === a ? void 0 === o ? 12 : o : a, a = parseInt(a), t.font = a + "px " + i, t.textBaseline = "top";
                        return {
                            width: t.measureText(r).width,
                            height: a
                        }
                    },
                    icon2Canvas: function(t, e) {
                        var n = t.content,
                            r = t.fontFamily,
                            o = t.fontSize,
                            a = void 0 === o ? 12 : o,
                            u = (t.color, t.fill, t.stroke, t.opacity),
                            c = t.size,
                            f = this._getTempCav().getContext("2d");
                        c = parseInt(c), f.font = c + "px " + r, f.textBaseline = "top";
                        for (var s = f.measureText(n).width, l = e.length, h = s * l, p = 0, d = 0; h > Math.pow(2, p);) p++;
                        for (var v = Math.pow(2, p); s > Math.pow(2, d);) d++;
                        var y = Math.pow(2, d),
                            _ = this.createCanvas({
                                width: 4 * v,
                                height: 4 * y
                            });
                        c && (a = 4 * c);
                        for (var g = _.getContext("2d"), b = 0; b < l; b++) {
                            var m = e[b];
                            if (g.font = a + "px " + r, g.textBaseline = "top", m.color) {
                                g.shadowBlur = 1, g.shadowColor = m.color;
                                var w = i.default.toNormal(m.color);
                                w[3] = w[3] * u;
                                var O = "rgba(" + w.join(",") + ")";
                                g.fillStyle = O, g.fillText(n, b * s * 4, 0)
                            }
                        }
                        return {
                            cav: _,
                            width: s
                        }
                    },
                    font2Canvas: function(t) {
                        var e = t.content,
                            n = t.fontFamily,
                            r = t.fontSize,
                            i = void 0 === r ? 12 : r,
                            o = t.color,
                            a = (t.fill, t.stroke),
                            u = t.opacity,
                            c = t.size,
                            f = this._getTempCav().getContext("2d"),
                            s = this.measureText(f, t, {
                                size: c
                            }),
                            l = (s.width, s.height, s.canvasSize),
                            h = this.createCanvas({
                                width: l,
                                height: l
                            });
                        c && (i = c);
                        var p = h.getContext("2d");
                        return p.globalAlpha = u, p.font = i + "px " + n, p.textBaseline = "top", o && (p.fillStyle = o, p.fillText(e, 0, 0)), a && (p.strokeStyle = o, p.strokeText(e, 0, 0)), h
                    },
                    source2Image: function(t, e) {
                        var n = this;
                        if (o.default.isStr(t)) {
                            var r = a[t];
                            if (r) e.call(this, r);
                            else {
                                var i = new Image;
                                i.crossOrigin = "anonymous", i.src = t, i.onload = function() {
                                    var r = a[t] = {
                                        image: i,
                                        source: t
                                    };
                                    e.call(n, r)
                                }, i.onerror = function() {
                                    e.call(n)
                                }
                            }
                        } else(o.default.isImg(t) || o.default.isCanvas(t)) && e.call(this, {
                            image: t,
                            source: t.src
                        })
                    },
                    images2Canvas: function(t, e) {
                        for (var n = e.isTexture, r = e.opacity, i = void 0 === r ? 1 : r, o = [], a = 0, u = 0, c = -1, f = t.length; ++c < f;) {
                            var s = t[c] || {},
                                l = s.height,
                                h = void 0 === l ? 0 : l,
                                p = s.width,
                                d = void 0 === p ? 0 : p;
                            u = h > u ? h : u, a += d
                        }
                        var v = a,
                            y = u;
                        if (n) {
                            for (var _ = 0, g = 0; a > Math.pow(2, _);) _++;
                            for (a = Math.pow(2, _); u > Math.pow(2, g);) g++;
                            u = Math.pow(2, g)
                        }
                        var b = this.createCanvas({
                                width: a,
                                height: u
                            }),
                            m = b.getContext("2d");
                        m.globalAlpha = i, c = -1, f = t.length;
                        for (var w = 0; ++c < f;) {
                            var O = t[c],
                                x = O || {},
                                M = x.width,
                                j = (d = void 0 === M ? 0 : M, x.height);
                            h = void 0 === j ? 0 : j;
                            o.push({
                                img: O,
                                startX: w,
                                endX: w + d,
                                startY: 0,
                                endY: h,
                                width: d,
                                height: h
                            }), d && m.drawImage(O, w, 0, d, h), w += d
                        }
                        return {
                            canvas: b,
                            imgAttr: o,
                            imgWidth: v,
                            imgHeight: y
                        }
                    },
                    images2CanvasTexture: function(t, e) {
                        for (var n = e.isTexture, r = e.opacity, i = void 0 === r ? 1 : r, o = {}, a = -1, u = t.length; ++a < u;) {
                            var c = t[a],
                                f = encodeURI(c.source);
                            o[f] || (o[f] = c.image)
                        }
                        var s = 0,
                            l = 0;
                        for (var h in o) {
                            var p = o[h] || {},
                                d = p.height,
                                v = void 0 === d ? 0 : d,
                                y = p.width,
                                _ = void 0 === y ? 0 : y;
                            l = v > l ? v : l, s += _
                        }
                        var g = s,
                            b = l;
                        if (n) {
                            var m = Math.ceil(Math.log2(s));
                            s = Math.pow(2, m);
                            var w = Math.ceil(Math.log2(l));
                            l = Math.pow(2, w)
                        }
                        var O = this.createCanvas({
                                width: s,
                                height: l
                            }),
                            x = O.getContext("2d");
                        x.globalAlpha = i;
                        var M = 0,
                            j = {};
                        for (var k in o) {
                            var P = o[k],
                                E = P || {},
                                A = E.height,
                                L = (v = void 0 === A ? 0 : A, E.width);
                            _ = void 0 === L ? 0 : L;
                            j[k] = {
                                img: P,
                                startX: M,
                                endX: M + _,
                                startY: 0,
                                endY: v,
                                width: _,
                                height: v
                            }, _ && x.drawImage(P, M, 0, _, v), M += _
                        }
                        return {
                            canvas: O,
                            imgAttrMap: j,
                            imgHeight: b,
                            imgWidth: g
                        }
                    },
                    sources2Textures: function(t, e, n) {
                        for (var r = this, i = -1, a = t.length, u = o.default.after(a, function(t) {
                            var i = r.images2CanvasTexture(t, o.default.defaults(n, {
                                isTexture: !0
                            }));
                            e.call(r, i)
                        }), c = []; ++i < a;) {
                            var f = t[i];
                            this.source2Image(f, function(t) {
                                t && c.push(t), u(c)
                            })
                        }
                    }
                };
            e.default = u
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.canvasGroup = e.CanvasGroup = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                a = r(n(46)),
                u = r(n(0)),
                c = n(4),
                f = "loca-visual-layer",
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), i(e, [{
                        key: "_initLayout",
                        value: function(t) {
                            var e = this._owner.getContainer(),
                                n = e.clientWidth,
                                r = e.clientHeight,
                                i = e.getElementsByClassName(f)[0];
                            i || (i = u.default.createElement("div", {
                                className: f
                            }, {
                                position: "relative",
                                width: n + "px",
                                height: r + "px"
                            }), e.appendChild(i));
                            var o = this._domContainer = u.default.createElement("canvas", {
                                width: n,
                                height: r,
                                className: f + "-canvas"
                            }, {
                                position: "absolute",
                                top: 0,
                                left: 0
                            });
                            i.appendChild(o), this._context = o.getContext("2d"), u.default.callFn(t, this)
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            function t(t) {
                                var e = t.target;
                                e._select = t.type === c.Event.MOUSE_ENTER, e._options.selectStyle && !this._owner._inDrag && r()
                            }
                            var n = this;
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_bindEvent", this).call(this);
                            var r = u.default.debounce(function() {
                                n._onRedraw()
                            }, 50);
                            this.on(c.Event.ADD_LAYER, function(e) {
                                e.layer.forEach(function(e) {
                                    e.on(c.Event.MOUSE_ENTER + " " + c.Event.MOUSE_LEAVE, t)
                                })
                            })
                        }
                    }, {
                        key: "beforeAddLayer",
                        value: function(t) {
                            this._options.zLevel && this.clear()
                        }
                    }, {
                        key: "beforeAdd",
                        value: function() {
                            this.clear()
                        }
                    }, {
                        key: "afterRemoveLayer",
                        value: function(t) {
                            this.clear();
                            for (var e = this._overlays, n = -1, r = e.length; ++n < r;) {
                                e[n].onAdd()
                            }
                        }
                    }, {
                        key: "delegateEvent",
                        value: function(t, e) {
                            var n = this._options.eventSupport,
                                r = this._overlays,
                                i = r.length;
                            if (n && this._load && !this._owner._inDrag && i) {
                                var o = e.offsetX,
                                    a = e.offsetY,
                                    f = e.changedTouches;
                                if (f && f.length > 0) {
                                    var s = f[0],
                                        l = u.default.offset(s.target),
                                        h = l.top,
                                        p = l.left;
                                    o = s.pageX - p, a = s.pageY - h
                                }
                                for (var d = void 0; --i > -1;) {
                                    var v = r[i];
                                    if (v.contains(o, a, t)) {
                                        d = v;
                                        break
                                    }
                                }
                                var y = this._lastOverlay;
                                y && y._owner !== this && (y = this._lastOverlay = void 0);
                                var _ = {
                                    originalEvent: e
                                };
                                t === c.Event.MOUSE_MOVE && y !== d && (y && y.emit(c.Event.MOUSE_LEAVE, _, !0).emit(c.Event.MOUSE_OUT, _), d && d.emit(c.Event.MOUSE_ENTER, _, !0).emit(c.Event.MOUSE_OVER, _), this._lastOverlay = d), d && d.emit(t, _, !0);
                                var g = this._owner.getContainer();
                                g && (g.style.cursor = d ? "pointer" : ""), this.emit(t, _)
                            }
                        }
                    }, {
                        key: "getContext",
                        value: function() {
                            return this._context
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), delete this._context, delete this._lastOverlay
                        }
                    }]), e
                }();
            e.CanvasGroup = s, e.canvasGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                o = n(24),
                a = n(4),
                u = n(1),
                c = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o.CanvasGroup), r(e, [{
                        key: "_initProperties",
                        value: function() {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._bounds = new u.LngLatBounds
                        }
                    }, {
                        key: "_initialize",
                        value: function() {
                            for (var t, n = this, r = arguments.length, o = Array(r), a = 0; a < r; a++) o[a] = arguments[a];
                            (t = i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this)).call.apply(t, [this].concat(o)), this._options.fitView && this.setFitView(), this.whenReady(function() {
                                n._defCursor = n._owner.getMap().getDefaultCursor()
                            })
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            var t = this;
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_bindEvent", this).call(this), this.on(a.Event.ADD_LAYER, function(e) {
                                t._updateBounds(e.layer, t._bounds)
                            })
                        }
                    }, {
                        key: "delegateEvent",
                        value: function(t, e) {
                            var n = this._options.eventSupport,
                                r = this._overlays,
                                i = r.length;
                            if (n && this._load && !this._owner._inDrag && i) {
                                var o = e.offsetX,
                                    u = e.offsetY,
                                    f = e.changedTouches;
                                if (f && f.length > 0) {
                                    var s = f[0],
                                        l = c.default.offset(s.target),
                                        h = l.top,
                                        p = l.left;
                                    o = s.pageX - p, u = s.pageY - h
                                }
                                for (var d = void 0, v = void 0; --i > -1;) {
                                    var y = r[i];
                                    if (y.contains(o, u, t)) {
                                        d = y;
                                        var _ = y._selectIdx;
                                        c.default.isNil(_) || (v = _);
                                        break
                                    }
                                }
                                var g = this._lastOverlay;
                                g && g._owner !== this && (g = this._lastOverlay = void 0);
                                var b = {
                                    originalEvent: e
                                };
                                t === a.Event.MOUSE_MOVE && (g !== d || !c.default.isNil(v) && this._lastSelectIdx !== v) && (g && g.emit(a.Event.MOUSE_LEAVE, b, !0).emit(a.Event.MOUSE_OUT, b), d && d.emit(a.Event.MOUSE_ENTER, b, !0).emit(a.Event.MOUSE_OVER, b), this._lastOverlay = d, this._lastSelectIdx = v), d && d.emit(t, b, !0);
                                var m = this._owner.getMap();
                                d ? m.setDefaultCursor("pointer") : this._defCursor && m.setDefaultCursor(this._defCursor), this.emit(t, b)
                            }
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                t._owner.setBounds(t._bounds)
                            }), this
                        }
                    }, {
                        key: "afterRemoveLayer",
                        value: function(t) {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "afterRemoveLayer", this).call(this, t), this._updateBounds()
                        }
                    }, {
                        key: "_updateBounds",
                        value: function(t, e) {
                            this._bounds = e || new u.LngLatBounds;
                            for (var n = -1, r = (t = t || this._overlays).length; ++n < r;) {
                                var i = t[n];
                                this._bounds.expend(i.getBounds())
                            }
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), delete this._lastSelectIdx
                        }
                    }]), e
                }();
            e.default = f
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.marker = e.Marker = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(48)),
                a = r(n(0)),
                u = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n);
                            var r = this._options,
                                i = r.type,
                                o = r.shape,
                                a = void 0 === o ? i : o,
                                u = r.select;
                            this._mergeStyle(), this._select = !!u;
                            var c = e.getRegisteredGraph(a);
                            if (!c) throw new Error("Please register component by Marker.registerGraph(" + a + "), first.");
                            this._shape = new c(this._options)
                        }
                    }, {
                        key: "_mergeStyle",
                        value: function() {
                            var t = this._options,
                                e = t.selectStyle,
                                n = t.style;
                            e && (this._options.selectStyle = a.default.merge({}, n, e))
                        }
                    }, {
                        key: "onAdd",
                        value: function() {
                            var t = this._owner;
                            t && (this._shape.setContext(t._context), this._refreshStyle(), this.render())
                        }
                    }, {
                        key: "render",
                        value: function() {
                            this._shape.update(this._coord, this._style).render()
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function() {
                            var t = this._options,
                                e = t.style,
                                n = t.selectStyle,
                                r = void 0 === n ? e : n;
                            this._style = this._select ? r : e
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            return this._shape.contains(t, e)
                        }
                    }, {
                        key: "setSelectStyle",
                        value: function(t, e) {
                            return e && (t = a.default.merge({}, this._options.selectStyle, t)), this._options.selectStyle = t, this._mergeStyle(), this
                        }
                    }], [{
                        key: "registerGraph",
                        value: function(t) {
                            var n = t.type;
                            n && (e._graphs[n.toLowerCase()] = t)
                        }
                    }, {
                        key: "unRegisterGraph",
                        value: function(t) {
                            var n = e._graphs;
                            t && (t = t.toLowerCase()) && n[t] && delete n[t]
                        }
                    }, {
                        key: "getRegisteredGraph",
                        value: function(t) {
                            return e._graphs[t.toLowerCase()]
                        }
                    }]), e
                }();
            u._graphs = {}, e.Marker = u, e.marker = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(u, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                a = r(n(45)),
                u = r(n(0)),
                c = n(1),
                f = {
                    zIndex: 0
                },
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), i(e, [{
                        key: "_initProperties",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._data, this._options = {}, this._defaults = {
                                type: "overlay"
                            }, this._coord
                        }
                    }, {
                        key: "_initialize",
                        value: function(t, e) {
                            this._data = t;
                            var n = (this._options = u.default.defaults(e, this._defaults, f)).position;
                            this._coord = (0, c.getByKey)(t, n, this)
                        }
                    }, {
                        key: "onAdd",
                        value: function() {
                            this._owner && this.render()
                        }
                    }, {
                        key: "render",
                        value: function() {}
                    }, {
                        key: "contains",
                        value: function(t, e) {}
                    }, {
                        key: "setStyle",
                        value: function(t, e) {
                            return e && (t = u.default.merge({}, this._options.style, t)), this._options.style = t, this
                        }
                    }, {
                        key: "getContainer",
                        value: function() {
                            var t = this._owner;
                            return t && t._owner
                        }
                    }, {
                        key: "getData",
                        value: function() {
                            return u.default.cloneDeep(this._data)
                        }
                    }, {
                        key: "getPosition",
                        value: function() {
                            return this._coord
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), delete this._data, delete this._options, delete this._coord
                        }
                    }]), e
                }();
            e.default = s
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                if (t instanceof c) return t;
                if (a.default.isArray(t)) {
                    if (t.length >= 2) return new c(t[0], t[1], t[2])
                } else {
                    if ("object" === (void 0 === t ? "undefined" : i(t)) && "lng" in t && "lat" in t) return new c(t.lng, t.lat, t.alt);
                    if ("string" == typeof t) return r(t.split(","));
                    if (void 0 !== t && null !== t && void 0 !== e) return new c(t, e, n)
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.LngLat = void 0;
            var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                },
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }();
            e.toLngLat = r;
            var a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                u = n(5),
                c = e.LngLat = function() {
                    function t(e, n, r) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this._lng = +e, this._lat = +n, void 0 !== r && (this._alt = +r)
                    }
                    return o(t, [{
                        key: "equals",
                        value: function(t) {
                            return this._lng === t._lng && this._lat === t._lat
                        }
                    }, {
                        key: "toString",
                        value: function() {
                            var t = this._lng + ", " + this._lat;
                            return void 0 !== this._alt && (t += ", " + this._alt), t
                        }
                    }, {
                        key: "distanceTo",
                        value: function(t) {
                            return (0, u.distance)(this.valueOf(), r(t).valueOf())
                        }
                    }, {
                        key: "getLat",
                        value: function() {
                            return this._lat
                        }
                    }, {
                        key: "getLng",
                        value: function() {
                            return this._lng
                        }
                    }, {
                        key: "getAlt",
                        value: function() {
                            return this._alt
                        }
                    }, {
                        key: "valueOf",
                        value: function() {
                            return [this._lng, this._lat]
                        }
                    }]), t
                }()
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(64)),
                a = r(n(147)),
                u = r(n(145)),
                c = n(63),
                f = function(t) {
                    function e(t, n) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var r = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
                        return r._options = {}, r._attr = {}, r._startAt = 0, r._stopped = !0, r._paused = !1, r._startTime = 0, r._pauseStart = 0, r._pauseTime = 0, r._reversed = !1, r._chainClips = [], r._tracks = [], r._interpolation = u.default.Linear, r._options = t || {}, r._attr = n, r._initOption(t), r._tracks = r._transform(n), r
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, null, [{
                        key: "registerPlugin",
                        value: function(t) {
                            var e = t.type,
                                n = this._plugins;
                            n && n[e] || (this._plugins = n || {}, this._plugins[e] = t)
                        }
                    }]), i(e, [{
                        key: "_initOption",
                        value: function(t) {
                            var e = t[c.Attr.EASING] || c.Easing.LINEAR;
                            this._easing = a.default[e] ? a.default[e] : e, this._delay = t[c.Attr.DELAY] || 0;
                            var n = t[c.Attr.DURATION];
                            this._duration = void 0 === n ? 1e3 : n, this._repeat_0 = this._repeat = t[c.Attr.REPEAT] || 1, this._interval = t[c.Attr.INTERVAL] || 0, this._yoyo = t[c.Attr.YOYO] || !1, this._startAt = t[c.Attr.START] || 0
                        }
                    }, {
                        key: "_transform",
                        value: function(t) {
                            var e = this.constructor._plugins,
                                n = [];
                            for (var r in t)
                                if (t.hasOwnProperty(r)) {
                                    var i = t[r];
                                    for (var o in e) {
                                        var a = e[o];
                                        if (a.test(i, r)) {
                                            (i = a.parse(i, r)).__type__ = a.type;
                                            break
                                        }
                                    }
                                    n.push({
                                        key: r,
                                        value: i
                                    })
                                }
                            return n
                        }
                    }, {
                        key: "start",
                        value: function(t) {
                            var e = window.performance.now(),
                                n = !1;
                            if (this._paused) this._pauseTime += e - this._pauseStart, this._paused = !1;
                            else {
                                if (!t && !this._stopped) return this;
                                n = !0, this._stopped = !1, this._startTime = e + this._delay
                            }
                            this.emit(c.Ev.START);
                            var r = this._repeat;
                            return r > 1 && r === this._repeat_0 && n && this.emit(c.Ev.REPEAT, {
                                remain: 0
                            }), this
                        }
                    }, {
                        key: "stop",
                        value: function(t) {
                            return this._stopped || (this._stopped = !0, this._paused = !1, this._pauseTime = 0, this._pauseStart = 0, this.emit(c.Ev.STOP), this.stopChain()), t && (this._repeat = this._repeat_0), this
                        }
                    }, {
                        key: "pause",
                        value: function() {
                            return this._stopped || this._paused ? this : (this._paused = !0, this._pauseStart = window.performance.now(), this.emit(c.Ev.PAUSE), this)
                        }
                    }, {
                        key: "update",
                        value: function(t) {
                            if (this._stopped) return !0;
                            if (this._paused || t && t < this._startTime) return !0;
                            var e = t - this._pauseTime,
                                n = this._getProgress(e),
                                r = n.progress,
                                i = n.elapsed,
                                o = this._updateAttr(r, i);
                            return this.emit(c.Ev.UPDATE, {
                                progress: r,
                                keyframe: o,
                                elapsed: i
                            }), this._afterUpdate(e, i)
                        }
                    }, {
                        key: "_getProgress",
                        value: function(t) {
                            var e = (t - this._startTime) / this._duration;
                            e += this._startAt, e = Math.min(e, 1);
                            return {
                                progress: this._easing(this._reversed ? 1 - e : e),
                                elapsed: e
                            }
                        }
                    }, {
                        key: "_updateAttr",
                        value: function(t, e) {
                            for (var n = this._tracks, r = {}, i = 0, o = n.length; i < o;) {
                                var a = n[i++],
                                    u = a.key,
                                    c = a.value,
                                    f = c.__type__;
                                if (f) {
                                    c = this.constructor._plugins[f].valueOf(c, t, e, u)
                                } else c = this._interpolation(c, t);
                                r[u] = c
                            }
                            return r
                        }
                    }, {
                        key: "_afterUpdate",
                        value: function(t, e) {
                            if (1 === e) {
                                var n = this._repeat,
                                    r = this._repeat_0;
                                if (n > 1) return isFinite(n) && n--, this._startTime = t + this._interval, this._startAt = 0, this._yoyo && (this._reversed = !this._reversed), this._repeat = n, this.emit(c.Ev.REPEAT_COMPLETE, {
                                    repeat: n
                                }), this.emit(c.Ev.REPEAT, {
                                    remain: r - n
                                }), !0;
                                this._stopped = !0, this._pauseTime = 0, this._pauseStart = 0, this._repeat = r, r > 1 && this.emit(c.Ev.REPEAT_COMPLETE, {
                                    repeat: 0
                                }), this.emit(c.Ev.COMPLETE);
                                for (var i = -1, o = this._chainClips, a = o.length, u = this._animation; ++i < a;) {
                                    var f = o[i];
                                    u && u._addClip(f), f.start()
                                }
                                return !1
                            }
                            return !0
                        }
                    }, {
                        key: "chain",
                        value: function() {
                            for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                            return this._chainClips = e, this
                        }
                    }, {
                        key: "stopChain",
                        value: function() {
                            for (var t = -1, e = this._chainClips, n = e.length; ++t < n;) {
                                e[t].stop()
                            }
                            return this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off(), this._stopped = !0, this._paused = !1, this._startTime = 0, this._pauseTime = 0, this._pauseStart = 0, this._chainClips = [];
                            var t = this._animation;
                            t && t.removeClip(this), this._animation = null
                        }
                    }]), e
                }();
            f.Event = c.Ev, f.Attr = c.Attr, f.Easing = c.Easing, e.default = f
        },
        function(t, e, n) {
            "use strict";
            var r = n(15);
            e.a = function(t, e, n) {
                if (null == n && (n = r.a), i = t.length) {
                    if ((e = +e) <= 0 || i < 2) return +n(t[0], 0, t);
                    if (e >= 1) return +n(t[i - 1], i - 1, t);
                    var i, o = (i - 1) * e,
                        a = Math.floor(o),
                        u = +n(t[a], a, t);
                    return u + (+n(t[a + 1], a + 1, t) - u) * (o - a)
                }
            }
        },
        function(t, e, n) {
            "use strict";

            function r() {}

            function i(t, e) {
                var n = new r;
                if (t instanceof r) t.each(function(t, e) {
                    n.set(e, t)
                });
                else if (Array.isArray(t)) {
                    var i, o = -1,
                        a = t.length;
                    if (null == e)
                        for (; ++o < a;) n.set(o, t[o]);
                    else
                        for (; ++o < a;) n.set(e(i = t[o], o, t), i)
                } else if (t)
                    for (var u in t) n.set(u, t[u]);
                return n
            }
            n.d(e, "b", function() {
                return o
            });
            var o = "$";
            r.prototype = i.prototype = {
                constructor: r,
                has: function(t) {
                    return o + t in this
                },
                get: function(t) {
                    return this[o + t]
                },
                set: function(t, e) {
                    return this[o + t] = e, this
                },
                remove: function(t) {
                    var e = o + t;
                    return e in this && delete this[e]
                },
                clear: function() {
                    for (var t in this) t[0] === o && delete this[t]
                },
                keys: function() {
                    var t = [];
                    for (var e in this) e[0] === o && t.push(e.slice(1));
                    return t
                },
                values: function() {
                    var t = [];
                    for (var e in this) e[0] === o && t.push(this[e]);
                    return t
                },
                entries: function() {
                    var t = [];
                    for (var e in this) e[0] === o && t.push({
                        key: e.slice(1),
                        value: this[e]
                    });
                    return t
                },
                size: function() {
                    var t = 0;
                    for (var e in this) e[0] === o && ++t;
                    return t
                },
                empty: function() {
                    for (var t in this)
                        if (t[0] === o) return !1;
                    return !0
                },
                each: function(t) {
                    for (var e in this) e[0] === o && t(this[e], e.slice(1), this)
                }
            }, e.a = i
        },
        function(t, e, n) {
            "use strict";

            function r() {}

            function i(t) {
                var e;
                return t = (t + "").trim().toLowerCase(), (e = m.exec(t)) ? (e = parseInt(e[1], 16), new f(e >> 8 & 15 | e >> 4 & 240, e >> 4 & 15 | 240 & e, (15 & e) << 4 | 15 & e, 1)) : (e = w.exec(t)) ? o(parseInt(e[1], 16)) : (e = O.exec(t)) ? new f(e[1], e[2], e[3], 1) : (e = x.exec(t)) ? new f(255 * e[1] / 100, 255 * e[2] / 100, 255 * e[3] / 100, 1) : (e = M.exec(t)) ? a(e[1], e[2], e[3], e[4]) : (e = j.exec(t)) ? a(255 * e[1] / 100, 255 * e[2] / 100, 255 * e[3] / 100, e[4]) : (e = k.exec(t)) ? s(e[1], e[2] / 100, e[3] / 100, 1) : (e = P.exec(t)) ? s(e[1], e[2] / 100, e[3] / 100, e[4]) : E.hasOwnProperty(t) ? o(E[t]) : "transparent" === t ? new f(NaN, NaN, NaN, 0) : null
            }

            function o(t) {
                return new f(t >> 16 & 255, t >> 8 & 255, 255 & t, 1)
            }

            function a(t, e, n, r) {
                return r <= 0 && (t = e = n = NaN), new f(t, e, n, r)
            }

            function u(t) {
                return t instanceof r || (t = i(t)), t ? (t = t.rgb(), new f(t.r, t.g, t.b, t.opacity)) : new f
            }

            function c(t, e, n, r) {
                return 1 === arguments.length ? u(t) : new f(t, e, n, null == r ? 1 : r)
            }

            function f(t, e, n, r) {
                this.r = +t, this.g = +e, this.b = +n, this.opacity = +r
            }

            function s(t, e, n, r) {
                return r <= 0 ? t = e = n = NaN : n <= 0 || n >= 1 ? t = e = NaN : e <= 0 && (t = NaN), new h(t, e, n, r)
            }

            function l(t, e, n, o) {
                return 1 === arguments.length ? function(t) {
                    if (t instanceof h) return new h(t.h, t.s, t.l, t.opacity);
                    if (t instanceof r || (t = i(t)), !t) return new h;
                    if (t instanceof h) return t;
                    var e = (t = t.rgb()).r / 255,
                        n = t.g / 255,
                        o = t.b / 255,
                        a = Math.min(e, n, o),
                        u = Math.max(e, n, o),
                        c = NaN,
                        f = u - a,
                        s = (u + a) / 2;
                    return f ? (c = e === u ? (n - o) / f + 6 * (n < o) : n === u ? (o - e) / f + 2 : (e - n) / f + 4, f /= s < .5 ? u + a : 2 - u - a, c *= 60) : f = s > 0 && s < 1 ? 0 : c, new h(c, f, s, t.opacity)
                }(t) : new h(t, e, n, null == o ? 1 : o)
            }

            function h(t, e, n, r) {
                this.h = +t, this.s = +e, this.l = +n, this.opacity = +r
            }

            function p(t, e, n) {
                return 255 * (t < 60 ? e + (n - e) * t / 60 : t < 180 ? n : t < 240 ? e + (n - e) * (240 - t) / 60 : e)
            }
            e.c = r, n.d(e, "e", function() {
                return v
            }), n.d(e, "d", function() {
                return y
            }), e.h = i, e.b = u, e.g = c, e.a = f, e.f = l;
            var d = n(33),
                v = .7,
                y = 1 / v,
                _ = "\\s*([+-]?\\d+)\\s*",
                g = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
                b = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
                m = /^#([0-9a-f]{3})$/,
                w = /^#([0-9a-f]{6})$/,
                O = new RegExp("^rgb\\(" + [_, _, _] + "\\)$"),
                x = new RegExp("^rgb\\(" + [b, b, b] + "\\)$"),
                M = new RegExp("^rgba\\(" + [_, _, _, g] + "\\)$"),
                j = new RegExp("^rgba\\(" + [b, b, b, g] + "\\)$"),
                k = new RegExp("^hsl\\(" + [g, b, b] + "\\)$"),
                P = new RegExp("^hsla\\(" + [g, b, b, g] + "\\)$"),
                E = {
                    aliceblue: 15792383,
                    antiquewhite: 16444375,
                    aqua: 65535,
                    aquamarine: 8388564,
                    azure: 15794175,
                    beige: 16119260,
                    bisque: 16770244,
                    black: 0,
                    blanchedalmond: 16772045,
                    blue: 255,
                    blueviolet: 9055202,
                    brown: 10824234,
                    burlywood: 14596231,
                    cadetblue: 6266528,
                    chartreuse: 8388352,
                    chocolate: 13789470,
                    coral: 16744272,
                    cornflowerblue: 6591981,
                    cornsilk: 16775388,
                    crimson: 14423100,
                    cyan: 65535,
                    darkblue: 139,
                    darkcyan: 35723,
                    darkgoldenrod: 12092939,
                    darkgray: 11119017,
                    darkgreen: 25600,
                    darkgrey: 11119017,
                    darkkhaki: 12433259,
                    darkmagenta: 9109643,
                    darkolivegreen: 5597999,
                    darkorange: 16747520,
                    darkorchid: 10040012,
                    darkred: 9109504,
                    darksalmon: 15308410,
                    darkseagreen: 9419919,
                    darkslateblue: 4734347,
                    darkslategray: 3100495,
                    darkslategrey: 3100495,
                    darkturquoise: 52945,
                    darkviolet: 9699539,
                    deeppink: 16716947,
                    deepskyblue: 49151,
                    dimgray: 6908265,
                    dimgrey: 6908265,
                    dodgerblue: 2003199,
                    firebrick: 11674146,
                    floralwhite: 16775920,
                    forestgreen: 2263842,
                    fuchsia: 16711935,
                    gainsboro: 14474460,
                    ghostwhite: 16316671,
                    gold: 16766720,
                    goldenrod: 14329120,
                    gray: 8421504,
                    green: 32768,
                    greenyellow: 11403055,
                    grey: 8421504,
                    honeydew: 15794160,
                    hotpink: 16738740,
                    indianred: 13458524,
                    indigo: 4915330,
                    ivory: 16777200,
                    khaki: 15787660,
                    lavender: 15132410,
                    lavenderblush: 16773365,
                    lawngreen: 8190976,
                    lemonchiffon: 16775885,
                    lightblue: 11393254,
                    lightcoral: 15761536,
                    lightcyan: 14745599,
                    lightgoldenrodyellow: 16448210,
                    lightgray: 13882323,
                    lightgreen: 9498256,
                    lightgrey: 13882323,
                    lightpink: 16758465,
                    lightsalmon: 16752762,
                    lightseagreen: 2142890,
                    lightskyblue: 8900346,
                    lightslategray: 7833753,
                    lightslategrey: 7833753,
                    lightsteelblue: 11584734,
                    lightyellow: 16777184,
                    lime: 65280,
                    limegreen: 3329330,
                    linen: 16445670,
                    magenta: 16711935,
                    maroon: 8388608,
                    mediumaquamarine: 6737322,
                    mediumblue: 205,
                    mediumorchid: 12211667,
                    mediumpurple: 9662683,
                    mediumseagreen: 3978097,
                    mediumslateblue: 8087790,
                    mediumspringgreen: 64154,
                    mediumturquoise: 4772300,
                    mediumvioletred: 13047173,
                    midnightblue: 1644912,
                    mintcream: 16121850,
                    mistyrose: 16770273,
                    moccasin: 16770229,
                    navajowhite: 16768685,
                    navy: 128,
                    oldlace: 16643558,
                    olive: 8421376,
                    olivedrab: 7048739,
                    orange: 16753920,
                    orangered: 16729344,
                    orchid: 14315734,
                    palegoldenrod: 15657130,
                    palegreen: 10025880,
                    paleturquoise: 11529966,
                    palevioletred: 14381203,
                    papayawhip: 16773077,
                    peachpuff: 16767673,
                    peru: 13468991,
                    pink: 16761035,
                    plum: 14524637,
                    powderblue: 11591910,
                    purple: 8388736,
                    rebeccapurple: 6697881,
                    red: 16711680,
                    rosybrown: 12357519,
                    royalblue: 4286945,
                    saddlebrown: 9127187,
                    salmon: 16416882,
                    sandybrown: 16032864,
                    seagreen: 3050327,
                    seashell: 16774638,
                    sienna: 10506797,
                    silver: 12632256,
                    skyblue: 8900331,
                    slateblue: 6970061,
                    slategray: 7372944,
                    slategrey: 7372944,
                    snow: 16775930,
                    springgreen: 65407,
                    steelblue: 4620980,
                    tan: 13808780,
                    teal: 32896,
                    thistle: 14204888,
                    tomato: 16737095,
                    turquoise: 4251856,
                    violet: 15631086,
                    wheat: 16113331,
                    white: 16777215,
                    whitesmoke: 16119285,
                    yellow: 16776960,
                    yellowgreen: 10145074
                };
            n.i(d.a)(r, i, {
                displayable: function() {
                    return this.rgb().displayable()
                },
                toString: function() {
                    return this.rgb() + ""
                }
            }), n.i(d.a)(f, c, n.i(d.b)(r, {
                brighter: function(t) {
                    return t = null == t ? y : Math.pow(y, t), new f(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? v : Math.pow(v, t), new f(this.r * t, this.g * t, this.b * t, this.opacity)
                },
                rgb: function() {
                    return this
                },
                displayable: function() {
                    return 0 <= this.r && this.r <= 255 && 0 <= this.g && this.g <= 255 && 0 <= this.b && this.b <= 255 && 0 <= this.opacity && this.opacity <= 1
                },
                toString: function() {
                    var t = this.opacity;
                    return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (1 === t ? ")" : ", " + t + ")")
                }
            })), n.i(d.a)(h, l, n.i(d.b)(r, {
                brighter: function(t) {
                    return t = null == t ? y : Math.pow(y, t), new h(this.h, this.s, this.l * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? v : Math.pow(v, t), new h(this.h, this.s, this.l * t, this.opacity)
                },
                rgb: function() {
                    var t = this.h % 360 + 360 * (this.h < 0),
                        e = isNaN(t) || isNaN(this.s) ? 0 : this.s,
                        n = this.l,
                        r = n + (n < .5 ? n : 1 - n) * e,
                        i = 2 * n - r;
                    return new f(p(t >= 240 ? t - 240 : t + 120, i, r), p(t, i, r), p(t < 120 ? t + 240 : t - 120, i, r), this.opacity)
                },
                displayable: function() {
                    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
                }
            }))
        },
        function(t, e, n) {
            "use strict";
            e.b = function(t, e) {
                var n = Object.create(t.prototype);
                for (var r in e) n[r] = e[r];
                return n
            }, e.a = function(t, e, n) {
                t.prototype = e.prototype = n, n.constructor = t
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return new Function("d", "return {" + t.map(function(t, e) {
                    return JSON.stringify(t) + ": d[" + e + "]"
                }).join(",") + "}")
            }
            var i = {},
                o = {},
                a = 34,
                u = 10,
                c = 13;
            e.a = function(t) {
                function e(t, e) {
                    function n() {
                        if (d) return o;
                        if (v) return v = !1, i;
                        var e, n, r = h;
                        if (t.charCodeAt(r) === a) {
                            for (; h++ < s && t.charCodeAt(h) !== a || t.charCodeAt(++h) === a;);
                            return (e = h) >= s ? d = !0 : (n = t.charCodeAt(h++)) === u ? v = !0 : n === c && (v = !0, t.charCodeAt(h) === u && ++h), t.slice(r + 1, e - 1).replace(/""/g, '"')
                        }
                        for (; h < s;) {
                            if ((n = t.charCodeAt(e = h++)) === u) v = !0;
                            else if (n === c) v = !0, t.charCodeAt(h) === u && ++h;
                            else if (n !== l) continue;
                            return t.slice(r, e)
                        }
                        return d = !0, t.slice(r, s)
                    }
                    var r, f = [],
                        s = t.length,
                        h = 0,
                        p = 0,
                        d = s <= 0,
                        v = !1;
                    for (t.charCodeAt(s - 1) === u && --s, t.charCodeAt(s - 1) === c && --s;
                        (r = n()) !== o;) {
                        for (var y = []; r !== i && r !== o;) y.push(r), r = n();
                        e && null == (y = e(y, p++)) || f.push(y)
                    }
                    return f
                }

                function n(e) {
                    return e.map(f).join(t)
                }

                function f(t) {
                    return null == t ? "" : s.test(t += "") ? '"' + t.replace(/"/g, '""') + '"' : t
                }
                var s = new RegExp('["' + t + "\n\r]"),
                    l = t.charCodeAt(0);
                return {
                    parse: function(t, n) {
                        var i, o, a = e(t, function(t, e) {
                            if (i) return i(t, e - 1);
                            o = t, i = n ? function(t, e) {
                                var n = r(t);
                                return function(r, i) {
                                    return e(n(r), i, t)
                                }
                            }(t, n) : r(t)
                        });
                        return a.columns = o || [], a
                    },
                    parseRows: e,
                    format: function(e, n) {
                        return null == n && (n = function(t) {
                            var e = Object.create(null),
                                n = [];
                            return t.forEach(function(t) {
                                for (var r in t) r in e || n.push(e[r] = r)
                            }), n
                        }(e)), [n.map(f).join(t)].concat(e.map(function(e) {
                            return n.map(function(t) {
                                return f(e[t])
                            }).join(t)
                        })).join("\n")
                    },
                    formatRows: function(t) {
                        return t.map(n).join("\n")
                    }
                }
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                if ((n = (t = e ? t.toExponential(e - 1) : t.toExponential()).indexOf("e")) < 0) return null;
                var n, r = t.slice(0, n);
                return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(n + 1)]
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n, r, i) {
                var o = t * t,
                    a = o * t;
                return ((1 - 3 * t + 3 * o - a) * e + (4 - 6 * o + 3 * a) * n + (1 + 3 * t + 3 * o - 3 * a) * r + a * i) / 6
            }
            e.b = r, e.a = function(t) {
                var e = t.length - 1;
                return function(n) {
                    var i = n <= 0 ? n = 0 : n >= 1 ? (n = 1, e - 1) : Math.floor(n * e),
                        o = t[i],
                        a = t[i + 1],
                        u = i > 0 ? t[i - 1] : 2 * o - a,
                        c = i < e - 1 ? t[i + 2] : 2 * a - o;
                    return r((n - i / e) * e, u, o, a, c)
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(9),
                i = n(93),
                o = n(88),
                a = n(91),
                u = n(20),
                c = n(92),
                f = n(94),
                s = n(90);
            e.a = function(t, e) {
                var l, h = typeof e;
                return null == e || "boolean" === h ? n.i(s.a)(e) : ("number" === h ? u.a : "string" === h ? (l = n.i(r.f)(e)) ? (e = l, i.a) : f.a : e instanceof r.f ? i.a : e instanceof Date ? a.a : Array.isArray(e) ? o.a : "function" != typeof e.valueOf && "function" != typeof e.toString || isNaN(e) ? c.a : u.a)(t, e)
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return function() {
                    return t
                }
            }
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "c", function() {
                return i
            }), n.d(e, "a", function() {
                return o
            }), n.d(e, "b", function() {
                return a
            });
            var r, i, o, a, u = n(101);
            ! function(t) {
                r = n.i(u.a)(t), i = r.format, r.parse, o = r.utcFormat, a = r.utcParse
            }({
                dateTime: "%x, %X",
                date: "%-m/%-d/%Y",
                time: "%-I:%M:%S %p",
                periods: ["AM", "PM"],
                days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            })
        },
        function(t, e, n) {
            "use strict";
            n(2);
            var r = n(229);
            n.d(e, "v", function() {
                return r.a
            }), n.d(e, "h", function() {
                return r.a
            });
            var i = n(232);
            n.d(e, "u", function() {
                return i.a
            }), n.d(e, "g", function() {
                return i.a
            });
            var o = n(230);
            n.d(e, "t", function() {
                return o.a
            });
            var a = n(228);
            n.d(e, "s", function() {
                return a.a
            });
            var u = n(227);
            n.d(e, "k", function() {
                return u.a
            });
            var c = n(239);
            n.d(e, "r", function() {
                return c.a
            }), n.d(e, "m", function() {
                return c.a
            }), n.d(e, "j", function() {
                return c.b
            }), n.d(e, "n", function() {
                return c.c
            });
            var f = n(231);
            n.d(e, "q", function() {
                return f.a
            });
            var s = n(240);
            n.d(e, "l", function() {
                return s.a
            });
            var l = n(235);
            n.d(e, "f", function() {
                return l.a
            });
            var h = n(234);
            n.d(e, "e", function() {
                return h.a
            });
            var p = n(233);
            n.d(e, "d", function() {
                return p.a
            });
            var d = n(237);
            n.d(e, "c", function() {
                return d.a
            }), n.d(e, "o", function() {
                return d.a
            }), n.d(e, "i", function() {
                return d.b
            }), n.d(e, "p", function() {
                return d.c
            });
            var v = n(236);
            n.d(e, "b", function() {
                return v.a
            });
            var y = n(238);
            n.d(e, "a", function() {
                return y.a
            })
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapContainer = e.MapContainer = void 0;
            var o = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                a = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                u = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                c = r(n(42)),
                f = n(6),
                s = n(1),
                l = n(5),
                h = n(4),
                p = r(n(0)),
                d = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, c["default"]), a(e, [{
                        key: "_initProperties",
                        value: function() {
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._load = !1, this._map = null, this._center = null, this._centerStr = "", this._zoom = 0, this._size = [0, 0], this._eventPool = {}, this._inDrag = !1, this._amapLoader = s.amapLoader
                        }
                    }, {
                        key: "_initialize",
                        value: function(t, n) {
                            var r = this;
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n);
                            var i = function(e, n) {
                                var i = r._domContainer;
                                i || t && t.get && (i = t.get("container")) && (r._map = t, r._domContainer = i), r._createMap(), setTimeout(function() {
                                    r.emit(h.Event.LOAD)
                                }, 0)
                            };
                            this._options.ui ? n.uiSuccess = i : n.success = i, s.amapLoader.init(n)
                        }
                    }, {
                        key: "_createDefaultGroup",
                        value: function(t, e) {
                            return new("3D" === this._options.viewMode ? f.Map3DOverlayGroup : f.MapOverlayGroup)(t, e)
                        }
                    }, {
                        key: "_createMap",
                        value: function() {
                            var t, e = this;
                            this._options.resizeEnable = !0;
                            var n = this._map = this._map || new AMap.Map(this._domContainer, this._options);
                            this.updateMapStatus();
                            var r = h.Event.ZOOM_END,
                                o = h.Event.ZOOM,
                                a = h.Event.MOVE,
                                u = h.Event.MOVE_END,
                                c = h.Event.RESIZE,
                                f = h.Event.DRAG_START,
                                s = h.Event.DRAG_END,
                                l = this._eventPool = (t = {}, i(t, o, function() {
                                    e._inDrag = !0, e.emit(o)
                                }), i(t, r, function() {
                                    e._updateMapZoom(), e._inDrag = !1, e.emit(r)
                                }), i(t, a, function() {
                                    e.emit(a)
                                }), i(t, u, function() {
                                    e._updateMapCenter(), e.emit(u)
                                }), i(t, c, function() {
                                    e.updateMapStatus(), e.emit(c)
                                }), i(t, f, function() {
                                    e._inDrag = !0
                                }), i(t, s, function() {
                                    e._inDrag = !1
                                }), t);
                            for (var p in l) n.on(p, l[p])
                        }
                    }, {
                        key: "updateMapStatus",
                        value: function() {
                            this._updateMapZoom(), this._updateMapSize(), this._updateMapCenter()
                        }
                    }, {
                        key: "_updateMapZoom",
                        value: function() {
                            this._zoom = this._map.getZoom()
                        }
                    }, {
                        key: "_updateMapSize",
                        value: function() {
                            var t = this._map.getSize();
                            this._size = [t.getWidth(), t.getHeight()]
                        }
                    }, {
                        key: "_updateMapCenter",
                        value: function() {
                            this._center = this._map.getCenter(), this._centerStr = this._center.toString()
                        }
                    }, {
                        key: "getMapStatus",
                        value: function() {
                            return {
                                center: this._center,
                                centerStr: this._centerStr,
                                zoom: this._zoom,
                                size: this._size
                            }
                        }
                    }, {
                        key: "getZoom",
                        value: function() {
                            return this._updateMapZoom(), this._zoom
                        }
                    }, {
                        key: "getCenter",
                        value: function() {
                            return this._updateMapCenter(), {
                                center: this._center,
                                centerStr: this._centerStr
                            }
                        }
                    }, {
                        key: "getSize",
                        value: function() {
                            return this._updateMapSize(), this._size
                        }
                    }, {
                        key: "getMap",
                        value: function() {
                            return this._map
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this,
                                e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._groups;
                            return this.whenReady(function() {
                                var n = new s.LngLatBounds;
                                p.default.isArray(e) || (e = [e]);
                                for (var r = -1, i = e.length; ++r < i;) n.expend(e[r].getBounds());
                                t.setBounds(n)
                            })
                        }
                    }, {
                        key: "setBounds",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                if (!(t = (0, s.toLngLatBounds)(t)).isEmpty()) {
                                    var n = t.valueOf(),
                                        r = o(n, 2),
                                        i = o(r[0], 2),
                                        a = i[0],
                                        u = i[1],
                                        c = o(r[1], 2),
                                        f = c[0],
                                        l = c[1],
                                        h = AMap.LngLat;
                                    e._map.setBounds(new AMap.Bounds(new h(a, u), new h(f, l)))
                                }
                            })
                        }
                    }, {
                        key: "_getNorthWest",
                        value: function() {
                            var t = this._map,
                                e = t.getBounds() || t.getBoundSize(),
                                n = e.getNorthEast();
                            return [e.getSouthWest().getLng(), n.getLat()]
                        }
                    }, {
                        key: "lngLat2Container",
                        value: function(t) {
                            t = (0, s.toLngLat)(t);
                            var e = this._map.getZoom();
                            return (0, l.lngLat2Container)(t.valueOf(), this._getNorthWest(), e)
                        }
                    }, {
                        key: "p20ToContainer",
                        value: function(t) {
                            var e = this._map.getZoom();
                            return (0, l.lngLat2Container)([], this._getNorthWest(), e, {
                                p20: t
                            })
                        }
                    }, {
                        key: "lngLat2GeodeticCoord",
                        value: function(t) {
                            return t = (0, s.toLngLat)(t), (0, l.lngLat2G20)(t.valueOf())
                        }
                    }, {
                        key: "getGroundResolution",
                        value: function(t, e) {
                            return t = (0, s.toLngLat)(t), (0, l.getGroundResolution)(t.getLat(), e || this._map.getZoom())
                        }
                    }, {
                        key: "getViewMode",
                        value: function() {
                            return this._map && this._map.getViewMode_()
                        }
                    }, {
                        key: "_is2D",
                        value: function() {
                            return "2D" === this.getViewMode()
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this);
                            var t = this._eventPool;
                            for (var n in t) {
                                var r = t[n];
                                this._map.off(n, r)
                            }
                            this._eventPool = {}, delete this._size, delete this._zoom, delete this._center, delete this._centerStr, delete this._map
                        }
                    }]), e
                }();
            e.MapContainer = d, e.mapContainer = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(d, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(8)),
                a = n(6),
                u = r(n(0)),
                c = n(4),
                f = function(t) {
                    function e() {
                        var t;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        for (var n = arguments.length, r = Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                        var o = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [this].concat(r)));
                        return o._initProperties(), o._initialize.apply(o, r), o
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initProperties",
                        value: function() {
                            this._load = !0, this._defGroup, this._groups = [], this._eventMap = {}, this._domContainer, this._options = {}
                        }
                    }, {
                        key: "_initialize",
                        value: function(t) {
                            var e = this,
                                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                            this._domContainer = u.default.getElement(t), this._options = u.default.clone(n), this.on(c.Event.LOAD, function() {
                                e._load = !0
                            });
                            var r = n.overlays,
                                i = n.groups,
                                o = n.defaultGroup,
                                a = this._defGroup = this._createDefaultGroup(r, o);
                            if (this.addLayer(a), i)
                                for (var f = -1, s = i.length; ++f < s;) {
                                    var l = i[f];
                                    this.addLayer(l)
                                }
                            this.whenReady(function() {
                                e._bindEvent()
                            })
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            var t = this,
                                e = this._options.eventSupport;
                            if (e) {
                                var n = this._domContainer,
                                    r = this._groups;
                                c.SupportEvents.split(/\s/).forEach(function(i) {
                                    var o = t._eventMap[i] = function(n) {
                                        for (var o = -1, a = r.length; ++o < a;) {
                                            var c = r[o],
                                                f = c._options.eventSupport;
                                            f = u.default.isNul(f) ? e : f, c._options.eventSupport = f, f && c.delegateEvent(i, n)
                                        }
                                        t.emit(i, {
                                            originalEvent: n
                                        }, !0)
                                    };
                                    n.addEventListener(i, o, !1)
                                })
                            }
                        }
                    }, {
                        key: "_createDefaultGroup",
                        value: function(t, e) {
                            return new a.OverlayGroup(t, e)
                        }
                    }, {
                        key: "getContainer",
                        value: function() {
                            return this._domContainer
                        }
                    }, {
                        key: "addLayer",
                        value: function(t, e) {
                            return t instanceof a.Overlay ? (u.default.isNul(e) && (e = this._defGroup), this._addOverlay(t, e)) : t instanceof a.OverlayGroup && this._addGroup(t), this
                        }
                    }, {
                        key: "_addOverlay",
                        value: function(t, e) {
                            var n = this;
                            this.hasLayer(t) || e.addLayer(t, function() {
                                n.emit(c.Event.ADD_LAYER, {
                                    layer: t
                                })
                            })
                        }
                    }, {
                        key: "_addGroup",
                        value: function(t) {
                            var e = this;
                            this.hasLayer(t) || (this._groups.push(t), t._owner2Add = this, t.beforeAdd(), this.whenReady(function() {
                                t._owner2Add === e && (t._owner = e, t.onAdd(), t.emit(c.Event.ADD), e.emit(c.Event.ADD_LAYER, {
                                    layer: t
                                }))
                            }))
                        }
                    }, {
                        key: "removeLayer",
                        value: function(t) {
                            return t instanceof a.Overlay ? this._rmOverlay(t) : t instanceof a.OverlayGroup && this._rmGroup(t), this
                        }
                    }, {
                        key: "_rmOverlay",
                        value: function(t) {
                            var e = this;
                            if (this.hasLayer(t)) {
                                var n = t._owner2Add;
                                n && n.removeLayer(t, function() {
                                    e.emit(c.Event.RM_LAYER, {
                                        layer: t
                                    })
                                })
                            }
                        }
                    }, {
                        key: "_rmGroup",
                        value: function(t) {
                            if (this.hasLayer(t)) {
                                var e = this._groups,
                                    n = e.indexOf(t); - 1 !== n && (t.onRemove(), t.emit(c.Event.RM), this.emit(c.Event.RM_LAYER, {
                                    layer: t
                                }), delete t._owner, delete t._owner2Add, e.splice(n, 1))
                            }
                        }
                    }, {
                        key: "hasLayer",
                        value: function(t) {
                            return t instanceof a.Overlay && (t = t._owner2Add), -1 !== this._groups.indexOf(t)
                        }
                    }, {
                        key: "whenReady",
                        value: function(t) {
                            return this._load ? t.call(this) : this.on(c.Event.LOAD, t), this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off();
                            var t = this._eventMap;
                            for (var e in t) this._domContainer.removeEventListener(e, t[e]);
                            this._eventMap = {};
                            for (var n = this._groups; n.length;) n[n.length - 1].destroy();
                            this._groups = [], this._options = {}, delete this._load, delete this._domContainer
                        }
                    }]), e
                }();
            e.default = f
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return u[t] || (u[t] = Math.pow(2, t)), u[t]
            }

            function i(t) {
                return a[t] || (a[t] = 256 * r(t)), a[t]
            }

            function o(t, e, n) {
                var r = function(t, e) {
                    var n = -p;
                    return [(e = e || 1) * (p * t[0] + .5), e * (n * t[1] + .5)]
                }(function(t) {
                    var e = Math.max(Math.min(h, t[1]), -h),
                        n = t[0] * f,
                        r = e * f;
                    return r = Math.log(Math.tan(l + r / 2)), [n, r]
                }(t), e);
                return n && (r[0] = Math.round(r[0]), r[1] = Math.round(r[1])), r
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var a = {},
                u = {},
                c = 12756274,
                f = Math.PI / 180,
                s = 180 / Math.PI,
                l = Math.PI / 4,
                h = 85.0511287798,
                p = .5 / Math.PI;
            e.distance = function(t, e) {
                var n = Math.cos,
                    r = t[1] * f,
                    i = t[0] * f,
                    o = e[1] * f,
                    a = e[0] * f - i,
                    u = (1 - n(o - r) + (1 - n(a)) * n(r) * n(o)) / 2;
                return c * Math.asin(Math.sqrt(u))
            }, e.getScaleInLv = r, e.getScale = i, e.lngLatToPointByScale = o, e.pointToLngLat = function(t, e) {
                return function(t) {
                    var e = t[0] * s,
                        n = (2 * Math.atan(Math.exp(t[1])) - Math.PI / 2) * s;
                    return [parseFloat(e.toFixed(6)), parseFloat(n.toFixed(6))]
                }(function(t, e) {
                    var n = p,
                        r = -n;
                    return [(t[0] / e - .5) / n, (t[1] / e - .5) / r]
                }(t, i(e)))
            }, e.lngLatToPoint = function(t, e, n) {
                return o(t, i(e), n)
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = "undefined" == typeof Float32Array ? Array : Float32Array,
                i = {
                    create: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                            n = new r(2);
                        return n[0] = t, n[1] = e, n
                    },
                    copy: function(t, e) {
                        return t[0] = e[0], t[1] = e[1], t
                    },
                    clone: function(t) {
                        var e = new r(2);
                        return e[0] = t[0], e[1] = t[1], e
                    },
                    set: function(t, e, n) {
                        return t[0] = e, t[1] = n, t
                    },
                    add: function(t, e, n) {
                        return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t
                    },
                    scaleAndAdd: function(t, e, n, r) {
                        return t[0] = e[0] + n[0] * r, t[1] = e[1] + n[1] * r, t
                    },
                    sub: function(t, e, n) {
                        return t[0] = e[0] - n[0], t[1] = e[1] - n[1], t
                    },
                    length: function(t) {
                        return Math.sqrt(this.lengthSquare(t))
                    },
                    lengthSquare: function(t) {
                        return t[0] * t[0] + t[1] * t[1]
                    },
                    multiply: function(t, e, n) {
                        return t[0] = e[0] * n[0], t[1] = e[1] * n[1], t
                    },
                    divide: function(t, e, n) {
                        return t[0] = e[0] / n[0], t[1] = e[1] / n[1], t
                    },
                    dot: function(t, e) {
                        return t[0] * e[0] + t[1] * e[1]
                    },
                    scale: function(t, e, n) {
                        return t[0] = e[0] * n, t[1] = e[1] * n, t
                    },
                    normalize: function(t, e) {
                        var n = this.len(e);
                        return 0 === n ? (t[0] = 0, t[1] = 0) : (t[0] = e[0] / n, t[1] = e[1] / n), t
                    },
                    distance: function(t, e) {
                        return Math.sqrt(this.distanceSquare(t, e))
                    },
                    distanceSquare: function(t, e) {
                        return (t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1])
                    },
                    negate: function(t, e) {
                        return t[0] = -e[0], t[1] = -e[1], t
                    },
                    lerp: function(t, e, n, r) {
                        return t[0] = e[0] + r * (n[0] - e[0]), t[1] = e[1] + r * (n[1] - e[1]), t
                    },
                    applyTransform: function(t, e, n) {
                        var r = e[0],
                            i = e[1];
                        return t[0] = n[0] * r + n[2] * i + n[4], t[1] = n[1] * r + n[3] * i + n[5], t
                    },
                    min: function(t, e, n) {
                        return t[0] = Math.min(e[0], n[0]), t[1] = Math.min(e[1], n[1]), t
                    },
                    max: function(t, e, n) {
                        return t[0] = Math.max(e[0], n[0]), t[1] = Math.max(e[1], n[1]), t
                    },
                    getAngle: function(t, e) {
                        var n = 0;
                        return 0 != t[0] - e[0] && (n = Math.atan2(t[1] - e[1], t[0] - e[0])), n
                    }
                };
            i.len = i.length, i.lenSquare = i.lengthSquare, i.dist = i.distance, i.distSquare = i.distanceSquare, e.default = i
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(8)),
                o = function(t) {
                    function e() {
                        var t;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        for (var n = arguments.length, r = Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                        var o = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [this].concat(r)));
                        return o._initProperties.apply(o, r), o._initialize.apply(o, r), o
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, i["default"]), r(e, [{
                        key: "_initProperties",
                        value: function() {
                            this._owner, this._owner2Add, this._bounds
                        }
                    }, {
                        key: "_initialize",
                        value: function() {}
                    }, {
                        key: "beforeAdd",
                        value: function() {}
                    }, {
                        key: "onAdd",
                        value: function(t) {}
                    }, {
                        key: "onRemove",
                        value: function(t) {}
                    }, {
                        key: "afterRemove",
                        value: function() {}
                    }, {
                        key: "addTo",
                        value: function(t) {
                            return t && t.addLayer(this), this
                        }
                    }, {
                        key: "remove",
                        value: function() {
                            return this.removeFrom(this._owner2Add)
                        }
                    }, {
                        key: "removeFrom",
                        value: function(t) {
                            return t && t.removeLayer(this), this
                        }
                    }, {
                        key: "getBounds",
                        value: function() {
                            return this._bounds
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off(), this.remove(), delete this._owner, delete this._owner2Add, delete this._bounds
                        }
                    }]), e
                }();
            e.default = o
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                o = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(47)),
                a = n(62),
                u = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), r(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            var r = this;
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n);
                            if (this._options.animation) {
                                (this._animation = new a.Animation).on("update", function() {
                                    r.clear()
                                }).on("afterUpdate", function() {
                                    for (var t = r._overlays, e = -1, n = t.length; ++e < n;) t[e].render()
                                })
                            }
                        }
                    }, {
                        key: "onAdd",
                        value: function(t) {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "onAdd", this).call(this, t), this._mount()
                        }
                    }, {
                        key: "_mount",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                var e = t._animation;
                                e && e.start()
                            })
                        }
                    }, {
                        key: "_unMount",
                        value: function() {
                            var t = this._animation;
                            t && t.stop(), this.clear()
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this);
                            var t = this._animation;
                            t && t.destroy(), delete this._animation
                        }
                    }]), e
                }();
            e.default = u
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t, e) {
                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !e || "object" != typeof e && "function" != typeof e ? t : e
            }

            function o(t) {
                t.onRemove(), delete t._owner2Add, delete t._owner, t.emit(s.Event.RM)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var a = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                u = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                c = r(n(45)),
                f = r(n(0)),
                s = n(4),
                l = function(t) {
                    function e() {
                        var t, n, r, o;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        for (var a = arguments.length, u = Array(a), c = 0; c < a; c++) u[c] = arguments[c];
                        return n = r = i(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [this].concat(u))), r.addOverlay = r.addLayer, r.removeOverlay = r.removeLayer, o = n, i(r, o)
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, c["default"]), a(e, [{
                        key: "_initProperties",
                        value: function() {
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._domContainer, this._options = {}, this._overlays = [], this._zIndex = 0, this._load = !1
                        }
                    }, {
                        key: "_initialize",
                        value: function() {
                            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                                e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                n = (this._options = f.default.clone(e)).container;
                            this._bindEvent(), this.addLayer(t), this.addTo(n)
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            var t = this;
                            this.on(s.Event.LOAD, function() {
                                t._load = !0
                            })
                        }
                    }, {
                        key: "beforeAddLayer",
                        value: function(t) {}
                    }, {
                        key: "addLayer",
                        value: function(t, e) {
                            for (var n = this, r = this._overlays, i = [], o = -1, a = (t = f.default.convert2Array(t)).length; ++o < a;) {
                                var u = t[o];
                                u._owner2Add || (u._owner2Add = this, u.beforeAdd(), i.push(u), r.push(u))
                            }
                            var c = i.length;
                            return c && (this._options.zLevel && (i = r.sort(function(t, e) {
                                return t._zIndex - e._zIndex
                            }), c = i.length), this.whenReady(function() {
                                if (n._owner2Add) {
                                    n.beforeAddLayer(i);
                                    for (var t = -1; ++t < c;) {
                                        var r = i[t];
                                        r._owner2Add && (r._owner = n, r.onAdd(), r.emit(s.Event.ADD))
                                    }
                                    var o = {
                                        layer: i
                                    };
                                    n.emit(s.Event.ADD_LAYER, o), f.default.callFn(e, n, o)
                                }
                            })), this
                        }
                    }, {
                        key: "removeLayer",
                        value: function(t) {
                            var e = this._overlays,
                                n = [];
                            if (f.default.isNil(t)) {
                                for (var r = -1, i = e.length; ++r < i;) {
                                    var a = e[r];
                                    o(a), n.push(a)
                                }
                                this._overlays = []
                            } else
                                for (var u = (t = f.default.convert2Array(t)).length; --u > -1;) {
                                    var c = t[u],
                                        l = e.indexOf(c); - 1 !== l && (o(c), e.splice(l, 1), n.push(c))
                                }
                            return n.length && (this.afterRemoveLayer(n), this.emit(s.Event.RM_LAYER, {
                                layer: n
                            })), this
                        }
                    }, {
                        key: "afterRemoveLayer",
                        value: function(t) {}
                    }, {
                        key: "onAdd",
                        value: function(t) {
                            var e = this;
                            this._owner && !this._load && this._initLayout(function(n) {
                                n && n.error || (f.default.callFn(t, e), e.emit(s.Event.LOAD))
                            })
                        }
                    }, {
                        key: "onRemove",
                        value: function() {
                            this._owner && (this.removeLayer(), this._removeLayout(), this._load = !1)
                        }
                    }, {
                        key: "hasOverlay",
                        value: function(t) {
                            return -1 !== this._overlays.indexOf(t)
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {}
                    }, {
                        key: "getZIndex",
                        value: function() {}
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            this._domContainer = this._owner.getContainer(), f.default.callFn(t, this)
                        }
                    }, {
                        key: "_removeLayout",
                        value: function() {}
                    }, {
                        key: "delegateEvent",
                        value: function(t, e) {}
                    }, {
                        key: "whenReady",
                        value: function(t) {
                            return this._load ? t.call(this) : this.on(s.Event.LOAD, t), this
                        }
                    }, {
                        key: "getContainer",
                        value: function() {
                            return this._domContainer
                        }
                    }, {
                        key: "_onRedraw",
                        value: function() {}
                    }, {
                        key: "clear",
                        value: function() {}
                    }, {
                        key: "destroy",
                        value: function() {
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), delete this._domContainer, delete this._options
                        }
                    }]), e
                }();
            e.default = l
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                a = r(n(27)),
                u = n(62),
                c = r(n(0)),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), i(e, [{
                        key: "_initProperties",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._defaults = {
                                type: "animationOverlay"
                            }
                        }
                    }, {
                        key: "_initialize",
                        value: function(t, n) {
                            var r = this;
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n);
                            var i = this._options.animation;
                            if (i) {
                                var a = i.keyframe;
                                a && (this._clip = new u.Clip(i, a).on("update", function(t, e) {
                                    r._refreshStyle(t, e)
                                }))
                            }
                        }
                    }, {
                        key: "onAdd",
                        value: function() {
                            var t = this._owner;
                            if (t) {
                                var e = this._clip,
                                    n = t._animation;
                                n && e ? (n.addClip(e), t._mount()) : (this._refreshStyle(), this.render())
                            }
                        }
                    }, {
                        key: "onRemove",
                        value: function() {
                            var t = this._owner;
                            if (t) {
                                var e = this._clip,
                                    n = t._animation;
                                n && e && (e.stop(), n.removeClip(e))
                            }
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function(t, e) {
                            var n = this._options.style;
                            this._style = e ? c.default.merge({}, n, e) : n
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this);
                            var t = this._clip;
                            t && t.destroy(), delete this._clip
                        }
                    }]), e
                }();
            e.default = f
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapLine = e.MapLine = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(50)),
                a = r(n(0)),
                u = n(1),
                c = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), n.isP20 ? this._coord = t : this._setLngLats(this._coord)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this._coord,
                                e = void 0;
                            e = this._options.isP20 ? this._p20ToContainer(t) : this._lngLats2Container(t);
                            var n = this._style;
                            return n && (n._coord_ = e, a.default.is2DimArr(e) && (e = [e]), this._shape.update(e, n).render()), this
                        }
                    }, {
                        key: "_p20ToContainer",
                        value: function(t) {
                            for (var e = this.getContainer(), n = [], r = 0; r < t.length; r++) {
                                var i = t[r];
                                Array.isArray(i) && Array.isArray(i[0]) ? n.push(this._p20ToContainer(i)) : n.push(e.p20ToContainer(i))
                            }
                            return n
                        }
                    }, {
                        key: "_lngLats2Container",
                        value: function(t) {
                            for (var e = [], n = this.getContainer(), r = -1, i = t.length; ++r < i;) {
                                var o = t[r];
                                o instanceof u.LngLat ? e.push(n.lngLat2Container(o)) : e.push(this._lngLats2Container(o))
                            }
                            return e
                        }
                    }, {
                        key: "setLngLats",
                        value: function(t) {
                            this._setLngLats(t), this.render()
                        }
                    }, {
                        key: "_setLngLats",
                        value: function(t) {
                            this._bounds = new u.LngLatBounds, this._coord = (0, u.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "getLngLats",
                        value: function() {
                            return this._coord
                        }
                    }]), e
                }();
            e.MapLine = c, e.mapLine = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(c, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = n(26),
                o = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, i.Marker), r(e, [{
                        key: "_initProperties",
                        value: function() {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._defaults = {
                                type: "amapmarker"
                            }
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this.getContainer();
                            return t && t.setBounds(this.getBounds()), this
                        }
                    }]), e
                }();
            e.default = o
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t[0]
            }

            function i(t) {
                return t[1]
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = function() {
                function t(t) {
                    for (var r = {}, i = [], a = 2 * e, u = -1, c = t.length; ++u < c;) {
                        var f = void 0,
                            s = void 0,
                            l = void 0;
                        if (!isNaN(s = +n.call(null, f = t[u], u, t)) && !isNaN(l = +o.call(null, f, u, t))) {
                            var h = Math.floor(s / a),
                                p = Math.floor(l / a),
                                d = h + "-" + p,
                                v = r[d];
                            f.index = u, v ? v.push(f) : (i.push(v = r[d] = [f]), v.i = h, v.j = p, v.x = h * a + e, v.y = p * a + e)
                        }
                    }
                    return i
                }
                var e = void 0,
                    n = r,
                    o = i;
                return t.radius = function(n) {
                    return arguments.length ? (e = +n, t) : e
                }, t.size = function(t) {}, t.radius(1)
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                var r = 60 * n;
                "pointy" == (arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "pointy") && (r += 30);
                var i = Math.PI / 180 * r;
                return [t[0] + e * Math.cos(i), t[1] + e * Math.sin(i)]
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = {
                getHexCorner: r,
                getHexCorners: function(t, e, n) {
                    for (var i = [], o = -1; ++o < 6;) i.push(r(t, e, o, n));
                    return i
                },
                getHexSize: function(t) {
                    return "pointy" == (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "pointy") ? [Math.sqrt(3) * t, 2 * t] : [2 * t, Math.sqrt(3) * t]
                }
            };
            e.default = i
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t[0]
            }

            function i(t) {
                return t[1]
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = function() {
                function t(t) {
                    var e, n = {},
                        r = [],
                        i = t.length;
                    for (e = 0; e < i; ++e)
                        if (!isNaN(a = +p.call(null, o = t[e], e, t)) && !isNaN(f = +d.call(null, o, e, t))) {
                            var o, a, f, s = Math.round(f /= c),
                                l = Math.round(a = a / u - (1 & s) / 2),
                                h = f - s;
                            if (3 * Math.abs(h) > 1) {
                                var v = a - l,
                                    y = l + (a < l ? -1 : 1) / 2,
                                    _ = s + (f < s ? -1 : 1),
                                    g = a - y,
                                    b = f - _;
                                v * v + h * h > g * g + b * b && (l = y + (1 & s ? 1 : -1) / 2, s = _)
                            }
                            var m = l + "-" + s,
                                w = n[m];
                            o.index = e, w ? w.push(o) : (r.push(w = n[m] = [o]), w.i = l, w.j = s, w.x = (l + (1 & s) / 2) * u, w.y = s * c)
                        }
                    return r
                }

                function e(t) {
                    var e = 0,
                        n = 0;
                    return a.map(function(r) {
                        var i = Math.sin(r) * t,
                            o = -Math.cos(r) * t,
                            a = i - e,
                            u = o - n;
                        return e = i, n = o, [a, u]
                    })
                }
                var n, u, c, f = 0,
                    s = 0,
                    l = 1,
                    h = 1,
                    p = r,
                    d = i;
                return t.hexagon = function(t) {
                    return "m" + e(null == t ? n : +t).join("l") + "z"
                }, t.hexagonCorner = function(t) {
                    return e(null == t ? n : +t)
                }, t.centers = function() {
                    for (var t = [], e = Math.round(s / c), r = Math.round(f / u), i = e * c; i < h + n; i += c, ++e)
                        for (var o = r * u + (1 & e) * u / 2; o < l + u / 2; o += u) t.push([o, i]);
                    return t
                }, t.mesh = function() {
                    var r = e(n).slice(0, 4).join("l");
                    return t.centers().map(function(t) {
                        return "M" + t + "m" + r
                    }).join("")
                }, t.x = function(e) {
                    return arguments.length ? (p = e, t) : p
                }, t.y = function(e) {
                    return arguments.length ? (d = e, t) : d
                }, t.radius = function(e) {
                    return arguments.length ? (n = +e, u = 2 * n * Math.sin(o), c = 1.5 * n, t) : n
                }, t.size = function(e) {
                    return arguments.length ? (f = s = 0, l = +e[0], h = +e[1], t) : [l - f, h - s]
                }, t.extent = function(e) {
                    return arguments.length ? (f = +e[0][0], s = +e[0][1], l = +e[1][0], h = +e[1][1], t) : [
                        [f, s],
                        [l, h]
                    ]
                }, t.radius(1)
            };
            var o = Math.PI / 3,
                a = [0, o, 2 * o, 3 * o, 4 * o, 5 * o]
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(66)),
                i = {
                    isColor: function(t) {
                        return r.default.isColor(t)
                    },
                    toNormal: function(t) {
                        return r.default.toNormal(t)
                    },
                    toFragColor: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1,
                            n = this.toNormal(t);
                        return [n[0] / 255, n[1] / 255, n[2] / 255, n[3] * e]
                    }
                };
            e.default = i
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return t instanceof a ? t : new a(t, e)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.toLngLatBounds = e.LngLatBounds = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = n(28),
                a = function() {
                    function t() {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this._southWest, this._northEast;
                        for (var e = -1, n = arguments.length; ++e < n;) this.expend(arguments.length <= e ? void 0 : arguments[e])
                    }
                    return i(t, [{
                        key: "expend",
                        value: function(e) {
                            var n = this._southWest,
                                i = this._northEast,
                                a = void 0,
                                u = void 0;
                            if (e instanceof o.LngLat) a = u = e;
                            else {
                                if (!(e instanceof t)) return e ? this.expend((0, o.toLngLat)(e) || r(e)) : this;
                                if (a = e._southWest, u = e._northEast, !a || !u) return this
                            } if (n || i) {
                                var c = n._lng,
                                    f = n._lat,
                                    s = i._lng,
                                    l = i._lat,
                                    h = a._lng,
                                    p = a._lat,
                                    d = u._lng,
                                    v = u._lat;
                                n._lng = h < c ? h : c, n._lat = p < f ? p : f, i._lng = d > s ? d : s, i._lat = v > l ? v : l
                            } else this._southWest = new o.LngLat(a._lng, a._lat), this._northEast = new o.LngLat(u._lng, u._lat);
                            return this
                        }
                    }, {
                        key: "contains",
                        value: function(e) {
                            var n = void 0,
                                i = void 0;
                            (e = "number" == typeof e[0] || e instanceof o.LngLat || "lat" in e ? (0, o.toLngLat)(e) : r(e)) instanceof o.LngLat ? n = i = e : e instanceof t && (n = e.getSouthWest(), i = e.getNorthEast());
                            var a = this._southWest,
                                u = this._northEast;
                            return n.lat >= a.lat && i.lat <= u.lat && n.lng >= a.lng && i.lng <= u.lng
                        }
                    }, {
                        key: "intersects",
                        value: function(t) {
                            t = r(t);
                            var e = this._southWest,
                                n = this._northEast,
                                i = t.getSouthWest(),
                                o = t.getNorthEast(),
                                a = o.lat >= e.lat && i.lat <= n.lat,
                                u = o.lng >= e.lng && i.lng <= n.lng;
                            return a && u
                        }
                    }, {
                        key: "getCenter",
                        value: function() {
                            var t = this._southWest,
                                e = this._northEast;
                            return new o.LngLat((t._lng + e._lng) / 2, (t._lat + e._lat) / 2)
                        }
                    }, {
                        key: "isEmpty",
                        value: function() {
                            return !this._southWest && !this._northEast
                        }
                    }, {
                        key: "getSouthWest",
                        value: function() {
                            return new o.LngLat(this.getSouth(), this.getWest())
                        }
                    }, {
                        key: "getNorthEast",
                        value: function() {
                            return new o.LngLat(this.getNorth(), this.getEast())
                        }
                    }, {
                        key: "getNorth",
                        value: function() {
                            return this._northEast._lat
                        }
                    }, {
                        key: "getSouth",
                        value: function() {
                            return this._southWest._lat
                        }
                    }, {
                        key: "getWest",
                        value: function() {
                            return this._southWest._lng
                        }
                    }, {
                        key: "getEast",
                        value: function() {
                            return this._northEast._lng
                        }
                    }, {
                        key: "valueOf",
                        value: function() {
                            var t = this._southWest,
                                e = this._northEast;
                            return [
                                [t._lng, t._lat],
                                [e._lng, e._lat]
                            ]
                        }
                    }]), t
                }();
            e.LngLatBounds = a, e.toLngLatBounds = r
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                return t instanceof c ? t : a.default.isArray(t) ? new c(t[0], t[1]) : void 0 === t || null === t ? t : "object" === (void 0 === t ? "undefined" : i(t)) && "x" in t && "y" in t ? new c(t.x, t.y) : new c(t, e, n)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Point = void 0;
            var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                },
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }();
            e.toPoint = r;
            var a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                u = Math.trunc || function(t) {
                    return t > 0 ? Math.floor(t) : Math.ceil(t)
                },
                c = e.Point = function() {
                    function t(e, n, r) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this._x = r ? e >> 0 : e, this._y = r ? n >> 0 : n
                    }
                    return o(t, [{
                        key: "clone",
                        value: function() {
                            return new t(this._x, this._y)
                        }
                    }, {
                        key: "add",
                        value: function(t) {
                            return this.clone()._add(r(t))
                        }
                    }, {
                        key: "_add",
                        value: function(t) {
                            return this._x += t._x, this._y += t._y, this
                        }
                    }, {
                        key: "subtract",
                        value: function(t) {
                            return this.clone()._subtract(r(t))
                        }
                    }, {
                        key: "_subtract",
                        value: function(t) {
                            return this._x -= t._x, this._y -= t._y, this
                        }
                    }, {
                        key: "divideBy",
                        value: function(t) {
                            return this.clone()._divideBy(t)
                        }
                    }, {
                        key: "_divideBy",
                        value: function(t) {
                            return this._x /= t, this._y /= t, this
                        }
                    }, {
                        key: "multiplyBy",
                        value: function(t) {
                            return this.clone()._multiplyBy(t)
                        }
                    }, {
                        key: "_multiplyBy",
                        value: function(t) {
                            return this._x *= t, this._y *= t, this
                        }
                    }, {
                        key: "scaleBy",
                        value: function(e) {
                            return new t(this._x * e._x, this._y * e._y)
                        }
                    }, {
                        key: "unscaleBy",
                        value: function(e) {
                            return new t(this._x / e._x, this._y / e._y)
                        }
                    }, {
                        key: "round",
                        value: function() {
                            return this.clone()._round()
                        }
                    }, {
                        key: "_round",
                        value: function() {
                            return this._x = this._x >> 0, this._y = this._y >> 0, this
                        }
                    }, {
                        key: "floor",
                        value: function() {
                            return this.clone()._floor()
                        }
                    }, {
                        key: "_floor",
                        value: function() {
                            return this._x = Math.floor(this._x), this._y = Math.floor(this._y), this
                        }
                    }, {
                        key: "ceil",
                        value: function() {
                            return this.clone()._ceil()
                        }
                    }, {
                        key: "_ceil",
                        value: function() {
                            return this._x = Math.ceil(this._x), this._y = Math.ceil(this._y), this
                        }
                    }, {
                        key: "trunc",
                        value: function() {
                            return this.clone()._trunc()
                        }
                    }, {
                        key: "_trunc",
                        value: function() {
                            return this._x = u(this._x), this._y = u(this._y), this
                        }
                    }, {
                        key: "distanceTo",
                        value: function(t) {
                            return Math.sqrt(this.distanceSquare(t))
                        }
                    }, {
                        key: "distanceSquare",
                        value: function(t) {
                            var e = (t = r(t))._x - this._x,
                                n = t._y - this._y;
                            return e * e + n * n
                        }
                    }, {
                        key: "equals",
                        value: function(t) {
                            return (t = r(t))._x === this._x && t._y === this._y
                        }
                    }, {
                        key: "getAngle",
                        value: function(t) {
                            t = r(t);
                            var e = 0,
                                n = this._x = t._x;
                            return 0 != n && (e = Math.atan2(this._y - t._y, n)), e
                        }
                    }, {
                        key: "valueOf",
                        value: function() {
                            return [this._x, this._y]
                        }
                    }]), t
                }()
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                    return e.default = t, e
                }(n(208)),
                i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(8));
            ! function(t) {
                function e(t) {
                    ! function(t, e) {
                        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                    }(this, e);
                    var n = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this)),
                        i = (n._options = t || {}).type;
                    return n._scale = r[i], n
                }(function(t, e) {
                    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                    t.prototype = Object.create(e && e.prototype, {
                        constructor: {
                            value: t,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                })(e, i["default"])
            }();
            e.default = {
                get: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "linear";
                    t = "scale" + t[0].toUpperCase() + t.substr(1);
                    var e = r[t];
                    return void 0 === e ? r.scaleLinear : e
                },
                create: function(t) {
                    return this.get(t)()
                }
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(8)),
                a = r(n(0)),
                u = function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                    return e.default = t, e
                }(n(187)),
                c = a.default.clone,
                f = a.default.map,
                s = a.default.isFunction,
                l = function(t) {
                    function e(t, n) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var r = function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this)),
                            i = (r._options = n || {}).type,
                            o = void 0 === i ? "json" : i,
                            f = c(t);
                        switch (o.toLowerCase()) {
                            case "csv":
                                f = u.csvParse(f);
                                break;
                            case "tsv":
                                f = u.tsvParse(f);
                                break;
                            case "json":
                            default:
                                f.columns = a.default.keys(f[0])
                        }
                        return r._data = f, r
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "add",
                        value: function(t) {
                            var e = c(t);
                            return this._data = this._data.concat(e), this
                        }
                    }, {
                        key: "getRow",
                        value: function(t) {
                            return this._data[t]
                        }
                    }, {
                        key: "getColumns",
                        value: function() {
                            return this._data.columns
                        }
                    }, {
                        key: "getData",
                        value: function(t) {
                            var e = this,
                                n = this._data;
                            return void 0 === t ? c(n) : f(n, function(n, r, i) {
                                return s(t) ? t.call(e, n, r, i) : n[t]
                            })
                        }
                    }, {
                        key: "getLength",
                        value: function() {
                            return this._data.length
                        }
                    }, {
                        key: "getOptions",
                        value: function(t) {
                            var e = c(this._options);
                            return t && (e = e[t]), e
                        }
                    }]), e
                }();
            e.default = l
        },
        function(t, e, n) {
            t.exports = n(60)
        },
        function(t, e, n) {
            ! function() {
                "use strict";

                function e(t, e, n, r, i) {
                    void 0 === i && (i = .5);
                    var o = h.projectionratio(i, t),
                        a = 1 - o,
                        u = {
                            x: o * e.x + a * r.x,
                            y: o * e.y + a * r.y
                        },
                        c = h.abcratio(i, t);
                    return {
                        A: {
                            x: n.x + (n.x - u.x) / c,
                            y: n.y + (n.y - u.y) / c
                        },
                        B: n,
                        C: u
                    }
                }
                var r = Math.abs,
                    i = Math.min,
                    o = Math.max,
                    a = Math.cos,
                    u = Math.sin,
                    c = Math.acos,
                    f = Math.sqrt,
                    s = Math.PI,
                    l = {
                        x: 0,
                        y: 0,
                        z: 0
                    },
                    h = n(61),
                    p = n(143),
                    d = function(t) {
                        var e = t && t.forEach ? t : [].slice.call(arguments),
                            n = !1;
                        if ("object" == typeof e[0]) {
                            n = e.length;
                            var i = [];
                            e.forEach(function(t) {
                                ["x", "y", "z"].forEach(function(e) {
                                    void 0 !== t[e] && i.push(t[e])
                                })
                            }), e = i
                        }
                        var o = !1,
                            a = e.length;
                        if (n) {
                            if (n > 4) {
                                if (1 !== arguments.length) throw new Error("Only new Bezier(point[]) is accepted for 4th and higher order curves");
                                o = !0
                            }
                        } else if (6 !== a && 8 !== a && 9 !== a && 12 !== a && 1 !== arguments.length) throw new Error("Only new Bezier(point[]) is accepted for 4th and higher order curves");
                        var u = !o && (9 === a || 12 === a) || t && t[0] && void 0 !== t[0].z;
                        this._3d = u;
                        for (var c = [], f = 0, s = u ? 3 : 2; f < a; f += s) {
                            var l = {
                                x: e[f],
                                y: e[f + 1]
                            };
                            u && (l.z = e[f + 2]), c.push(l)
                        }
                        this.order = c.length - 1, this.points = c;
                        var p = ["x", "y"];
                        u && p.push("z"), this.dims = p, this.dimlen = p.length,
                            function(t) {
                                for (var e = t.order, n = t.points, i = h.align(n, {
                                    p1: n[0],
                                    p2: n[e]
                                }), o = 0; o < i.length; o++)
                                    if (r(i[o].y) > 1e-4) return void(t._linear = !1);
                                t._linear = !0
                            }(this), this._t1 = 0, this._t2 = 1, this.update()
                    };
                d.fromSVG = function(t) {
                    var e = t.match(/[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?/g).map(parseFloat);
                    return /[cq]/.test(t) ? (e = e.map(function(t, n) {
                        return n < 2 ? t : t + e[n % 2]
                    }), new d(e)) : new d(e)
                }, d.quadraticFromPoints = function(t, n, r, i) {
                    if (void 0 === i && (i = .5), 0 === i) return new d(n, n, r);
                    if (1 === i) return new d(t, n, n);
                    var o = e(2, t, n, r, i);
                    return new d(t, o.A, r)
                }, d.cubicFromPoints = function(t, n, r, i, o) {
                    void 0 === i && (i = .5);
                    var a = e(3, t, n, r, i);
                    void 0 === o && (o = h.dist(n, a.C));
                    var u = o * (1 - i) / i,
                        c = h.dist(t, r),
                        f = (r.x - t.x) / c,
                        s = (r.y - t.y) / c,
                        l = o * f,
                        p = o * s,
                        v = u * f,
                        y = u * s,
                        _ = n.x - l,
                        g = n.y - p,
                        b = n.x + v,
                        m = n.y + y,
                        w = a.A,
                        O = w.x + (_ - w.x) / (1 - i),
                        x = w.y + (g - w.y) / (1 - i),
                        M = w.x + (b - w.x) / i,
                        j = w.y + (m - w.y) / i,
                        k = {
                            x: t.x + (O - t.x) / i,
                            y: t.y + (x - t.y) / i
                        },
                        P = {
                            x: r.x + (M - r.x) / (1 - i),
                            y: r.y + (j - r.y) / (1 - i)
                        };
                    return new d(t, k, P, r)
                };
                var v = function() {
                    return h
                };
                d.getUtils = v, d.prototype = {
                    getUtils: v,
                    valueOf: function() {
                        return this.toString()
                    },
                    toString: function() {
                        return h.pointsToString(this.points)
                    },
                    toSVG: function(t) {
                        if (this._3d) return !1;
                        for (var e = this.points, n = ["M", e[0].x, e[0].y, 2 === this.order ? "Q" : "C"], r = 1, i = e.length; r < i; r++) n.push(e[r].x), n.push(e[r].y);
                        return n.join(" ")
                    },
                    update: function() {
                        this.dpoints = [];
                        for (var t = this.points, e = t.length, n = e - 1; e > 1; e--, n--) {
                            for (var r, i = [], o = 0; o < n; o++) r = {
                                x: n * (t[o + 1].x - t[o].x),
                                y: n * (t[o + 1].y - t[o].y)
                            }, this._3d && (r.z = n * (t[o + 1].z - t[o].z)), i.push(r);
                            this.dpoints.push(i), t = i
                        }
                        this.computedirection()
                    },
                    computedirection: function() {
                        var t = this.points,
                            e = h.angle(t[0], t[this.order], t[1]);
                        this.clockwise = e > 0
                    },
                    length: function() {
                        return h.length(this.derivative.bind(this))
                    },
                    _lut: [],
                    getLUT: function(t) {
                        if (t = t || 100, this._lut.length === t) return this._lut;
                        this._lut = [];
                        for (var e = 0; e <= t; e++) this._lut.push(this.compute(e / t));
                        return this._lut
                    },
                    on: function(t, e) {
                        e = e || 5;
                        for (var n, r = this.getLUT(), i = [], o = 0, a = 0; a < r.length; a++) n = r[a], h.dist(n, t) < e && (i.push(n), o += a / r.length);
                        return !!i.length && (o /= i.length)
                    },
                    project: function(t) {
                        var e = this.getLUT(),
                            n = e.length - 1,
                            r = h.closest(e, t),
                            i = r.mdist,
                            o = r.mpos;
                        if (0 === o || o === n) {
                            var a = o / n,
                                u = this.compute(a);
                            return u.t = a, u.d = i, u
                        }
                        var c, f, s, l = (o + 1) / n,
                            p = .1 / n;
                        for (i += 1, c = a = (o - 1) / n; a < l + p; a += p) f = this.compute(a), (s = h.dist(t, f)) < i && (i = s, c = a);
                        return f = this.compute(c), f.t = c, f.d = i, f
                    },
                    get: function(t) {
                        return this.compute(t)
                    },
                    point: function(t) {
                        return this.points[t]
                    },
                    compute: function(t) {
                        if (0 === t) return this.points[0];
                        if (1 === t) return this.points[this.order];
                        var e = this.points,
                            n = 1 - t;
                        if (1 === this.order) return f = {
                            x: n * e[0].x + t * e[1].x,
                            y: n * e[0].y + t * e[1].y
                        }, this._3d && (f.z = n * e[0].z + t * e[1].z), f;
                        if (this.order < 4) {
                            var r, i, o, a = n * n,
                                u = t * t,
                                c = 0;
                            2 === this.order ? (e = [e[0], e[1], e[2], l], r = a, i = n * t * 2, o = u) : 3 === this.order && (r = a * n, i = a * t * 3, o = n * u * 3, c = t * u);
                            var f = {
                                x: r * e[0].x + i * e[1].x + o * e[2].x + c * e[3].x,
                                y: r * e[0].y + i * e[1].y + o * e[2].y + c * e[3].y
                            };
                            return this._3d && (f.z = r * e[0].z + i * e[1].z + o * e[2].z + c * e[3].z), f
                        }
                        for (var s = JSON.parse(JSON.stringify(this.points)); s.length > 1;) {
                            for (var h = 0; h < s.length - 1; h++) s[h] = {
                                x: s[h].x + (s[h + 1].x - s[h].x) * t,
                                y: s[h].y + (s[h + 1].y - s[h].y) * t
                            }, void 0 !== s[h].z && (s[h] = s[h].z + (s[h + 1].z - s[h].z) * t);
                            s.splice(s.length - 1, 1)
                        }
                        return s[0]
                    },
                    raise: function() {
                        for (var t, e, n = this.points, r = [n[0]], i = n.length, o = 1; o < i; o++) t = n[o], e = n[o - 1], r[o] = {
                            x: (i - o) / i * t.x + o / i * e.x,
                            y: (i - o) / i * t.y + o / i * e.y
                        };
                        return r[i] = n[i - 1], new d(r)
                    },
                    derivative: function(t) {
                        var e, n, r = 1 - t,
                            i = 0,
                            o = this.dpoints[0];
                        2 === this.order && (o = [o[0], o[1], l], e = r, n = t), 3 === this.order && (e = r * r, n = r * t * 2, i = t * t);
                        var a = {
                            x: e * o[0].x + n * o[1].x + i * o[2].x,
                            y: e * o[0].y + n * o[1].y + i * o[2].y
                        };
                        return this._3d && (a.z = e * o[0].z + n * o[1].z + i * o[2].z), a
                    },
                    inflections: function() {
                        return h.inflections(this.points)
                    },
                    normal: function(t) {
                        return this._3d ? this.__normal3(t) : this.__normal2(t)
                    },
                    __normal2: function(t) {
                        var e = this.derivative(t),
                            n = f(e.x * e.x + e.y * e.y);
                        return {
                            x: -e.y / n,
                            y: e.x / n
                        }
                    },
                    __normal3: function(t) {
                        var e = this.derivative(t),
                            n = this.derivative(t + .01),
                            r = f(e.x * e.x + e.y * e.y + e.z * e.z),
                            i = f(n.x * n.x + n.y * n.y + n.z * n.z);
                        e.x /= r, e.y /= r, e.z /= r, n.x /= i, n.y /= i, n.z /= i;
                        var o = {
                                x: n.y * e.z - n.z * e.y,
                                y: n.z * e.x - n.x * e.z,
                                z: n.x * e.y - n.y * e.x
                            },
                            a = f(o.x * o.x + o.y * o.y + o.z * o.z);
                        o.x /= a, o.y /= a, o.z /= a;
                        var u = [o.x * o.x, o.x * o.y - o.z, o.x * o.z + o.y, o.x * o.y + o.z, o.y * o.y, o.y * o.z - o.x, o.x * o.z - o.y, o.y * o.z + o.x, o.z * o.z];
                        return {
                            x: u[0] * e.x + u[1] * e.y + u[2] * e.z,
                            y: u[3] * e.x + u[4] * e.y + u[5] * e.z,
                            z: u[6] * e.x + u[7] * e.y + u[8] * e.z
                        }
                    },
                    hull: function(t) {
                        var e, n = this.points,
                            r = [],
                            i = [],
                            o = 0,
                            a = 0,
                            u = 0;
                        for (i[o++] = n[0], i[o++] = n[1], i[o++] = n[2], 3 === this.order && (i[o++] = n[3]); n.length > 1;) {
                            for (r = [], a = 0, u = n.length - 1; a < u; a++) e = h.lerp(t, n[a], n[a + 1]), i[o++] = e, r.push(e);
                            n = r
                        }
                        return i
                    },
                    split: function(t, e) {
                        if (0 === t && e) return this.split(e).left;
                        if (1 === e) return this.split(t).right;
                        var n = this.hull(t),
                            r = {
                                left: 2 === this.order ? new d([n[0], n[3], n[5]]) : new d([n[0], n[4], n[7], n[9]]),
                                right: 2 === this.order ? new d([n[5], n[4], n[2]]) : new d([n[9], n[8], n[6], n[3]]),
                                span: n
                            };
                        if (r.left._t1 = h.map(0, 0, 1, this._t1, this._t2), r.left._t2 = h.map(t, 0, 1, this._t1, this._t2), r.right._t1 = h.map(t, 0, 1, this._t1, this._t2), r.right._t2 = h.map(1, 0, 1, this._t1, this._t2), !e) return r;
                        e = h.map(e, t, 1, 0, 1);
                        return r.right.split(e).left
                    },
                    extrema: function() {
                        var t, e, n = {},
                            r = [];
                        return this.dims.forEach(function(i) {
                            e = function(t) {
                                return t[i]
                            }, t = this.dpoints[0].map(e), n[i] = h.droots(t), 3 === this.order && (t = this.dpoints[1].map(e), n[i] = n[i].concat(h.droots(t))), n[i] = n[i].filter(function(t) {
                                return t >= 0 && t <= 1
                            }), r = r.concat(n[i].sort())
                        }.bind(this)), r = r.sort().filter(function(t, e) {
                            return r.indexOf(t) === e
                        }), n.values = r, n
                    },
                    bbox: function() {
                        var t = this.extrema(),
                            e = {};
                        return this.dims.forEach(function(n) {
                            e[n] = h.getminmax(this, n, t[n])
                        }.bind(this)), e
                    },
                    overlaps: function(t) {
                        var e = this.bbox(),
                            n = t.bbox();
                        return h.bboxoverlap(e, n)
                    },
                    offset: function(t, e) {
                        if (void 0 !== e) {
                            var n = this.get(t),
                                r = this.normal(t),
                                i = {
                                    c: n,
                                    n: r,
                                    x: n.x + r.x * e,
                                    y: n.y + r.y * e
                                };
                            return this._3d && (i.z = n.z + r.z * e), i
                        }
                        if (this._linear) {
                            var o = this.normal(0),
                                a = this.points.map(function(e) {
                                    var n = {
                                        x: e.x + t * o.x,
                                        y: e.y + t * o.y
                                    };
                                    return e.z && r.z && (n.z = e.z + t * o.z), n
                                });
                            return [new d(a)]
                        }
                        return this.reduce().map(function(e) {
                            return e.scale(t)
                        })
                    },
                    simple: function() {
                        if (3 === this.order) {
                            var t = h.angle(this.points[0], this.points[3], this.points[1]),
                                e = h.angle(this.points[0], this.points[3], this.points[2]);
                            if (t > 0 && e < 0 || t < 0 && e > 0) return !1
                        }
                        var n = this.normal(0),
                            i = this.normal(1),
                            o = n.x * i.x + n.y * i.y;
                        this._3d && (o += n.z * i.z);
                        return r(c(o)) < s / 3
                    },
                    reduce: function() {
                        var t, e, n = 0,
                            i = 0,
                            o = [],
                            a = [],
                            u = this.extrema().values;
                        for (-1 === u.indexOf(0) && (u = [0].concat(u)), -1 === u.indexOf(1) && u.push(1), n = u[0], t = 1; t < u.length; t++) i = u[t], (e = this.split(n, i))._t1 = n, e._t2 = i, o.push(e), n = i;
                        return o.forEach(function(t) {
                            for (n = 0, i = 0; i <= 1;)
                                for (i = n + .01; i <= 1.01; i += .01)
                                    if (!(e = t.split(n, i)).simple()) {
                                        if (i -= .01, r(n - i) < .01) return [];
                                        (e = t.split(n, i))._t1 = h.map(n, 0, 1, t._t1, t._t2), e._t2 = h.map(i, 0, 1, t._t1, t._t2), a.push(e), n = i;
                                        break
                                    }
                            n < 1 && ((e = t.split(n, 1))._t1 = h.map(n, 0, 1, t._t1, t._t2), e._t2 = t._t2, a.push(e))
                        }), a
                    },
                    scale: function(t) {
                        var e = this.order,
                            n = !1;
                        if ("function" == typeof t && (n = t), n && 2 === e) return this.raise().scale(n);
                        var r = this.clockwise,
                            i = n ? n(0) : t,
                            o = n ? n(1) : t,
                            a = [this.offset(0, 10), this.offset(1, 10)],
                            u = h.lli4(a[0], a[0].c, a[1], a[1].c);
                        if (!u) throw new Error("cannot scale this curve. Try reducing it first.");
                        var c = this.points,
                            s = [];
                        return [0, 1].forEach(function(t) {
                            var n = s[t * e] = h.copy(c[t * e]);
                            n.x += (t ? o : i) * a[t].n.x, n.y += (t ? o : i) * a[t].n.y
                        }.bind(this)), n ? ([0, 1].forEach(function(i) {
                            if (2 !== this.order || !i) {
                                var o = c[i + 1],
                                    a = {
                                        x: o.x - u.x,
                                        y: o.y - u.y
                                    },
                                    l = n ? n((i + 1) / e) : t;
                                n && !r && (l = -l);
                                var h = f(a.x * a.x + a.y * a.y);
                                a.x /= h, a.y /= h, s[i + 1] = {
                                    x: o.x + l * a.x,
                                    y: o.y + l * a.y
                                }
                            }
                        }.bind(this)), new d(s)) : ([0, 1].forEach(function(t) {
                            if (2 !== this.order || !t) {
                                var n = s[t * e],
                                    r = this.derivative(t),
                                    i = {
                                        x: n.x + r.x,
                                        y: n.y + r.y
                                    };
                                s[t + 1] = h.lli4(n, i, u, c[t + 1])
                            }
                        }.bind(this)), new d(s))
                    },
                    outline: function(t, e, n, r) {
                        function i(t, e, n, r, i) {
                            return function(o) {
                                var a = r / n,
                                    u = (r + i) / n,
                                    c = e - t;
                                return h.map(o, 0, 1, t + a * c, t + u * c)
                            }
                        }
                        e = void 0 === e ? t : e;
                        var o, a = this.reduce(),
                            u = a.length,
                            c = [],
                            f = [],
                            s = 0,
                            l = this.length(),
                            d = void 0 !== n && void 0 !== r;
                        a.forEach(function(o) {
                            O = o.length(), d ? (c.push(o.scale(i(t, n, l, s, O))), f.push(o.scale(i(-e, -r, l, s, O)))) : (c.push(o.scale(t)), f.push(o.scale(-e))), s += O
                        }), f = f.map(function(t) {
                            return (o = t.points)[3] ? t.points = [o[3], o[2], o[1], o[0]] : t.points = [o[2], o[1], o[0]], t
                        }).reverse();
                        var v = c[0].points[0],
                            y = c[u - 1].points[c[u - 1].points.length - 1],
                            _ = f[u - 1].points[f[u - 1].points.length - 1],
                            g = f[0].points[0],
                            b = h.makeline(_, v),
                            m = h.makeline(y, g),
                            w = [b].concat(c).concat([m]).concat(f),
                            O = w.length;
                        return new p(w)
                    },
                    outlineshapes: function(t, e, n) {
                        e = e || t;
                        for (var r = this.outline(t, e).curves, i = [], o = 1, a = r.length; o < a / 2; o++) {
                            var u = h.makeshape(r[o], r[a - o], n);
                            u.startcap.virtual = o > 1, u.endcap.virtual = o < a / 2 - 1, i.push(u)
                        }
                        return i
                    },
                    intersects: function(t, e) {
                        return t ? t.p1 && t.p2 ? this.lineIntersects(t) : (t instanceof d && (t = t.reduce()), this.curveintersects(this.reduce(), t, e)) : this.selfintersects(e)
                    },
                    lineIntersects: function(t) {
                        var e = i(t.p1.x, t.p2.x),
                            n = i(t.p1.y, t.p2.y),
                            r = o(t.p1.x, t.p2.x),
                            a = o(t.p1.y, t.p2.y),
                            u = this;
                        return h.roots(this.points, t).filter(function(t) {
                            var i = u.get(t);
                            return h.between(i.x, e, r) && h.between(i.y, n, a)
                        })
                    },
                    selfintersects: function(t) {
                        var e, n, r, i, o = this.reduce(),
                            a = o.length - 2,
                            u = [];
                        for (e = 0; e < a; e++) r = o.slice(e, e + 1), i = o.slice(e + 2), n = this.curveintersects(r, i, t), u = u.concat(n);
                        return u
                    },
                    curveintersects: function(t, e, n) {
                        var r = [];
                        t.forEach(function(t) {
                            e.forEach(function(e) {
                                t.overlaps(e) && r.push({
                                    left: t,
                                    right: e
                                })
                            })
                        });
                        var i = [];
                        return r.forEach(function(t) {
                            var e = h.pairiteration(t.left, t.right, n);
                            e.length > 0 && (i = i.concat(e))
                        }), i
                    },
                    arcs: function(t) {
                        t = t || .5;
                        return this._iterate(t, [])
                    },
                    _error: function(t, e, n, i) {
                        var o = (i - n) / 4,
                            a = this.get(n + o),
                            u = this.get(i - o),
                            c = h.dist(t, e),
                            f = h.dist(t, a),
                            s = h.dist(t, u);
                        return r(f - c) + r(s - c)
                    },
                    _iterate: function(t, e) {
                        var n, r = 0,
                            i = 1;
                        do {
                            n = 0, i = 1;
                            var o, c, f, s, l, p = this.get(r),
                                d = !1,
                                v = !1,
                                y = i,
                                _ = 1;
                            do {
                                v = d, s = f, y = (r + i) / 2, 0, o = this.get(y), c = this.get(i), (f = h.getccenter(p, o, c)).interval = {
                                    start: r,
                                    end: i
                                };
                                if (d = this._error(f, p, r, i) <= t, (l = v && !d) || (_ = i), d) {
                                    if (i >= 1) {
                                        if (f.interval.end = _ = 1, s = f, i > 1) {
                                            var g = {
                                                x: f.x + f.r * a(f.e),
                                                y: f.y + f.r * u(f.e)
                                            };
                                            f.e += h.angle({
                                                x: f.x,
                                                y: f.y
                                            }, g, this.get(1))
                                        }
                                        break
                                    }
                                    i += (i - r) / 2
                                } else i = y
                            } while (!l && n++ < 100);
                            if (n >= 100) break;
                            s = s || f, e.push(s), r = _
                        } while (i < 1);
                        return e
                    }
                }, t.exports = d
            }()
        },
        function(t, e, n) {
            ! function() {
                "use strict";
                var e = Math.abs,
                    r = Math.cos,
                    i = Math.sin,
                    o = Math.acos,
                    a = Math.atan2,
                    u = Math.sqrt,
                    c = Math.pow,
                    f = function(t) {
                        return t < 0 ? -c(-t, 1 / 3) : c(t, 1 / 3)
                    },
                    s = Math.PI,
                    l = 2 * s,
                    h = s / 2,
                    p = Number.MAX_SAFE_INTEGER,
                    d = Number.MIN_SAFE_INTEGER,
                    v = {
                        Tvalues: [-.06405689286260563, .06405689286260563, -.1911188674736163, .1911188674736163, -.3150426796961634, .3150426796961634, -.4337935076260451, .4337935076260451, -.5454214713888396, .5454214713888396, -.6480936519369755, .6480936519369755, -.7401241915785544, .7401241915785544, -.820001985973903, .820001985973903, -.8864155270044011, .8864155270044011, -.9382745520027328, .9382745520027328, -.9747285559713095, .9747285559713095, -.9951872199970213, .9951872199970213],
                        Cvalues: [.12793819534675216, .12793819534675216, .1258374563468283, .1258374563468283, .12167047292780339, .12167047292780339, .1155056680537256, .1155056680537256, .10744427011596563, .10744427011596563, .09761865210411388, .09761865210411388, .08619016153195327, .08619016153195327, .0733464814110803, .0733464814110803, .05929858491543678, .05929858491543678, .04427743881741981, .04427743881741981, .028531388628933663, .028531388628933663, .0123412297999872, .0123412297999872],
                        arcfn: function(t, e) {
                            var n = e(t),
                                r = n.x * n.x + n.y * n.y;
                            return void 0 !== n.z && (r += n.z * n.z), u(r)
                        },
                        between: function(t, e, n) {
                            return e <= t && t <= n || v.approximately(t, e) || v.approximately(t, n)
                        },
                        approximately: function(t, n, r) {
                            return e(t - n) <= (r || 1e-6)
                        },
                        length: function(t) {
                            var e, n, r = 0,
                                i = v.Tvalues.length;
                            for (e = 0; e < i; e++) n = .5 * v.Tvalues[e] + .5, r += v.Cvalues[e] * v.arcfn(n, t);
                            return .5 * r
                        },
                        map: function(t, e, n, r, i) {
                            return r + (i - r) * ((t - e) / (n - e))
                        },
                        lerp: function(t, e, n) {
                            var r = {
                                x: e.x + t * (n.x - e.x),
                                y: e.y + t * (n.y - e.y)
                            };
                            return e.z && n.z && (r.z = e.z + t * (n.z - e.z)), r
                        },
                        pointToString: function(t) {
                            var e = t.x + "/" + t.y;
                            return void 0 !== t.z && (e += "/" + t.z), e
                        },
                        pointsToString: function(t) {
                            return "[" + t.map(v.pointToString).join(", ") + "]"
                        },
                        copy: function(t) {
                            return JSON.parse(JSON.stringify(t))
                        },
                        angle: function(t, e, n) {
                            var r = e.x - t.x,
                                i = e.y - t.y,
                                o = n.x - t.x,
                                u = n.y - t.y;
                            return a(r * u - i * o, r * o + i * u)
                        },
                        round: function(t, e) {
                            var n = "" + t,
                                r = n.indexOf(".");
                            return parseFloat(n.substring(0, r + 1 + e))
                        },
                        dist: function(t, e) {
                            var n = t.x - e.x,
                                r = t.y - e.y;
                            return u(n * n + r * r)
                        },
                        closest: function(t, e) {
                            var n, r, i = c(2, 63);
                            return t.forEach(function(t, o) {
                                (r = v.dist(e, t)) < i && (i = r, n = o)
                            }), {
                                mdist: i,
                                mpos: n
                            }
                        },
                        abcratio: function(t, n) {
                            if (2 !== n && 3 !== n) return !1;
                            if (void 0 === t) t = .5;
                            else if (0 === t || 1 === t) return t;
                            var r = c(t, n) + c(1 - t, n);
                            return e((r - 1) / r)
                        },
                        projectionratio: function(t, e) {
                            if (2 !== e && 3 !== e) return !1;
                            if (void 0 === t) t = .5;
                            else if (0 === t || 1 === t) return t;
                            var n = c(1 - t, e);
                            return n / (c(t, e) + n)
                        },
                        lli8: function(t, e, n, r, i, o, a, u) {
                            var c = (t - n) * (o - u) - (e - r) * (i - a);
                            return 0 != c && {
                                x: ((t * r - e * n) * (i - a) - (t - n) * (i * u - o * a)) / c,
                                y: ((t * r - e * n) * (o - u) - (e - r) * (i * u - o * a)) / c
                            }
                        },
                        lli4: function(t, e, n, r) {
                            var i = t.x,
                                o = t.y,
                                a = e.x,
                                u = e.y,
                                c = n.x,
                                f = n.y,
                                s = r.x,
                                l = r.y;
                            return v.lli8(i, o, a, u, c, f, s, l)
                        },
                        lli: function(t, e) {
                            return v.lli4(t, t.c, e, e.c)
                        },
                        makeline: function(t, e) {
                            var r = n(60),
                                i = t.x,
                                o = t.y,
                                a = e.x,
                                u = e.y,
                                c = (a - i) / 3,
                                f = (u - o) / 3;
                            return new r(i, o, i + c, o + f, i + 2 * c, o + 2 * f, a, u)
                        },
                        findbbox: function(t) {
                            var e = p,
                                n = p,
                                r = d,
                                i = d;
                            return t.forEach(function(t) {
                                var o = t.bbox();
                                e > o.x.min && (e = o.x.min), n > o.y.min && (n = o.y.min), r < o.x.max && (r = o.x.max), i < o.y.max && (i = o.y.max)
                            }), {
                                x: {
                                    min: e,
                                    mid: (e + r) / 2,
                                    max: r,
                                    size: r - e
                                },
                                y: {
                                    min: n,
                                    mid: (n + i) / 2,
                                    max: i,
                                    size: i - n
                                }
                            }
                        },
                        shapeintersections: function(t, e, n, r, i) {
                            if (!v.bboxoverlap(e, r)) return [];
                            var o = [],
                                a = [t.startcap, t.forward, t.back, t.endcap],
                                u = [n.startcap, n.forward, n.back, n.endcap];
                            return a.forEach(function(e) {
                                e.virtual || u.forEach(function(r) {
                                    if (!r.virtual) {
                                        var a = e.intersects(r, i);
                                        a.length > 0 && (a.c1 = e, a.c2 = r, a.s1 = t, a.s2 = n, o.push(a))
                                    }
                                })
                            }), o
                        },
                        makeshape: function(t, e, n) {
                            var r = e.points.length,
                                i = t.points.length,
                                o = v.makeline(e.points[r - 1], t.points[0]),
                                a = v.makeline(t.points[i - 1], e.points[0]),
                                u = {
                                    startcap: o,
                                    forward: t,
                                    back: e,
                                    endcap: a,
                                    bbox: v.findbbox([o, t, e, a])
                                },
                                c = v;
                            return u.intersections = function(t) {
                                return c.shapeintersections(u, u.bbox, t, t.bbox, n)
                            }, u
                        },
                        getminmax: function(t, e, n) {
                            if (!n) return {
                                min: 0,
                                max: 0
                            };
                            var r, i, o = p,
                                a = d; - 1 === n.indexOf(0) && (n = [0].concat(n)), -1 === n.indexOf(1) && n.push(1);
                            for (var u = 0, c = n.length; u < c; u++) r = n[u], (i = t.get(r))[e] < o && (o = i[e]), i[e] > a && (a = i[e]);
                            return {
                                min: o,
                                mid: (o + a) / 2,
                                max: a,
                                size: a - o
                            }
                        },
                        align: function(t, e) {
                            var n = e.p1.x,
                                o = e.p1.y,
                                u = -a(e.p2.y - o, e.p2.x - n);
                            return t.map(function(t) {
                                return {
                                    x: (t.x - n) * r(u) - (t.y - o) * i(u),
                                    y: (t.x - n) * i(u) + (t.y - o) * r(u)
                                }
                            })
                        },
                        roots: function(t, e) {
                            e = e || {
                                p1: {
                                    x: 0,
                                    y: 0
                                },
                                p2: {
                                    x: 1,
                                    y: 0
                                }
                            };
                            var n = t.length - 1,
                                i = v.align(t, e),
                                a = function(t) {
                                    return 0 <= t && t <= 1
                                };
                            if (2 === n) {
                                if (0 !== (h = (p = i[0].y) - 2 * (d = i[1].y) + (y = i[2].y))) {
                                    var c = -u(d * d - p * y),
                                        s = -p + d;
                                    return [g = -(c + s) / h, -(-c + s) / h].filter(a)
                                }
                                return d !== y && 0 === h ? [(2 * d - y) / 2 * (d - y)].filter(a) : []
                            }
                            var h, p, d, y, _, g, b, m, w, O = i[0].y,
                                x = i[1].y,
                                M = i[2].y,
                                j = (i = (3 * (d = (-3 * O + 3 * x) / (h = 3 * x - O - 3 * M + i[3].y)) - (p = (3 * O - 6 * x + 3 * M) / h) * p) / 3) / 3,
                                k = (2 * p * p * p - 9 * p * d + 27 * (y = O / h)) / 27,
                                P = k / 2,
                                E = P * P + j * j * j;
                            if (E < 0) {
                                var A = -i / 3,
                                    L = u(A * A * A),
                                    C = -k / (2 * L),
                                    S = o(C < -1 ? -1 : C > 1 ? 1 : C),
                                    T = 2 * f(L);
                                return b = T * r(S / 3) - p / 3, m = T * r((S + l) / 3) - p / 3, w = T * r((S + 2 * l) / 3) - p / 3, [b, m, w].filter(a)
                            }
                            if (0 === E) return _ = P < 0 ? f(-P) : -f(P), b = 2 * _ - p / 3, m = -_ - p / 3, [b, m].filter(a);
                            var D = u(E);
                            return _ = f(-P + D), g = f(P + D), [_ - g - p / 3].filter(a)
                        },
                        droots: function(t) {
                            if (3 === t.length) {
                                var e = t[0],
                                    n = t[1],
                                    r = t[2],
                                    i = e - 2 * n + r;
                                if (0 !== i) {
                                    var o = -u(n * n - e * r),
                                        a = -e + n;
                                    return [-(o + a) / i, -(-o + a) / i]
                                }
                                return n !== r && 0 === i ? [(2 * n - r) / (2 * (n - r))] : []
                            }
                            if (2 === t.length) {
                                return (e = t[0]) !== (n = t[1]) ? [e / (e - n)] : []
                            }
                        },
                        inflections: function(t) {
                            if (t.length < 4) return [];
                            var e = v.align(t, {
                                    p1: t[0],
                                    p2: t.slice(-1)[0]
                                }),
                                n = e[2].x * e[1].y,
                                r = e[3].x * e[1].y,
                                i = e[1].x * e[2].y,
                                o = 18 * (-3 * n + 2 * r + 3 * i - (l = e[3].x * e[2].y)),
                                a = 18 * (3 * n - r - 3 * i),
                                u = 18 * (i - n);
                            if (v.approximately(o, 0)) {
                                if (!v.approximately(a, 0)) {
                                    var c = -u / a;
                                    if (0 <= c && c <= 1) return [c]
                                }
                                return []
                            }
                            var f = a * a - 4 * o * u,
                                s = Math.sqrt(f),
                                l = 2 * o;
                            return v.approximately(l, 0) ? [] : [(s - a) / l, -(a + s) / l].filter(function(t) {
                                return 0 <= t && t <= 1
                            })
                        },
                        bboxoverlap: function(t, n) {
                            var r, i, o, a, u, c = ["x", "y"],
                                f = c.length;
                            for (r = 0; r < f; r++)
                                if (i = c[r], o = t[i].mid, a = n[i].mid, u = (t[i].size + n[i].size) / 2, e(o - a) >= u) return !1;
                            return !0
                        },
                        expandbox: function(t, e) {
                            e.x.min < t.x.min && (t.x.min = e.x.min), e.y.min < t.y.min && (t.y.min = e.y.min), e.z && e.z.min < t.z.min && (t.z.min = e.z.min), e.x.max > t.x.max && (t.x.max = e.x.max), e.y.max > t.y.max && (t.y.max = e.y.max), e.z && e.z.max > t.z.max && (t.z.max = e.z.max), t.x.mid = (t.x.min + t.x.max) / 2, t.y.mid = (t.y.min + t.y.max) / 2, t.z && (t.z.mid = (t.z.min + t.z.max) / 2), t.x.size = t.x.max - t.x.min, t.y.size = t.y.max - t.y.min, t.z && (t.z.size = t.z.max - t.z.min)
                        },
                        pairiteration: function(t, e, n) {
                            var r = t.bbox(),
                                i = e.bbox(),
                                o = n || .5;
                            if (r.x.size + r.y.size < o && i.x.size + i.y.size < o) return [(1e5 * (t._t1 + t._t2) / 2 | 0) / 1e5 + "/" + (1e5 * (e._t1 + e._t2) / 2 | 0) / 1e5];
                            var a = t.split(.5),
                                u = e.split(.5),
                                c = [{
                                    left: a.left,
                                    right: u.left
                                }, {
                                    left: a.left,
                                    right: u.right
                                }, {
                                    left: a.right,
                                    right: u.right
                                }, {
                                    left: a.right,
                                    right: u.left
                                }],
                                f = [];
                            return 0 === (c = c.filter(function(t) {
                                return v.bboxoverlap(t.left.bbox(), t.right.bbox())
                            })).length ? f : (c.forEach(function(t) {
                                f = f.concat(v.pairiteration(t.left, t.right, o))
                            }), f = f.filter(function(t, e) {
                                return f.indexOf(t) === e
                            }))
                        },
                        getccenter: function(t, e, n) {
                            var o, u = e.x - t.x,
                                c = e.y - t.y,
                                f = n.x - e.x,
                                s = n.y - e.y,
                                p = u * r(h) - c * i(h),
                                d = u * i(h) + c * r(h),
                                y = f * r(h) - s * i(h),
                                _ = f * i(h) + s * r(h),
                                g = (t.x + e.x) / 2,
                                b = (t.y + e.y) / 2,
                                m = (e.x + n.x) / 2,
                                w = (e.y + n.y) / 2,
                                O = g + p,
                                x = b + d,
                                M = m + y,
                                j = w + _,
                                k = v.lli8(g, b, O, x, m, w, M, j),
                                P = v.dist(k, t),
                                E = a(t.y - k.y, t.x - k.x),
                                A = a(e.y - k.y, e.x - k.x),
                                L = a(n.y - k.y, n.x - k.x);
                            return E < L ? ((E > A || A > L) && (E += l), E > L && (o = L, L = E, E = o)) : L < A && A < E ? (o = L, L = E, E = o) : L += l, k.s = E, k.e = L, k.r = P, k
                        }
                    };
                t.exports = v
            }()
        },
        function(t, e, n) {
            var r = n(65),
                i = r.Animation,
                o = r.Clip;
            n(149), n(152), t.exports.default = {
                Animation: i,
                Clip: o
            }, t.exports.Animation = i, t.exports.Clip = o
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            e.Ev = {
                UPDATE: "update",
                START: "start",
                REPEAT: "repeat",
                REPEAT_COMPLETE: "repeatComplete",
                AFTER_UPDATE: "afterUpdate",
                COMPLETE: "complete",
                PAUSE: "pause",
                STOP: "stop",
                RESET: "reset"
            }, e.Attr = {
                DURATION: "duration",
                REPEAT: "repeat",
                DELAY: "delay",
                EASING: "easing",
                INTERVAL: "interval",
                YOYO: "yoyo",
                START: "startAt"
            }, e.Easing = {
                LINEAR: "Linear",
                QUADRATIC_IN: "QuadraticIn",
                QUADRATIC_OUT: "QuadraticOut",
                QUADRATIC_IN_OUT: "QuadraticInOut",
                CUBIC_IN: "CubicIn",
                CUBIC_OUT: "CubicOut",
                CUBIC_IN_OUT: "CubicInOut",
                QUARTIC_IN: "QuarticIn",
                QUARTIC_OUT: "QuarticOut",
                QUARTIC_IN_OUT: "QuarticInOut",
                QUINTIC_IN: "QuinticIn",
                QUINTIC_OUT: "QuinticOut",
                QUINTIC_IN_OUT: "QuinticInOut",
                SINUSOIDAL_IN: "SinusoidalIn",
                SINUSOIDAL_OUT: "SinusoidalOut",
                SINUSOIDAL_IN_OUT: "SinusoidalInOut",
                EXPONENTIAL_IN: "ExponentialIn",
                EXPONENTIAL_OUT: "ExponentialOut",
                EXPONENTIAL_IN_OUT: "ExponentialInOut",
                CIRCULAR_IN: "CircularIn",
                CIRCULAR_OUT: "CircularOut",
                CIRCULAR_IN_OUT: "CircularInOut",
                ELASTIC_IN: "ElasticIn",
                ELASTIC_OUT: "ElasticOut",
                ELASTIC_IN_OUT: "ElasticInOut",
                BACK_IN: "BackIn",
                BACK_OUT: "BackOut",
                BACK_IN_OUT: "BackInOut",
                BOUNCE_IN: "BounceIn",
                BOUNCE_OUT: "BounceOut",
                BOUNCE_IN_OUT: "BounceInOut"
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = -1,
                o = function() {
                    function t() {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t), this.__events__ = {}, this.__id__ = ++i
                    }
                    return r(t, [{
                        key: "on",
                        value: function(t, e, n) {
                            var r = this.__events__,
                                i = r[t] = r[t] || [];
                            n === this && (n = void 0);
                            for (var o = -1, a = i; ++o < a;) {
                                var u = i[o],
                                    c = u.fn,
                                    f = u.ctx;
                                if (c === e && f === n) return this
                            }
                            var s = {
                                fn: e,
                                ctx: n
                            };
                            return i.push(s), this
                        }
                    }, {
                        key: "once",
                        value: function(t, e, n) {
                            function r(n) {
                                this.off(t, r), e.call(this, n)
                            }
                            return r.listener = e, this.on(t, r, n)
                        }
                    }, {
                        key: "off",
                        value: function(t, e, n) {
                            var r = this.__events__;
                            if (!t) return this.__events__ = {}, this;
                            if (!e) return delete r[t], this;
                            var i = r[t];
                            if (i)
                                for (var o = i.length; --o >= 0;) {
                                    var a = i[o],
                                        u = a.fn;
                                    a.ctx === n && (u !== e && u !== u.listener || (i.splice(o, 1), u = function() {}))
                                }
                            return this
                        }
                    }, {
                        key: "emit",
                        value: function(t, e) {
                            var n = this.__events__[t];
                            if (n)
                                for (var r = function(t) {
                                    for (var e = -1, n = arguments.length <= 1 ? 0 : arguments.length - 1; ++e < n;) {
                                        var r = arguments.length <= e + 1 ? void 0 : arguments[e + 1];
                                        for (var i in r) r.hasOwnProperty(i) && (t[i] = r[i])
                                    }
                                    return t
                                }({}, e, {
                                    target: this,
                                    type: t
                                }), i = -1, o = n.length; ++i < o;) {
                                    var a = n[i],
                                        u = a.fn,
                                        c = a.ctx;
                                    u.call(c || this, r)
                                }
                            return this
                        }
                    }, {
                        key: "events",
                        get: function() {
                            return this.__events__
                        }
                    }, {
                        key: "id",
                        get: function() {
                            return this.__id__
                        }
                    }]), t
                }();
            e.default = o
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Clip = e.Animation = void 0;
            var i = r(n(144)),
                o = r(n(29));
            e.default = {
                Animation: i.default,
                Clip: o.default
            }, e.Animation = i.default, e.Clip = o.default
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return (t = Math.round(t)) < 0 ? 0 : t > 255 ? 255 : t
            }

            function i(t) {
                return t < 0 ? 0 : t > 1 ? 1 : t
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(150)),
                u = a.default.parseCSSColor,
                c = {
                    isColor: function(t) {
                        if ("string" == typeof t) return !!(0, a.default)(t);
                        if (Array.isArray(t)) {
                            for (var e = 0, n = t.length; e < n;) {
                                var r = t[e++];
                                if ("string" != typeof r) return !1;
                                if (!u(r)) return !1
                            }
                            return !0
                        }
                        return !1
                    },
                    toColorIncrease: function(t) {
                        return [t[0] || 0, t[1] || 0, t[2] || 0, t[3] || 0]
                    },
                    toNormal: function(t) {
                        if (Array.isArray(t)) {
                            for (var e = [], n = 0, r = t.length; n < r;) {
                                var i = t[n++];
                                if ("string" != typeof i) return null;
                                var o = u(i);
                                if (!o) return null;
                                e.push(o)
                            }
                            return e
                        }
                        return "string" == typeof t ? u(t) : null
                    },
                    toNormalArray: function(t) {
                        if (Array.isArray(t)) {
                            for (var e = [], n = 0, r = t.length; n < r;) {
                                var i = t[n++];
                                if ("string" != typeof i) return null;
                                var o = u(i);
                                if (!o) return null;
                                e.push(o)
                            }
                            return e
                        }
                        return "string" == typeof t ? [u(t)] : null
                    },
                    linearGradient: function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                            n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : c.Utils.Linear,
                            r = t.length - 1,
                            i = r * e,
                            a = i >> 0,
                            u = n;
                        return function(t, e, n) {
                            var r = o(t, 4),
                                i = r[0],
                                a = r[1],
                                c = r[2],
                                f = r[3],
                                s = o(e, 4),
                                l = s[0],
                                h = s[1],
                                p = s[2],
                                d = s[3];
                            return [u(i, l, n) >> 0, u(a, h, n) >> 0, u(c, p, n) >> 0, u(f, d, n)]
                        }(t[a], t[a + 1 > r ? r : a + 1], i - a)
                    },
                    mixColors: function(t, e) {
                        var n = this.toNormal(t);
                        if (Array.isArray(e) && n) {
                            var o = [r(n[0] + e[0] || 0), r(n[1] + e[1] || 0), r(n[2] + e[2] || 0), i(n[3] + e[3] || 0)];
                            return "rgba(" + [o[0], o[1], o[2], o[3]].join(",") + ")"
                        }
                        return t
                    },
                    toRGBA: function(t) {
                        if (t && t.length >= 3) {
                            var e = void 0 === t[3] ? 1 : t[3];
                            return "rgba(" + r(t[0]) + "," + r(t[1]) + "," + r(t[2]) + "," + i(e) + ")"
                        }
                        return "transparent"
                    },
                    Utils: {
                        Linear: function(t, e, n) {
                            return (e - t) * n + t
                        }
                    }
                };
            e.default = c
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "b", function() {
                return i
            }), n.d(e, "a", function() {
                return o
            });
            var r = Array.prototype,
                i = r.slice,
                o = r.map
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "b", function() {
                return a
            }), n.d(e, "c", function() {
                return u
            });
            var r = n(13),
                i = n(69),
                o = n.i(i.a)(r.a),
                a = o.right,
                u = o.left;
            e.a = a
        },
        function(t, e, n) {
            "use strict";
            var r = n(13);
            e.a = function(t) {
                return 1 === t.length && (t = function(t) {
                    return function(e, i) {
                        return n.i(r.a)(t(e), i)
                    }
                }(t)), {
                    left: function(e, n, r, i) {
                        for (null == r && (r = 0), null == i && (i = e.length); r < i;) {
                            var o = r + i >>> 1;
                            t(e[o], n) < 0 ? r = o + 1 : i = o
                        }
                        return r
                    },
                    right: function(e, n, r, i) {
                        for (null == r && (r = 0), null == i && (i = e.length); r < i;) {
                            var o = r + i >>> 1;
                            t(e[o], n) > 0 ? i = o : r = o + 1
                        }
                        return r
                    }
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(78);
            e.a = function(t, e) {
                var i = n.i(r.a)(t, e);
                return i ? Math.sqrt(i) : i
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n, r, i, o = t.length,
                    a = -1;
                if (null == e) {
                    for (; ++a < o;)
                        if (null != (n = t[a]) && n >= n)
                            for (r = i = n; ++a < o;) null != (n = t[a]) && (r > n && (r = n), i < n && (i = n))
                } else
                    for (; ++a < o;)
                        if (null != (n = e(t[a], a, t)) && n >= n)
                            for (r = i = n; ++a < o;) null != (n = e(t[a], a, t)) && (r > n && (r = n), i < n && (i = n)); return [r, i]
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n, r, i = t.length,
                    o = -1;
                if (null == e) {
                    for (; ++o < i;)
                        if (null != (n = t[o]) && n >= n)
                            for (r = n; ++o < i;) null != (n = t[o]) && r > n && (r = n)
                } else
                    for (; ++o < i;)
                        if (null != (n = e(t[o], o, t)) && n >= n)
                            for (r = n; ++o < i;) null != (n = e(t[o], o, t)) && r > n && (r = n); return r
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return [t, e]
            }
            e.b = r, e.a = function(t, e) {
                null == e && (e = r);
                for (var n = 0, i = t.length - 1, o = t[0], a = new Array(i < 0 ? 0 : i); n < i;) a[n] = e(o, o = t[++n]);
                return a
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e, n) {
                t = +t, e = +e, n = (i = arguments.length) < 2 ? (e = t, t = 0, 1) : i < 3 ? 1 : +n;
                for (var r = -1, i = 0 | Math.max(0, Math.ceil((e - t) / n)), o = new Array(i); ++r < i;) o[r] = t + r * n;
                return o
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return Math.ceil(Math.log(t.length) / Math.LN2) + 1
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                var r = (e - t) / Math.max(0, n),
                    u = Math.floor(Math.log(r) / Math.LN10),
                    c = r / Math.pow(10, u);
                return u >= 0 ? (c >= i ? 10 : c >= o ? 5 : c >= a ? 2 : 1) * Math.pow(10, u) : -Math.pow(10, -u) / (c >= i ? 10 : c >= o ? 5 : c >= a ? 2 : 1)
            }
            e.b = r, e.c = function(t, e, n) {
                var r = Math.abs(e - t) / Math.max(0, n),
                    u = Math.pow(10, Math.floor(Math.log(r) / Math.LN10)),
                    c = r / u;
                return c >= i ? u *= 10 : c >= o ? u *= 5 : c >= a && (u *= 2), e < t ? -u : u
            };
            var i = Math.sqrt(50),
                o = Math.sqrt(10),
                a = Math.sqrt(2);
            e.a = function(t, e, n) {
                var i, o, a, u, c = -1;
                if (e = +e, t = +t, n = +n, t === e && n > 0) return [t];
                if ((i = e < t) && (o = t, t = e, e = o), 0 === (u = r(t, e, n)) || !isFinite(u)) return [];
                if (u > 0)
                    for (t = Math.ceil(t / u), e = Math.floor(e / u), a = new Array(o = Math.ceil(e - t + 1)); ++c < o;) a[c] = (t + c) * u;
                else
                    for (t = Math.floor(t * u), e = Math.ceil(e * u), a = new Array(o = Math.ceil(t - e + 1)); ++c < o;) a[c] = (t - c) / u;
                return i && a.reverse(), a
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t.length
            }
            var i = n(72);
            e.a = function(t) {
                if (!(u = t.length)) return [];
                for (var e = -1, o = n.i(i.a)(t, r), a = new Array(o); ++e < o;)
                    for (var u, c = -1, f = a[e] = new Array(u); ++c < u;) f[c] = t[c][e];
                return a
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(15);
            e.a = function(t, e) {
                var i, o, a = t.length,
                    u = 0,
                    c = -1,
                    f = 0,
                    s = 0;
                if (null == e)
                    for (; ++c < a;) isNaN(i = n.i(r.a)(t[c])) || (s += (o = i - f) * (i - (f += o / ++u)));
                else
                    for (; ++c < a;) isNaN(i = n.i(r.a)(e(t[c], c, t))) || (s += (o = i - f) * (i - (f += o / ++u))); if (u > 1) return s / (u - 1)
            }
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "b", function() {
                return r
            }), n.d(e, "a", function() {
                return i
            });
            var r = Math.PI / 180,
                i = 180 / Math.PI
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return r
            });
            var r = Array.prototype.slice
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return function() {
                    return t
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(3),
                i = n(80),
                o = n(180),
                a = n(179),
                u = n(81),
                c = n(182),
                f = n(185),
                s = [
                    [],
                    [
                        [
                            [1, 1.5],
                            [.5, 1]
                        ]
                    ],
                    [
                        [
                            [1.5, 1],
                            [1, 1.5]
                        ]
                    ],
                    [
                        [
                            [1.5, 1],
                            [.5, 1]
                        ]
                    ],
                    [
                        [
                            [1, .5],
                            [1.5, 1]
                        ]
                    ],
                    [
                        [
                            [1, 1.5],
                            [.5, 1]
                        ],
                        [
                            [1, .5],
                            [1.5, 1]
                        ]
                    ],
                    [
                        [
                            [1, .5],
                            [1, 1.5]
                        ]
                    ],
                    [
                        [
                            [1, .5],
                            [.5, 1]
                        ]
                    ],
                    [
                        [
                            [.5, 1],
                            [1, .5]
                        ]
                    ],
                    [
                        [
                            [1, 1.5],
                            [1, .5]
                        ]
                    ],
                    [
                        [
                            [.5, 1],
                            [1, .5]
                        ],
                        [
                            [1.5, 1],
                            [1, 1.5]
                        ]
                    ],
                    [
                        [
                            [1.5, 1],
                            [1, .5]
                        ]
                    ],
                    [
                        [
                            [.5, 1],
                            [1.5, 1]
                        ]
                    ],
                    [
                        [
                            [1, 1.5],
                            [1.5, 1]
                        ]
                    ],
                    [
                        [
                            [.5, 1],
                            [1, 1.5]
                        ]
                    ],
                    []
                ];
            e.a = function() {
                function t(t) {
                    var i = v(t);
                    if (Array.isArray(i)) i = i.slice().sort(o.a);
                    else {
                        var a = n.i(r.extent)(t),
                            u = a[0],
                            c = a[1];
                        i = n.i(r.tickStep)(u, c, i), i = n.i(r.range)(Math.floor(u / i) * i, Math.floor(c / i) * i, i)
                    }
                    return i.map(function(n) {
                        return e(t, n)
                    })
                }

                function e(t, e) {
                    var r = [],
                        i = [];
                    return function(t, e, n) {
                        function r(t) {
                            var e, r, a = [t[0][0] + i, t[0][1] + o],
                                u = [t[1][0] + i, t[1][1] + o],
                                c = l(a),
                                f = l(u);
                            (e = v[c]) ? (r = h[f]) ? (delete v[e.end], delete h[r.start], e === r ? (e.ring.push(u), n(e.ring)) : h[e.start] = v[r.end] = {
                                start: e.start,
                                end: r.end,
                                ring: e.ring.concat(r.ring)
                            }) : (delete v[e.end], e.ring.push(u), v[e.end = f] = e) : (e = h[f]) ? (r = v[c]) ? (delete h[e.start], delete v[r.end], e === r ? (e.ring.push(u), n(e.ring)) : h[r.start] = v[e.end] = {
                                start: r.start,
                                end: e.end,
                                ring: r.ring.concat(e.ring)
                            }) : (delete h[e.start], e.ring.unshift(a), h[e.start = c] = e) : h[c] = v[f] = {
                                start: c,
                                end: f,
                                ring: [a, u]
                            }
                        }
                        var i, o, a, u, c, f, h = new Array,
                            v = new Array;
                        i = o = -1, u = t[0] >= e, s[u << 1].forEach(r);
                        for (; ++i < p - 1;) a = u, u = t[i + 1] >= e, s[a | u << 1].forEach(r);
                        s[u << 0].forEach(r);
                        for (; ++o < d - 1;) {
                            for (i = -1, u = t[o * p + p] >= e, c = t[o * p] >= e, s[u << 1 | c << 2].forEach(r); ++i < p - 1;) a = u, u = t[o * p + p + i + 1] >= e, f = c, c = t[o * p + i + 1] >= e, s[a | u << 1 | c << 2 | f << 3].forEach(r);
                            s[u | c << 3].forEach(r)
                        }
                        i = -1, c = t[o * p] >= e, s[c << 2].forEach(r);
                        for (; ++i < p - 1;) f = c, c = t[o * p + i + 1] >= e, s[c << 2 | f << 3].forEach(r);
                        s[c << 3].forEach(r)
                    }(t, e, function(o) {
                        y(o, t, e), n.i(a.a)(o) > 0 ? r.push([o]) : i.push(o)
                    }), i.forEach(function(t) {
                        for (var e, i = 0, o = r.length; i < o; ++i)
                            if (-1 !== n.i(c.a)((e = r[i])[0], t)) return void e.push(t)
                    }), {
                        type: "MultiPolygon",
                        value: e,
                        coordinates: r
                    }
                }

                function l(t) {
                    return 2 * t[0] + t[1] * (p + 1) * 4
                }

                function h(t, e, n) {
                    t.forEach(function(t) {
                        var r, i = t[0],
                            o = t[1],
                            a = 0 | i,
                            u = 0 | o,
                            c = e[u * p + a];
                        i > 0 && i < p && a === i && (r = e[u * p + a - 1], t[0] = i + (n - r) / (c - r) - .5), o > 0 && o < d && u === o && (r = e[(u - 1) * p + a], t[1] = o + (n - r) / (c - r) - .5)
                    })
                }
                var p = 1,
                    d = 1,
                    v = r.thresholdSturges,
                    y = h;
                return t.contour = e, t.size = function(e) {
                    if (!arguments.length) return [p, d];
                    var n = Math.ceil(e[0]),
                        r = Math.ceil(e[1]);
                    if (!(n > 0 && r > 0)) throw new Error("invalid size");
                    return p = n, d = r, t
                }, t.thresholds = function(e) {
                    return arguments.length ? (v = "function" == typeof e ? e : Array.isArray(e) ? n.i(u.a)(i.a.call(e)) : n.i(u.a)(e), t) : v
                }, t.smooth = function(e) {
                    return arguments.length ? (y = e ? h : f.a, t) : y === h
                }, t
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(189);
            n.d(e, "f", function() {
                return r.a
            }), n.d(e, "c", function() {
                return r.b
            });
            n(87);
            var i = n(85);
            n.d(e, "a", function() {
                return i.a
            });
            var o = n(195);
            n.d(e, "e", function() {
                return o.a
            });
            var a = n(196);
            n.d(e, "b", function() {
                return a.a
            });
            var u = n(197);
            n.d(e, "d", function() {
                return u.a
            })
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "b", function() {
                return r
            });
            var r, i = n(35);
            e.a = function(t, e) {
                var o = n.i(i.a)(t, e);
                if (!o) return t + "";
                var a = o[0],
                    u = o[1],
                    c = u - (r = 3 * Math.max(-8, Math.min(8, Math.floor(u / 3)))) + 1,
                    f = a.length;
                return c === f ? a : c > f ? a + new Array(c - f + 1).join("0") : c > 0 ? a.slice(0, c) + "." + a.slice(c) : "0." + new Array(1 - c).join("0") + n.i(i.a)(t, Math.max(0, e + c - 1))[0]
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return new i(t)
            }

            function i(t) {
                if (!(e = a.exec(t))) throw new Error("invalid format: " + t);
                var e, n = e[1] || " ",
                    r = e[2] || ">",
                    i = e[3] || "-",
                    u = e[4] || "",
                    c = !!e[5],
                    f = e[6] && +e[6],
                    s = !!e[7],
                    l = e[8] && +e[8].slice(1),
                    h = e[9] || "";
                "n" === h ? (s = !0, h = "g") : o.a[h] || (h = ""), (c || "0" === n && "=" === r) && (c = !0, n = "0", r = "="), this.fill = n, this.align = r, this.sign = i, this.symbol = u, this.zero = c, this.width = f, this.comma = s, this.precision = l, this.type = h
            }
            e.a = r;
            var o = n(86),
                a = /^(?:(.)?([<>=^]))?([+\-\( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?([a-z%])?$/i;
            r.prototype = i.prototype, i.prototype.toString = function() {
                return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (null == this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (null == this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + this.type
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(190),
                i = n(84),
                o = n(193);
            e.a = {
                "": r.a,
                "%": function(t, e) {
                    return (100 * t).toFixed(e)
                },
                b: function(t) {
                    return Math.round(t).toString(2)
                },
                c: function(t) {
                    return t + ""
                },
                d: function(t) {
                    return Math.round(t).toString(10)
                },
                e: function(t, e) {
                    return t.toExponential(e)
                },
                f: function(t, e) {
                    return t.toFixed(e)
                },
                g: function(t, e) {
                    return t.toPrecision(e)
                },
                o: function(t) {
                    return Math.round(t).toString(8)
                },
                p: function(t, e) {
                    return n.i(o.a)(100 * t, e)
                },
                r: o.a,
                s: i.a,
                X: function(t) {
                    return Math.round(t).toString(16).toUpperCase()
                },
                x: function(t) {
                    return Math.round(t).toString(16)
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(19),
                i = n(191),
                o = n(192),
                a = n(85),
                u = n(86),
                c = n(84),
                f = n(194),
                s = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
            e.a = function(t) {
                function e(t) {
                    function e(t) {
                        var e, n, a, u = w,
                            f = O;
                        if ("c" === m) f = x(t) + f, t = "";
                        else {
                            var h = (t = +t) < 0;
                            if (t = x(Math.abs(t), b), h && 0 == +t && (h = !1), u = (h ? "(" === o ? o : "-" : "-" === o || "(" === o ? "" : o) + u, f = f + ("s" === m ? s[8 + c.b / 3] : "") + (h && "(" === o ? ")" : ""), M)
                                for (e = -1, n = t.length; ++e < n;)
                                    if (48 > (a = t.charCodeAt(e)) || a > 57) {
                                        f = (46 === a ? p + t.slice(e + 1) : t.slice(e)) + f, t = t.slice(0, e);
                                        break
                                    }
                        }
                        g && !y && (t = l(t, 1 / 0));
                        var v = u.length + t.length + f.length,
                            j = v < _ ? new Array(_ - v + 1).join(r) : "";
                        switch (g && y && (t = l(j + t, j.length ? _ - f.length : 1 / 0), j = ""), i) {
                            case "<":
                                t = u + t + f + j;
                                break;
                            case "=":
                                t = u + j + t + f;
                                break;
                            case "^":
                                t = j.slice(0, v = j.length >> 1) + u + t + f + j.slice(v);
                                break;
                            default:
                                t = j + u + t + f
                        }
                        return d(t)
                    }
                    var r = (t = n.i(a.a)(t)).fill,
                        i = t.align,
                        o = t.sign,
                        f = t.symbol,
                        y = t.zero,
                        _ = t.width,
                        g = t.comma,
                        b = t.precision,
                        m = t.type,
                        w = "$" === f ? h[0] : "#" === f && /[boxX]/.test(m) ? "0" + m.toLowerCase() : "",
                        O = "$" === f ? h[1] : /[%p]/.test(m) ? v : "",
                        x = u.a[m],
                        M = !m || /[defgprs%]/.test(m);
                    return b = null == b ? m ? 6 : 12 : /[gprs]/.test(m) ? Math.max(1, Math.min(21, b)) : Math.max(0, Math.min(20, b)), e.toString = function() {
                        return t + ""
                    }, e
                }
                var l = t.grouping && t.thousands ? n.i(i.a)(t.grouping, t.thousands) : f.a,
                    h = t.currency,
                    p = t.decimal,
                    d = t.numerals ? n.i(o.a)(t.numerals) : f.a,
                    v = t.percent || "%";
                return {
                    format: e,
                    formatPrefix: function(t, i) {
                        var o = e((t = n.i(a.a)(t), t.type = "f", t)),
                            u = 3 * Math.max(-8, Math.min(8, Math.floor(n.i(r.a)(i) / 3))),
                            c = Math.pow(10, -u),
                            f = s[8 + u / 3];
                        return function(t) {
                            return o(c * t) + f
                        }
                    }
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(37);
            e.a = function(t, e) {
                var i, o = e ? e.length : 0,
                    a = t ? Math.min(o, t.length) : 0,
                    u = new Array(o),
                    c = new Array(o);
                for (i = 0; i < a; ++i) u[i] = n.i(r.a)(t[i], e[i]);
                for (; i < o; ++i) c[i] = e[i];
                return function(t) {
                    for (i = 0; i < a; ++i) c[i] = u[i](t);
                    return c
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(36);
            e.a = function(t) {
                var e = t.length;
                return function(i) {
                    var o = Math.floor(((i %= 1) < 0 ? ++i : i) * e),
                        a = t[(o + e - 1) % e],
                        u = t[o % e],
                        c = t[(o + 1) % e],
                        f = t[(o + 2) % e];
                    return n.i(r.b)((i - o / e) * e, a, u, c, f)
                }
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return function() {
                    return t
                }
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n = new Date;
                return t = +t, e -= t,
                    function(r) {
                        return n.setTime(t + e * r), n
                    }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(37);
            e.a = function(t, e) {
                var i, o = {},
                    a = {};
                null !== t && "object" == typeof t || (t = {}), null !== e && "object" == typeof e || (e = {});
                for (i in e) i in t ? o[i] = n.i(r.a)(t[i], e[i]) : a[i] = e[i];
                return function(t) {
                    for (i in o) a[i] = o[i](t);
                    return a
                }
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return function(e) {
                    var r, o, a = e.length,
                        u = new Array(a),
                        c = new Array(a),
                        f = new Array(a);
                    for (r = 0; r < a; ++r) o = n.i(i.e)(e[r]), u[r] = o.r || 0, c[r] = o.g || 0, f[r] = o.b || 0;
                    return u = t(u), c = t(c), f = t(f), o.opacity = 1,
                        function(t) {
                            return o.r = u(t), o.g = c(t), o.b = f(t), o + ""
                        }
                }
            }
            n.d(e, "b", function() {
                return c
            }), n.d(e, "c", function() {
                return f
            });
            var i = n(9),
                o = n(36),
                a = n(89),
                u = n(16);
            e.a = function t(e) {
                function r(t, e) {
                    var r = o((t = n.i(i.e)(t)).r, (e = n.i(i.e)(e)).r),
                        a = o(t.g, e.g),
                        c = o(t.b, e.b),
                        f = n.i(u.a)(t.opacity, e.opacity);
                    return function(e) {
                        return t.r = r(e), t.g = a(e), t.b = c(e), t.opacity = f(e), t + ""
                    }
                }
                var o = n.i(u.c)(e);
                return r.gamma = t, r
            }(1);
            var c = r(o.a),
                f = r(a.a)
        },
        function(t, e, n) {
            "use strict";
            var r = n(20),
                i = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
                o = new RegExp(i.source, "g");
            e.a = function(t, e) {
                var a, u, c, f = i.lastIndex = o.lastIndex = 0,
                    s = -1,
                    l = [],
                    h = [];
                for (t += "", e += "";
                    (a = i.exec(t)) && (u = o.exec(e));)(c = u.index) > f && (c = e.slice(f, c), l[s] ? l[s] += c : l[++s] = c), (a = a[0]) === (u = u[0]) ? l[s] ? l[s] += u : l[++s] = u : (l[++s] = null, h.push({
                    i: s,
                    x: n.i(r.a)(a, u)
                })), f = o.lastIndex;
                return f < e.length && (c = e.slice(f), l[s] ? l[s] += c : l[++s] = c), l.length < 2 ? h[0] ? function(t) {
                    return function(e) {
                        return t(e) + ""
                    }
                }(h[0].x) : function(t) {
                    return function() {
                        return t
                    }
                }(e) : (e = h.length, function(t) {
                    for (var n, r = 0; r < e; ++r) l[(n = h[r]).i] = n.x(t);
                    return l.join("")
                })
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n, r = 0,
                    i = (t = t.slice()).length - 1,
                    o = t[r],
                    a = t[i];
                return a < o && (n = r, r = i, i = n, n = o, o = a, a = n), t[r] = e.floor(o), t[i] = e.ceil(a), t
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return +t
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                function e(e) {
                    var n = e + "",
                        r = u.get(n);
                    if (!r) {
                        if (f !== a) return f;
                        u.set(n, r = c.push(e))
                    }
                    return t[(r - 1) % t.length]
                }
                var u = n.i(i.a)(),
                    c = [],
                    f = a;
                return t = null == t ? [] : o.b.call(t), e.domain = function(t) {
                    if (!arguments.length) return c.slice();
                    c = [], u = n.i(i.a)();
                    for (var r, o, a = -1, f = t.length; ++a < f;) u.has(o = (r = t[a]) + "") || u.set(o, c.push(r));
                    return e
                }, e.range = function(n) {
                    return arguments.length ? (t = o.b.call(n), e) : t.slice()
                }, e.unknown = function(t) {
                    return arguments.length ? (f = t, e) : f
                }, e.copy = function() {
                    return r().domain(c).range(t).unknown(f)
                }, e
            }
            n.d(e, "b", function() {
                return a
            }), e.a = r;
            var i = n(171),
                o = n(11),
                a = {
                    name: "implicit"
                }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return new Date(t)
            }

            function i(t) {
                return t instanceof Date ? +t : +new Date(+t)
            }

            function o(t, e, c, f, m, w, O, x, M) {
                function j(n) {
                    return (O(n) < n ? L : w(n) < n ? C : m(n) < n ? S : f(n) < n ? T : e(n) < n ? c(n) < n ? D : I : t(n) < n ? R : N)(n)
                }

                function k(e, r, i, o) {
                    if (null == e && (e = 10), "number" == typeof e) {
                        var u = Math.abs(i - r) / e,
                            c = n.i(a.bisector)(function(t) {
                                return t[2]
                            }).right(z, u);
                        c === z.length ? (o = n.i(a.tickStep)(r / b, i / b, e), e = t) : c ? (o = (c = z[u / z[c - 1][2] < z[c][2] / u ? c - 1 : c])[1], e = c[0]) : (o = Math.max(n.i(a.tickStep)(r, i, e), 1), e = x)
                    }
                    return null == o ? e : e.every(o)
                }
                var P = n.i(l.a)(l.b, u.interpolateNumber),
                    E = P.invert,
                    A = P.domain,
                    L = M(".%L"),
                    C = M(":%S"),
                    S = M("%I:%M"),
                    T = M("%I %p"),
                    D = M("%a %d"),
                    I = M("%b %d"),
                    R = M("%B"),
                    N = M("%Y"),
                    z = [
                        [O, 1, p],
                        [O, 5, 5 * p],
                        [O, 15, 15 * p],
                        [O, 30, 30 * p],
                        [w, 1, d],
                        [w, 5, 5 * d],
                        [w, 15, 15 * d],
                        [w, 30, 30 * d],
                        [m, 1, v],
                        [m, 3, 3 * v],
                        [m, 6, 6 * v],
                        [m, 12, 12 * v],
                        [f, 1, y],
                        [f, 2, 2 * y],
                        [c, 1, _],
                        [e, 1, g],
                        [e, 3, 3 * g],
                        [t, 1, b]
                    ];
                return P.invert = function(t) {
                    return new Date(E(t))
                }, P.domain = function(t) {
                    return arguments.length ? A(s.a.call(t, i)) : A().map(r)
                }, P.ticks = function(t, e) {
                    var n, r = A(),
                        i = r[0],
                        o = r[r.length - 1],
                        a = o < i;
                    return a && (n = i, i = o, o = n), n = k(t, i, o, e), n = n ? n.range(i, o + 1) : [], a ? n.reverse() : n
                }, P.tickFormat = function(t, e) {
                    return null == e ? j : M(e)
                }, P.nice = function(t, e) {
                    var r = A();
                    return (t = k(t, r[0], r[r.length - 1], e)) ? A(n.i(h.a)(r, t)) : P
                }, P.copy = function() {
                    return n.i(l.c)(P, o(t, e, c, f, m, w, O, x, M))
                }, P
            }
            e.b = o;
            var a = n(3),
                u = n(14),
                c = n(40),
                f = n(99),
                s = n(11),
                l = n(21),
                h = n(95),
                p = 1e3,
                d = 60 * p,
                v = 60 * d,
                y = 24 * v,
                _ = 7 * y,
                g = 30 * y,
                b = 365 * y;
            e.a = function() {
                return o(c.l, c.q, c.r, c.k, c.s, c.t, c.u, c.v, f.b).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)])
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(39);
            n.d(e, "b", function() {
                return r.c
            }), n.d(e, "a", function() {
                return r.a
            });
            n(101), n(100), n(226)
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return i
            });
            var r = n(39),
                i = "%Y-%m-%dT%H:%M:%S.%LZ";
            Date.prototype.toISOString || n.i(r.a)(i)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                if (0 <= t.y && t.y < 100) {
                    var e = new Date(-1, t.m, t.d, t.H, t.M, t.S, t.L);
                    return e.setFullYear(t.y), e
                }
                return new Date(t.y, t.m, t.d, t.H, t.M, t.S, t.L)
            }

            function i(t) {
                if (0 <= t.y && t.y < 100) {
                    var e = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
                    return e.setUTCFullYear(t.y), e
                }
                return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L))
            }

            function o(t) {
                return {
                    y: t,
                    m: 0,
                    d: 1,
                    H: 0,
                    M: 0,
                    S: 0,
                    L: 0
                }
            }

            function a(t, e, n) {
                var r = t < 0 ? "-" : "",
                    i = (r ? -t : t) + "",
                    o = i.length;
                return r + (o < n ? new Array(n - o + 1).join(e) + i : i)
            }

            function u(t) {
                return t.replace(yt, "\\$&")
            }

            function c(t) {
                return new RegExp("^(?:" + t.map(u).join("|") + ")", "i")
            }

            function f(t) {
                for (var e = {}, n = -1, r = t.length; ++n < r;) e[t[n].toLowerCase()] = n;
                return e
            }

            function s(t, e, n) {
                var r = dt.exec(e.slice(n, n + 1));
                return r ? (t.w = +r[0], n + r[0].length) : -1
            }

            function l(t, e, n) {
                var r = dt.exec(e.slice(n, n + 1));
                return r ? (t.u = +r[0], n + r[0].length) : -1
            }

            function h(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.U = +r[0], n + r[0].length) : -1
            }

            function p(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.V = +r[0], n + r[0].length) : -1
            }

            function d(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.W = +r[0], n + r[0].length) : -1
            }

            function v(t, e, n) {
                var r = dt.exec(e.slice(n, n + 4));
                return r ? (t.y = +r[0], n + r[0].length) : -1
            }

            function y(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1
            }

            function _(t, e, n) {
                var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n, n + 6));
                return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1
            }

            function g(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.m = r[0] - 1, n + r[0].length) : -1
            }

            function b(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.d = +r[0], n + r[0].length) : -1
            }

            function m(t, e, n) {
                var r = dt.exec(e.slice(n, n + 3));
                return r ? (t.m = 0, t.d = +r[0], n + r[0].length) : -1
            }

            function w(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.H = +r[0], n + r[0].length) : -1
            }

            function O(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.M = +r[0], n + r[0].length) : -1
            }

            function x(t, e, n) {
                var r = dt.exec(e.slice(n, n + 2));
                return r ? (t.S = +r[0], n + r[0].length) : -1
            }

            function M(t, e, n) {
                var r = dt.exec(e.slice(n, n + 3));
                return r ? (t.L = +r[0], n + r[0].length) : -1
            }

            function j(t, e, n) {
                var r = dt.exec(e.slice(n, n + 6));
                return r ? (t.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1
            }

            function k(t, e, n) {
                var r = vt.exec(e.slice(n, n + 1));
                return r ? n + r[0].length : -1
            }

            function P(t, e, n) {
                var r = dt.exec(e.slice(n));
                return r ? (t.Q = +r[0], n + r[0].length) : -1
            }

            function E(t, e, n) {
                var r = dt.exec(e.slice(n));
                return r ? (t.Q = 1e3 * +r[0], n + r[0].length) : -1
            }

            function A(t, e) {
                return a(t.getDate(), e, 2)
            }

            function L(t, e) {
                return a(t.getHours(), e, 2)
            }

            function C(t, e) {
                return a(t.getHours() % 12 || 12, e, 2)
            }

            function S(t, e) {
                return a(1 + ht.k.count(n.i(ht.l)(t), t), e, 3)
            }

            function T(t, e) {
                return a(t.getMilliseconds(), e, 3)
            }

            function D(t, e) {
                return T(t, e) + "000"
            }

            function I(t, e) {
                return a(t.getMonth() + 1, e, 2)
            }

            function R(t, e) {
                return a(t.getMinutes(), e, 2)
            }

            function N(t, e) {
                return a(t.getSeconds(), e, 2)
            }

            function z(t) {
                var e = t.getDay();
                return 0 === e ? 7 : e
            }

            function F(t, e) {
                return a(ht.m.count(n.i(ht.l)(t), t), e, 2)
            }

            function U(t, e) {
                var r = t.getDay();
                return t = r >= 4 || 0 === r ? n.i(ht.n)(t) : ht.n.ceil(t), a(ht.n.count(n.i(ht.l)(t), t) + (4 === n.i(ht.l)(t).getDay()), e, 2)
            }

            function B(t) {
                return t.getDay()
            }

            function q(t, e) {
                return a(ht.j.count(n.i(ht.l)(t), t), e, 2)
            }

            function G(t, e) {
                return a(t.getFullYear() % 100, e, 2)
            }

            function V(t, e) {
                return a(t.getFullYear() % 1e4, e, 4)
            }

            function Y(t) {
                var e = t.getTimezoneOffset();
                return (e > 0 ? "-" : (e *= -1, "+")) + a(e / 60 | 0, "0", 2) + a(e % 60, "0", 2)
            }

            function W(t, e) {
                return a(t.getUTCDate(), e, 2)
            }

            function H(t, e) {
                return a(t.getUTCHours(), e, 2)
            }

            function Z(t, e) {
                return a(t.getUTCHours() % 12 || 12, e, 2)
            }

            function X(t, e) {
                return a(1 + ht.d.count(n.i(ht.a)(t), t), e, 3)
            }

            function Q(t, e) {
                return a(t.getUTCMilliseconds(), e, 3)
            }

            function $(t, e) {
                return Q(t, e) + "000"
            }

            function K(t, e) {
                return a(t.getUTCMonth() + 1, e, 2)
            }

            function J(t, e) {
                return a(t.getUTCMinutes(), e, 2)
            }

            function tt(t, e) {
                return a(t.getUTCSeconds(), e, 2)
            }

            function et(t) {
                var e = t.getUTCDay();
                return 0 === e ? 7 : e
            }

            function nt(t, e) {
                return a(ht.o.count(n.i(ht.a)(t), t), e, 2)
            }

            function rt(t, e) {
                var r = t.getUTCDay();
                return t = r >= 4 || 0 === r ? n.i(ht.p)(t) : ht.p.ceil(t), a(ht.p.count(n.i(ht.a)(t), t) + (4 === n.i(ht.a)(t).getUTCDay()), e, 2)
            }

            function it(t) {
                return t.getUTCDay()
            }

            function ot(t, e) {
                return a(ht.i.count(n.i(ht.a)(t), t), e, 2)
            }

            function at(t, e) {
                return a(t.getUTCFullYear() % 100, e, 2)
            }

            function ut(t, e) {
                return a(t.getUTCFullYear() % 1e4, e, 4)
            }

            function ct() {
                return "+0000"
            }

            function ft() {
                return "%"
            }

            function st(t) {
                return +t
            }

            function lt(t) {
                return Math.floor(+t / 1e3)
            }
            e.a = function(t) {
                function e(t, e) {
                    return function(n) {
                        var r, i, o, a = [],
                            u = -1,
                            c = 0,
                            f = t.length;
                        for (n instanceof Date || (n = new Date(+n)); ++u < f;) 37 === t.charCodeAt(u) && (a.push(t.slice(c, u)), null != (i = pt[r = t.charAt(++u)]) ? r = t.charAt(++u) : i = "e" === r ? " " : "0", (o = e[r]) && (r = o(n, i)), a.push(r), c = u + 1);
                        return a.push(t.slice(c, u)), a.join("")
                    }
                }

                function a(t, e) {
                    return function(r) {
                        var a, c, f = o(1900);
                        if (u(f, t, r += "", 0) != r.length) return null;
                        if ("Q" in f) return new Date(f.Q);
                        if ("p" in f && (f.H = f.H % 12 + 12 * f.p), "V" in f) {
                            if (f.V < 1 || f.V > 53) return null;
                            "w" in f || (f.w = 1), "Z" in f ? (a = (c = (a = i(o(f.y))).getUTCDay()) > 4 || 0 === c ? ht.i.ceil(a) : n.i(ht.i)(a), a = ht.d.offset(a, 7 * (f.V - 1)), f.y = a.getUTCFullYear(), f.m = a.getUTCMonth(), f.d = a.getUTCDate() + (f.w + 6) % 7) : (a = (c = (a = e(o(f.y))).getDay()) > 4 || 0 === c ? ht.j.ceil(a) : n.i(ht.j)(a), a = ht.k.offset(a, 7 * (f.V - 1)), f.y = a.getFullYear(), f.m = a.getMonth(), f.d = a.getDate() + (f.w + 6) % 7)
                        } else("W" in f || "U" in f) && ("w" in f || (f.w = "u" in f ? f.u % 7 : "W" in f ? 1 : 0), c = "Z" in f ? i(o(f.y)).getUTCDay() : e(o(f.y)).getDay(), f.m = 0, f.d = "W" in f ? (f.w + 6) % 7 + 7 * f.W - (c + 5) % 7 : f.w + 7 * f.U - (c + 6) % 7);
                        return "Z" in f ? (f.H += f.Z / 100 | 0, f.M += f.Z % 100, i(f)) : e(f)
                    }
                }

                function u(t, e, n, r) {
                    for (var i, o, a = 0, u = e.length, c = n.length; a < u;) {
                        if (r >= c) return -1;
                        if (37 === (i = e.charCodeAt(a++))) {
                            if (i = e.charAt(a++), !(o = Dt[i in pt ? e.charAt(a++) : i]) || (r = o(t, n, r)) < 0) return -1
                        } else if (i != n.charCodeAt(r++)) return -1
                    }
                    return r
                }
                var dt = t.dateTime,
                    vt = t.date,
                    yt = t.time,
                    _t = t.periods,
                    gt = t.days,
                    bt = t.shortDays,
                    mt = t.months,
                    wt = t.shortMonths,
                    Ot = c(_t),
                    xt = f(_t),
                    Mt = c(gt),
                    jt = f(gt),
                    kt = c(bt),
                    Pt = f(bt),
                    Et = c(mt),
                    At = f(mt),
                    Lt = c(wt),
                    Ct = f(wt),
                    St = {
                        a: function(t) {
                            return bt[t.getDay()]
                        },
                        A: function(t) {
                            return gt[t.getDay()]
                        },
                        b: function(t) {
                            return wt[t.getMonth()]
                        },
                        B: function(t) {
                            return mt[t.getMonth()]
                        },
                        c: null,
                        d: A,
                        e: A,
                        f: D,
                        H: L,
                        I: C,
                        j: S,
                        L: T,
                        m: I,
                        M: R,
                        p: function(t) {
                            return _t[+(t.getHours() >= 12)]
                        },
                        Q: st,
                        s: lt,
                        S: N,
                        u: z,
                        U: F,
                        V: U,
                        w: B,
                        W: q,
                        x: null,
                        X: null,
                        y: G,
                        Y: V,
                        Z: Y,
                        "%": ft
                    },
                    Tt = {
                        a: function(t) {
                            return bt[t.getUTCDay()]
                        },
                        A: function(t) {
                            return gt[t.getUTCDay()]
                        },
                        b: function(t) {
                            return wt[t.getUTCMonth()]
                        },
                        B: function(t) {
                            return mt[t.getUTCMonth()]
                        },
                        c: null,
                        d: W,
                        e: W,
                        f: $,
                        H: H,
                        I: Z,
                        j: X,
                        L: Q,
                        m: K,
                        M: J,
                        p: function(t) {
                            return _t[+(t.getUTCHours() >= 12)]
                        },
                        Q: st,
                        s: lt,
                        S: tt,
                        u: et,
                        U: nt,
                        V: rt,
                        w: it,
                        W: ot,
                        x: null,
                        X: null,
                        y: at,
                        Y: ut,
                        Z: ct,
                        "%": ft
                    },
                    Dt = {
                        a: function(t, e, n) {
                            var r = kt.exec(e.slice(n));
                            return r ? (t.w = Pt[r[0].toLowerCase()], n + r[0].length) : -1
                        },
                        A: function(t, e, n) {
                            var r = Mt.exec(e.slice(n));
                            return r ? (t.w = jt[r[0].toLowerCase()], n + r[0].length) : -1
                        },
                        b: function(t, e, n) {
                            var r = Lt.exec(e.slice(n));
                            return r ? (t.m = Ct[r[0].toLowerCase()], n + r[0].length) : -1
                        },
                        B: function(t, e, n) {
                            var r = Et.exec(e.slice(n));
                            return r ? (t.m = At[r[0].toLowerCase()], n + r[0].length) : -1
                        },
                        c: function(t, e, n) {
                            return u(t, dt, e, n)
                        },
                        d: b,
                        e: b,
                        f: j,
                        H: w,
                        I: w,
                        j: m,
                        L: M,
                        m: g,
                        M: O,
                        p: function(t, e, n) {
                            var r = Ot.exec(e.slice(n));
                            return r ? (t.p = xt[r[0].toLowerCase()], n + r[0].length) : -1
                        },
                        Q: P,
                        s: E,
                        S: x,
                        u: l,
                        U: h,
                        V: p,
                        w: s,
                        W: d,
                        x: function(t, e, n) {
                            return u(t, vt, e, n)
                        },
                        X: function(t, e, n) {
                            return u(t, yt, e, n)
                        },
                        y: y,
                        Y: v,
                        Z: _,
                        "%": k
                    };
                return St.x = e(vt, St), St.X = e(yt, St), St.c = e(dt, St), Tt.x = e(vt, Tt), Tt.X = e(yt, Tt), Tt.c = e(dt, Tt), {
                    format: function(t) {
                        var n = e(t += "", St);
                        return n.toString = function() {
                            return t
                        }, n
                    },
                    parse: function(t) {
                        var e = a(t += "", r);
                        return e.toString = function() {
                            return t
                        }, e
                    },
                    utcFormat: function(t) {
                        var n = e(t += "", Tt);
                        return n.toString = function() {
                            return t
                        }, n
                    },
                    utcParse: function(t) {
                        var e = a(t, i);
                        return e.toString = function() {
                            return t
                        }, e
                    }
                }
            };
            var ht = n(40),
                pt = {
                    "-": "",
                    _: " ",
                    0: "0"
                },
                dt = /^\s*\d+/,
                vt = /^%/,
                yt = /[\\^$*+?|[\]().{}]/g
        },
        function(t, e) {
            (function(e) {
                t.exports = e
            }).call(e, {})
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Loca = void 0;
            var r = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                i = n(131),
                o = function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                    return e.default = t, e
                }(i),
                a = n(1),
                u = i.VisualMap;
            u.create = i.visualMap, u.visualMap = i.visualMap, u.amapLoader = i.amapLoader, u.VisualLayer = i.VisualLayer, u.visualLayer = i.visualLayer, u.DistrictVisualLayer = i.DistrictVisualLayer, u.districtVisualLayer = i.districtVisualLayer, u.HeatMapVisualLayer = i.HeatMapVisualLayer, u.heatMapVisualLayer = i.heatMapVisualLayer, u.Animation = i.Animation, u.Clip = i.Clip, u.DataSet = i.DataSet, u.VM = o;
            var c = r("1.2.1".split("."), 3),
                f = c[0],
                s = c[1],
                l = c[2];
            1 == f && 10 * s + 1 * l < 13 && console && console.warn && console.warn("尊敬的开发者，您使用的 Loca JSAPI 已升级至 1.1.3 版本，同时建议使用 1.4.10 以上版本的地图 JSAPI。\n更多详情请查看 %s", "https://lbs.amap.com/api/loca-api/api/version_diff/"), u.version = "1.2.1", a.FunLog.version = u.version, e.Loca = u
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.canvasContainer = e.CanvasContainer = void 0;
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(42)),
                o = n(24),
                a = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, i["default"]), r(e, [{
                        key: "_createDefaultGroup",
                        value: function(t, e) {
                            return new o.CanvasGroup(t, e)
                        }
                    }]), e
                }();
            e.CanvasContainer = a, e.canvasContainer = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(a, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return 2 * Math.cos(t * s) * f * c / (0, u.getScale)(e)
            }

            function i(t) {
                var e = t[0],
                    n = t[1];
                return [e - h[0], n - h[1]]
            }

            function o(t, e) {
                var n = (0, u.getScaleInLv)(20 - e);
                return [t[0] / n, t[1] / n]
            }

            function a(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : l,
                    n = arguments[2],
                    r = n || {},
                    i = r.useMercator,
                    c = r.noCache,
                    f = p[e] = p[e] || {},
                    s = t[0] + "," + t[1],
                    h = f[s];
                if (!h) {
                    if (e === l) h = (0, u.lngLatToPoint)(t, e);
                    else if (i) h = (0, u.lngLatToPoint)(t, e);
                    else {
                        h = o(a(t, l, n), e)
                    }
                    c || (f[s] = h)
                }
                return h.slice()
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.transCrossDateLine = e.meter2Pn = e.p20toPn = e.p20ToG20 = e.lngLat2G20 = e.lngLat2Container = e.pixel2LngLat = e.lngLat2Pixel = e.getGroundResolution = void 0;
            var u = n(43),
                c = 6378137,
                f = Math.PI,
                s = f / 180,
                l = 20,
                h = [215440491, 106744817],
                p = {},
                d = {};
            e.getGroundResolution = r, e.lngLat2Pixel = a, e.pixel2LngLat = function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : l,
                    n = d[e] = d[e] || {},
                    r = t[0] + "," + t[1],
                    i = n[r];
                return i || (i = (0, u.pointToLngLat)(t, e), d[r] = i), i
            }, e.lngLat2Container = function(t, e, n, r) {
                var i = (r || {}).p20,
                    o = void 0 === i ? a(t, l) : i,
                    c = a(e, l, {
                        noCache: !0
                    }),
                    f = (0, u.getScaleInLv)(l - n);
                return [(o[0] - c[0]) / f, (o[1] - c[1]) / f]
            }, e.lngLat2G20 = function(t) {
                return i((0, u.lngLatToPoint)(t, l))
            }, e.p20ToG20 = i, e.p20toPn = o, e.meter2Pn = function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 20,
                    n = r(arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0, e);
                return Math.round(t / n)
            }, e.transCrossDateLine = function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [-180, -22],
                    n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 20,
                    r = t[0],
                    i = a(t, n);
                if (r > e[0] && r < e[1]) {
                    var o = 256 * Math.pow(2, n);
                    i[0] += o
                }
                return i
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(8)),
                o = n(1),
                a = function(t) {
                    function e(t) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var n = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
                        return n._options = t, n
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, i["default"]), r(e, [{
                        key: "setContext",
                        value: function(t) {
                            return this._ctx = t, this
                        }
                    }, {
                        key: "update",
                        value: function(t, e) {
                            return this._vertices = t, this._attr = e, this.updateBounds(), this
                        }
                    }, {
                        key: "_updatePath",
                        value: function() {
                            return this
                        }
                    }, {
                        key: "_draw",
                        value: function() {
                            return this
                        }
                    }, {
                        key: "render",
                        value: function() {
                            this._updatePath(), this._draw(), this._attr.debugBounds && this._renderBounds()
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            return this._bounds && this._bounds.contains([t, e])
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            return this._bounds = new o.Bounds, this
                        }
                    }, {
                        key: "_renderBounds",
                        value: function() {}
                    }]), e
                }();
            a.type = "path", e.default = a
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = n(1),
                c = r(n(0)),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = this._ctx,
                                e = this._x,
                                n = this._y,
                                r = this._r,
                                i = c.default.getPixelRatio();
                            return t.beginPath(), t.arc(e * i, n * i, r * i, 0, 2 * Math.PI), this
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = this._attr.lineWidth;
                            if (this._bounds.contains([t, e])) {
                                var r = (n || 0) / 2,
                                    i = this._r + r,
                                    o = t - this._x,
                                    a = e - this._y;
                                return o * o + a * a <= i * i
                            }
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = i(this._vertices, 2),
                                e = t[0],
                                n = t[1],
                                r = this._attr,
                                o = r.offsetX,
                                a = r.offsetY,
                                f = r.radius,
                                s = r.size,
                                l = r.r,
                                h = void 0 === l ? f : l,
                                p = r.s,
                                d = void 0 === p ? s : p,
                                v = r.lineWidth;
                            e = +o ? o + e : e, n = +a ? a + n : n, this._x = e, this._y = n, h = c.default.isNul(h) ? c.default.isNul(d) ? 1 : d / 2 : h, this._r = h;
                            var y = (v || 0) / 2,
                                _ = h - y,
                                g = h + y;
                            this._bounds = new u.Bounds([e - _, n - _], [e + g, n + g])
                        }
                    }]), e
                }();
            f.type = "circle", e.default = f
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = n(1),
                c = r(n(59)),
                f = r(n(22)),
                s = r(n(0)),
                l = f.default.Coordinate.distance2LineString,
                h = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = this._ctx,
                                e = this._verticesOnPaint,
                                n = this._attr.curveness,
                                r = s.default.getPixelRatio();
                            t.beginPath();
                            for (var o = -1, a = e.length; ++o < a;) {
                                var u = e[o],
                                    c = -1,
                                    f = u.length;
                                if (n)
                                    for (; ++c < f;) {
                                        var l = i(u[c], 3),
                                            h = l[0],
                                            p = l[1],
                                            d = l[2];
                                        t.moveTo(h[0] * r, h[1] * r), t.quadraticCurveTo(p[0] * r, p[1] * r, d[0] * r, d[1] * r)
                                    } else {
                                        h = u[0];
                                        for (t.moveTo(h[0] * r, h[1] * r), c = 0; ++c < f;) {
                                            var v = u[c];
                                            t.lineTo(v[0] * r, v[1] * r)
                                        }
                                    }
                            }
                        }
                    }, {
                        key: "_draw",
                        value: function() {
                            var t = this._ctx,
                                e = this._attr,
                                n = e.borderWidth,
                                r = e.color,
                                i = e.shadowBlur,
                                o = e.shadowColor,
                                a = e.shadowOffsetX,
                                u = e.shadowOffsetY,
                                c = e.lineWidth,
                                f = void 0 === c ? n : c,
                                s = e.stroke,
                                l = void 0 === s ? r : s,
                                h = e.opacity,
                                p = e.dashArray,
                                d = e.lineDashOffset,
                                v = e.lineCap,
                                y = e.lineJoin;
                            return t.shadowOffsetX = a, t.shadowOffsetY = u, t.shadowBlur = i, t.shadowColor = o, l && (t.setLineDash && p && (t.setLineDash(p), t.lineDashOffset = d), t.strokeStyle = l, t.globalAlpha = h, t.lineWidth = f, t.lineCap = v, t.lineJoin = y, t.stroke()), this
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = [t, e];
                            if (this._bounds.contains(n))
                                for (var r = this._attr, i = r.lineWidth, o = r.curveness, a = this._verticesOnPaint, c = -1, f = a.length; ++c < f;)
                                    if (o)
                                        for (var s = a[c], h = -1, p = s.length; ++h < p;) {
                                            var d = s[h],
                                                v = i / 2;
                                            if ((0, u.distanceSquare2Bezier)(n, d.bezier) <= v * v) return !0
                                        } else {
                                            var y = a[c];
                                            if (l(n, y) - i / 2 <= 0) return !0
                                        }
                                    return !1
                        }
                    }, {
                        key: "_interpolateLines",
                        value: function() {}
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = this._bounds = new u.Bounds,
                                e = this._attr,
                                n = e.offsetX,
                                r = e.offsetY,
                                i = e.lineWidth,
                                o = e.curveness;
                            e.smooth, e.interpolate;
                            n = n || 0, r = r || 0;
                            for (var a = i || 1, f = [], s = this._vertices, l = -1, h = s.length; ++l < h;) {
                                var p = [],
                                    d = s[l],
                                    v = -1,
                                    y = d.length;
                                if (o)
                                    for (; ++v < y - 1;) {
                                        var _ = d[v],
                                            g = d[v + 1];
                                        _ = [_[0] + n, _[1] + r], g = [g[0] + n, g[1] + r];
                                        var b = (0, u.getControlPoint)(_, g, o),
                                            m = new c.default(_[0], _[1], b[0], b[1], g[0], g[1]),
                                            w = [_, b, g];
                                        w.bezier = m, p.push(w);
                                        var O = m.bbox(),
                                            x = O.x,
                                            M = O.y;
                                        t.expend([x.min, M.min]).expend([x.max, M.max])
                                    } else
                                        for (; ++v < y;) {
                                            var j = d[v];
                                            j = [j[0] + n, j[1] + r], p.push(j), t.expend(j)
                                        }
                                f.push(p)
                            }
                            var k = t.getTopLeft(),
                                P = t.getBottomRight(),
                                E = new u.Point(a / 2, a / 2);
                            t.expend(k.subtract(E)).expend(P.add(E)), this._verticesOnPaint = f
                        }
                    }]), e
                }();
            h.type = "line", e.default = h
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = r(n(52)),
                c = n(1),
                f = r(n(22)),
                s = r(n(0)),
                l = f.default.Coordinate.containsCoordinate,
                h = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = this._ctx,
                                e = this._r,
                                n = this._x,
                                r = this._y,
                                o = this._corners = u.default.getHexCorners([n, r], e),
                                a = o[0],
                                c = s.default.getPixelRatio();
                            t.beginPath(), t.moveTo(a[0] * c, a[1] * c);
                            for (var f = 0, l = o.length; ++f < l;) {
                                var h = i(o[f], 2),
                                    p = h[0],
                                    d = h[1];
                                t.lineTo(p * c, d * c)
                            }
                            t.closePath()
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            return !!this._bounds.contains([t, e]) && l([t, e], this._corners, !0)
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = this._attr,
                                e = t.offsetX,
                                n = t.offsetY,
                                r = t.lineWidth,
                                o = t.radius,
                                a = t.r,
                                u = void 0 === a ? o : a;
                            e = e || 0, n = n || 0, r = r || 1;
                            var f = i(this._vertices, 2),
                                s = f[0],
                                l = f[1],
                                h = this._x = s + e,
                                p = this._y = l + n;
                            this._r = u;
                            var d = this._bounds = new c.Bounds([h - u, p - u], [h + u, p + u]),
                                v = d.getTopLeft(),
                                y = d.getBottomRight(),
                                _ = new c.Point(r / 2, r / 2);
                            d.expend(v.subtract(_)).expend(y.add(_))
                        }
                    }]), e
                }();
            h.type = "hexagon", e.default = h
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = r(n(23)),
                c = n(1),
                f = r(n(0)),
                s = document.body,
                l = window.getComputedStyle,
                h = {},
                p = function(t) {
                    function e(t) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var n = function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t)),
                            r = t.style,
                            i = r.className,
                            o = r.content;
                        if (!h[i]) {
                            var a = document.createElement("i");
                            s.appendChild(a), a.className = i, a.style.position = "absolute", a.style.top = "-999px";
                            var u = l(a, null),
                                c = u.fontFamily,
                                f = u.fontSize,
                                p = u.color,
                                d = u.opacity;
                            o || (o = l(a, "::before").getPropertyValue("content").replace(/"/g, ""));
                            var v = {
                                content: o,
                                fontFamily: c = c.replace(/"/g, ""),
                                fontSize: f,
                                fontColor: p,
                                fontOpacity: d
                            };
                            h[i] = v
                        }
                        return n
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = this._attr.className,
                                e = h[t];
                            if (e) {
                                var n = this._bounds.getTopLeft().valueOf(),
                                    r = i(n, 2),
                                    o = r[0],
                                    a = r[1],
                                    u = f.default.getPixelRatio();
                                this._attr.tX = o * u, this._attr.tY = a * u, this._attr.content = e.content
                            }
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = i(this._vertices, 2),
                                e = t[0],
                                n = t[1],
                                r = this._attr,
                                o = r.className,
                                a = r.offsetX,
                                f = r.offsetY;
                            e = +a ? a + e : e, n = +f ? f + n : n;
                            var s = h[o],
                                l = u.default.measureText(this._ctx, s, this._attr),
                                p = l.width,
                                d = l.height;
                            this._bounds = new c.Bounds([e - p / 2, n - d / 2], [e + p / 2, n + d / 2])
                        }
                    }]), e
                }();
            p.type = "iconfont", e.default = p
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = r(n(0)),
                c = n(1),
                f = "imgLoad",
                s = {},
                l = function(t) {
                    function e(t) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var n = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t));
                        n.on(f, function() {
                            n._load = !0
                        });
                        var r = t.source;
                        if (u.default.isStr(r)) {
                            var i = s[r];
                            if (i) n._symbolEl = i, n.emit(f);
                            else {
                                var o = new Image;
                                o.addEventListener("load", function() {
                                    n._symbolEl = s[r] = {
                                        img: o,
                                        width: o.width,
                                        height: o.height
                                    }, n.emit(f)
                                }), o.addEventListener("error", function() {
                                    n.emit(f)
                                }), o.src = r
                            }
                        } else(u.default.isImg(r) || u.default.isCanvas(r)) && (n._symbolEl = r, n.emit(f));
                        return n
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_draw",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                var e = t._ctx,
                                    n = t._symbolEl,
                                    r = n.img,
                                    o = n.width,
                                    a = n.height;
                                r = r || t._symbolEl;
                                var f = t._attr,
                                    s = f.opacity,
                                    l = f.size,
                                    h = f.s,
                                    p = void 0 === h ? l : h,
                                    d = f.angle,
                                    v = i(t._vertices, 2),
                                    y = v[0],
                                    _ = v[1];
                                u.default.isArray(p) || (p = [p]);
                                var g = u.default.getPixelRatio(),
                                    b = a / o,
                                    m = i(p, 2),
                                    w = m[0],
                                    O = void 0 === w ? o : w,
                                    x = m[1],
                                    M = void 0 === x ? O * b : x,
                                    j = y - O / 2,
                                    k = _ - M / 2;
                                e.globalAlpha = s, d ? (e.save(), e.translate(y * g, _ * g), e.rotate(d), e.translate(-y * g, -_ * g), e.drawImage(r, j * g, k * g, O * g, M * g), e.restore()) : e.drawImage(r, j * g, k * g, O * g, M * g), t._bounds = new c.Bounds([j, k], [j + O, k + M])
                            })
                        }
                    }, {
                        key: "whenReady",
                        value: function(t) {
                            this._load ? t.call(this) : this.on(f, t)
                        }
                    }, {
                        key: "_renderBounds",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                (function t(e, n, r) {
                                    null === e && (e = Function.prototype);
                                    var i = Object.getOwnPropertyDescriptor(e, n);
                                    if (void 0 === i) {
                                        var o = Object.getPrototypeOf(e);
                                        return null === o ? void 0 : t(o, n, r)
                                    }
                                    if ("value" in i) return i.value;
                                    var a = i.get;
                                    if (void 0 !== a) return a.call(r)
                                })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_renderBounds", t).call(t)
                            })
                        }
                    }]), e
                }();
            l.type = "image", e.default = l
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = r(n(22)),
                c = n(1),
                f = r(n(0)),
                s = u.default.Coordinate.containsCoordinate,
                l = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = f.default.getPixelRatio(),
                                e = this._ctx;
                            e.beginPath();
                            for (var n = this._verticesOnPaint, r = -1, o = n.length; ++r < o;) {
                                var a = n[r],
                                    u = 0,
                                    c = a.length,
                                    s = i(a[0], 2),
                                    l = s[0],
                                    h = s[1];
                                for (e.moveTo(l * t, h * t); ++u < c;) {
                                    var p = i(a[u], 2),
                                        d = p[0],
                                        v = p[1];
                                    e.lineTo(d * t, v * t)
                                }
                                e.closePath()
                            }
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = [t, e];
                            if (this._bounds.contains(n))
                                for (var r = this._verticesOnPaint, i = -1, o = r.length; ++i < o;) {
                                    if (s(n, r[i], !0)) return !0
                                }
                            return !1
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = this._bounds = new c.Bounds,
                                e = this._attr,
                                n = e.offsetX,
                                r = e.offsetY,
                                i = e.lineWidth;
                            n = n || 0, r = r || 0;
                            for (var o = i || 1, a = [], u = this._vertices, f = -1, s = u.length; ++f < s;) {
                                for (var l = [], h = u[f], p = -1, d = h.length; ++p < d;) {
                                    var v = h[p];
                                    v = [v[0] + n, v[1] + r], l.push(v), t.expend(v)
                                }
                                a.push(l)
                            }
                            var y = t.getTopLeft(),
                                _ = t.getBottomRight(),
                                g = new c.Point(o / 2, o / 2);
                            t.expend(y.subtract(g)).expend(_.add(g)), this._verticesOnPaint = a
                        }
                    }]), e
                }();
            l.type = "polygon", e.default = l
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(10)),
                u = r(n(0)),
                c = n(1),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_updatePath",
                        value: function() {
                            var t = this._w,
                                e = this._h,
                                n = this._x,
                                r = this._y,
                                i = this._ctx,
                                o = this._attr.angle,
                                a = u.default.getPixelRatio();
                            i.beginPath(), o ? (i.save(), i.translate((n - t / 2) * a, (r - e / 2) * a), i.rotate(o), i.translate((t / 2 - n) * a, (e / 2 - r) * a), i.rect(n * a, r * a, t * a, e * a), i.restore()) : i.rect(n * a, r * a, t * a, e * a)
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            return this._bounds.contains([t, e])
                        }
                    }, {
                        key: "updateBounds",
                        value: function() {
                            var t = this._attr,
                                e = t.offsetX,
                                n = t.offsetY,
                                r = t.lineWidth,
                                o = t.size,
                                a = t.s,
                                f = void 0 === a ? o : a;
                            e = e || 0, n = n || 0, r = r || 1;
                            var s = u.default.isArray(f) ? f : [f, f],
                                l = i(s, 2),
                                h = l[0],
                                p = l[1],
                                d = void 0 === p ? h : p,
                                v = i(this._vertices, 2),
                                y = v[0],
                                _ = v[1],
                                g = this._x = y + e - h / 2,
                                b = this._y = _ + n - d / 2;
                            this._w = h, this._h = d;
                            var m = this._bounds = new c.Bounds([g, b], [g + h, b + d]),
                                w = m.getTopLeft(),
                                O = m.getBottomRight(),
                                x = new c.Point(r / 2, r / 2);
                            m.expend(w.subtract(x)).expend(O.add(x))
                        }
                    }]), e
                }();
            f.type = "rectangle", e.default = f
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(44)),
                i = function(t, e, n, r, i) {
                    var o = i * i,
                        a = i * o,
                        u = -.5 * a + o - .5 * i,
                        c = 1.5 * a - 2.5 * o + 1,
                        f = -1.5 * a + 2 * o + .5 * i,
                        s = .5 * a - .5 * o;
                    return [t[0] * u + e[0] * c + n[0] * f + r[0] * s, t[1] * u + e[1] * c + n[1] * f + r[1] * s]
                },
                o = {
                    getPoints: function(t) {
                        for (var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2, o = (arguments.length > 3 && void 0 !== arguments[3] && arguments[3], t.length), a = [], u = 0, c = 1; c < o; c++) u += r.default.distance(t[c - 1], t[c]);
                        var f = u / (2 << n);
                        f = f > o ? f << 0 : o;
                        for (var s = 0; s <= f; s++) {
                            var l = s / f * (e ? o : o - 1),
                                h = l >> 0,
                                p = l - h,
                                d = void 0,
                                v = t[h % o],
                                y = void 0,
                                _ = void 0;
                            e ? (d = t[(h - 1 + o) % o], y = t[(h + 1) % o], _ = t[(h + 2) % o]) : (d = t[0 === h ? 0 : h - 1], y = t[h + 1 > o - 1 ? o - 1 : h + 1], _ = t[h + 2 > o - 1 ? o - 1 : h + 2]), a.push(i(d, v, y, _, p))
                        }
                        return a
                    },
                    chaikinPolygonInterpolate: function(t) {
                        for (var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : .25, n = [], r = 0; r < t.length; r++) {
                            var i = t[r],
                                o = r + 1 < t.length ? t[r + 1] : t[0],
                                a = i[0],
                                u = i[1],
                                c = o[0],
                                f = o[1],
                                s = 1 - e,
                                l = [s * a + e * c, s * u + e * f],
                                h = [e * a + s * c, e * u + s * f];
                            n.push(l), n.push(h)
                        }
                        return n
                    }
                };
            e.default = o
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Choropleth = void 0;
            var r = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                i = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                };
            e.choropleth = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            };
            var o = n(6),
                a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                u = n(1),
                c = n(4),
                f = {
                    dataOptions: {
                        position: "position",
                        value: "value"
                    },
                    attrOpt: {
                        adcode: 1e5,
                        mode: "count",
                        style: {
                            lineWidth: 1,
                            stroke: "#333",
                            opacity: .7
                        },
                        gradient: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"]
                    }
                },
                s = e.Choropleth = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o.OverlayGroup), r(e, [{
                        key: "_initProperties",
                        value: function() {
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._groupMap = {}, this._dataList = [], this._defOptions = {
                                drillDown: !1
                            }
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            var e = this;
                            u.amapLoader._whenUIReady(function(n) {
                                n.loadUI(["geo/DistrictExplorer"], function(n) {
                                    var r = e._owner;
                                    if (r) {
                                        var i = e._map = r.getMap();
                                        if (i) {
                                            var a = e._explorer = new n({
                                                    eventSupport: !1,
                                                    map: i
                                                }),
                                                u = "3D" === r.getViewMode();
                                            e._group = new(u ? o.Map3DOverlayGroup : o.MapOverlayGroup)([], e._options), e._group.addTo(r), t.call(e, a)
                                        }
                                    }
                                })
                            }), u.amapLoader.init({
                                ui: !0
                            })
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            var t = this;
                            i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_bindEvent", this).call(this);
                            var n = this._options,
                                r = n.drillDown,
                                o = n.fitView;
                            r && this.on(c.Event.CLICK, function(e) {
                                var n = e.propagatedFrom.getData().subFeature.properties,
                                    r = n.adcode,
                                    i = n.childrenNum;
                                r && i && t.goto(r)
                            }), o && this.on(c.Event.RENDER, function(e) {
                                t.setFitView()
                            })
                        }
                    }, {
                        key: "setData",
                        value: function(t, e) {
                            this._bounds = new u.LngLatBounds, this._dataList = [], this._data = a.default.clone(t);
                            for (var n = this._dataOptions = a.default.defaults({}, e, f.dataOptions), r = n.position, i = n.value, o = n.max, c = n.min, s = a.default.isNul(c) ? -1 / 0 : c, l = a.default.isNul(o) ? 1 / 0 : o, h = -1, p = t.length; ++h < p;) {
                                var d = t[h],
                                    v = (0, u.toLngLat)((0, u.getByKey)(d, r, this, h));
                                this._bounds.expend(v);
                                var y = +(0, u.getByKey)(d, i, this, h) || 0;
                                y = y > l ? l : y < s ? s : y, this._dataList.push({
                                    rawData: d,
                                    lngLat: v,
                                    value: y
                                })
                            }
                            return this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t) {
                            this._attrOptions = (0, u.formatVisualOptions)(t, f.attrOpt)
                        }
                    }, {
                        key: "_groupByAdCode",
                        value: function(t, e, n) {
                            var r = this,
                                i = this._groupMap[e];
                            i ? n.call(this, i.features) : this.whenReady(function() {
                                r._explorer.loadAreaNode(e, function(e, i) {
                                    if (e) n.call(r);
                                    else {
                                        var o = i.adcode;
                                        if (!r._groupMap[o]) {
                                            var a = i.groupByPosition(t, function(t) {
                                                return t.lngLat.valueOf()
                                            });
                                            r._updateStatistics(a), r._groupMap[o] = {
                                                features: a,
                                                areaNode: i
                                            }, n.call(r, a)
                                        }
                                    }
                                })
                            })
                        }
                    }, {
                        key: "_updateStatistics",
                        value: function(t) {
                            for (var e = -1, n = t.length; ++e < n;) {
                                var r = t[e],
                                    i = r.subFeatureIndex,
                                    o = r.points;
                                if (-1 !== i) {
                                    var u = o.length,
                                        c = {
                                            count: u
                                        };
                                    u > 0 && (c.sum = a.default.sumBy(o, "value"), c.max = a.default.maxBy(o, "value").value, c.min = a.default.minBy(o, "value").value, c.mean = a.default.meanBy(o, "value"), c.median = a.default.median(o, "value")), r.statistics = c
                                }
                            }
                            return t
                        }
                    }, {
                        key: "changeMode",
                        value: function(t) {
                            return this._attrOptions.mode = t, this._render(), this
                        }
                    }, {
                        key: "goto",
                        value: function(t) {
                            if (-1 === t) {
                                var e = this._adcode;
                                if (e) {
                                    var n = this._groupMap[e].areaNode.getParentFeature().properties.acroutes || [],
                                        r = n[n.length - 1];
                                    r && r != e && (this._attrOptions.adcode = r, this._render())
                                }
                            } else this._attrOptions.adcode = t, this._render();
                            return this
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this._render(), this
                        }
                    }, {
                        key: "_render",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                var e = t._attrOptions,
                                    n = e.displayBlank,
                                    r = e.mode,
                                    i = e.adcode,
                                    s = e.style,
                                    l = e.selectStyle;
                                t._groupByAdCode(t._dataList, i, function(e) {
                                    if (e) {
                                        t._adcode = i;
                                        var h = [],
                                            p = [];
                                        e.forEach(function(t) {
                                            var e = t.subFeatureIndex,
                                                n = t.points,
                                                i = t.statistics;
                                            if (-1 !== e) {
                                                var o = n.length > 0 ? i[r] : void 0;
                                                h.push({
                                                    feature: t,
                                                    weight: o
                                                }), a.default.isNil(o) || p.push(o)
                                            }
                                        });
                                        var d = a.default.extent(p),
                                            v = s || {},
                                            y = v.color,
                                            _ = v.borderColor,
                                            g = void 0 === _ ? v.stroke : _,
                                            b = v.height,
                                            m = v.blankFill,
                                            w = (0, u.toAttrOption)(y, {
                                                scale: "quantile",
                                                input: d
                                            }),
                                            O = w.value,
                                            x = w.scale,
                                            M = w.input;
                                        "quantile" === x && (M = a.default.chain(p).uniq().sortBy().value());
                                        var j = u.Scale.create(x).domain(M).range(O);
                                        j.nice && j.nice();
                                        var k = (0, u.toAttrOption)(b, {
                                                scale: "linear",
                                                input: d,
                                                clamp: !0
                                            }),
                                            P = k.value,
                                            E = k.scale,
                                            A = k.input,
                                            L = k.clamp,
                                            C = void 0;
                                        a.default.isArray(P) && (C = u.Scale.create(E).domain(A).range(P)).clamp && C.clamp(L);
                                        var S = [];
                                        h.forEach(function(t) {
                                            var e = t.feature,
                                                r = t.weight,
                                                i = a.default.isNil(r);
                                            if (i && !n) return !1;
                                            var o = e.subFeature,
                                                u = 0;
                                            C && (u = a.default.isNil(r) ? 0 : C(r));
                                            var c = i ? a.default.isNil(m) ? "" : m : j(r),
                                                h = a.default.defaults({
                                                    color: c,
                                                    borderColor: g,
                                                    height: u
                                                }, s),
                                                p = [];
                                            o.geometry.coordinates.forEach(function(t) {
                                                p.push(t[0])
                                            });
                                            var d = {
                                                type: "polygon",
                                                position: p,
                                                style: h,
                                                feature: e
                                            };
                                            l && (d.selectStyle = a.default.defaults(l, f.attrOpt.selectStyle)), S.push(d)
                                        });
                                        var T = [],
                                            D = "3D" === t._owner.getViewMode();
                                        S.forEach(function(e) {
                                            var n = new(D ? o.Map3DPolygon : o.MapPolygon)(e.feature, e);
                                            n.addEventParent(t, function(t) {
                                                var e = t.target.getData();
                                                return t.value = e.statistics[r], t.feature = e, t
                                            }), T.push(n)
                                        }), t._group.removeOverlay().addOverlay(T), t.emit(c.Event.RENDER)
                                    }
                                })
                            }), this
                        }
                    }, {
                        key: "getStatus",
                        value: function() {
                            var t = this._groupMap[this._adcode];
                            return t ? {
                                adcode: this._adcode,
                                features: t.features
                            } : void 0
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                t._group.setFitView()
                            }), this
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                e._group.setZIndex(t)
                            }), this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this._group && this._group.destroy(), i(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this)
                        }
                    }]), e
                }()
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.gridHeatMapFeatureGroup = e.GridHeatMapFeatureGroup = void 0;
            var r = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                a = n(6),
                u = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                c = n(1),
                f = {
                    position: "position",
                    value: "value"
                },
                s = {
                    style: {
                        radius: 10,
                        gap: 2,
                        opacity: .7,
                        lineWidth: 1,
                        fill: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"]
                    },
                    selectStyle: {
                        opacity: .95
                    },
                    mode: "count",
                    shape: "hexagon",
                    unit: "px"
                },
                l = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a.OverlayGroup), i(e, [{
                        key: "_initProperties",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._data = [], this._attrOptions = {}, this._points = []
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            this._group = new a.CanvasGroup([], this._options), u.default.callFn(t, this)
                        }
                    }, {
                        key: "setData",
                        value: function(t, e) {
                            this._data = t || [];
                            var n = this._dataOptions = u.default.defaults(e, f);
                            return this._buildPointIdx(t, n), this._resetBin(), this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t) {
                            return this._attrOptions = (0, c.formatVisualOptions)(t, s), this._resetBin(), this
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                if (t._updateBinning(), t._binData) {
                                    var e = t._dataOptions,
                                        n = e.max,
                                        r = e.min;
                                    t._attrList = t._updateStyle(t._binData, t._attrOptions, {
                                        max: n,
                                        min: r
                                    });
                                    for (var i = t._attrList, o = [], u = -1, c = i.length; ++u < c;) {
                                        var f = new a.Marker(t._data[u], i[u]);
                                        o.push(f)
                                    }
                                    t._group.addOverlay(o)
                                }
                            })
                        }
                    }, {
                        key: "_buildPointIdx",
                        value: function(t, e) {
                            for (var n = e.position, r = e.value, i = [], o = -1, a = t.length; ++o < a;) {
                                var u = t[o],
                                    f = (0, c.getByKey)(u, n, this, o),
                                    s = (0, c.getByKey)(u, r, this, o);
                                f.value = s, i.push(f)
                            }
                            this._points = i
                        }
                    }, {
                        key: "_updateBinning",
                        value: function() {
                            if (!this._binData) {
                                var t = this._attrOptions,
                                    e = t.shape,
                                    n = t.style.radius;
                                this._binData = this._addHeatValue((0, c.binning)(this._points, {
                                    radius: n,
                                    shape: e
                                }))
                            }
                        }
                    }, {
                        key: "_addHeatValue",
                        value: function(t) {
                            for (var e = -1, n = t.length; ++e < n;) {
                                var r = t[e];
                                r.count = r.length, r.count && (r.sum = u.default.sumBy(r, "value"), r.mean = u.default.meanBy(r, "value"), r.max = u.default.maxBy(r, "value").value, r.min = u.default.minBy(r, "value").value, r.median = u.default.median(r, "value"))
                            }
                            return t
                        }
                    }, {
                        key: "_updateStyle",
                        value: function(t, e, n) {
                            var i = n.max,
                                o = n.min,
                                a = e.style,
                                f = e.selectStyle,
                                s = e.mode,
                                l = e.shape,
                                h = e.colorScale,
                                p = e.gradient,
                                d = e.color,
                                v = void 0 === d ? p : d,
                                y = (e.unit, e.heightUnit),
                                _ = a.radius,
                                g = a.opacity,
                                b = a.fillOpacity,
                                m = void 0 === b ? g : b,
                                w = a.lineWidth,
                                O = a.stroke,
                                x = a.gap,
                                M = a.height,
                                j = (0, c.sortGradientColor)(v).colors,
                                k = u.default.map(t, function(t) {
                                    return t[s]
                                });
                            if (u.default.isNul(i) || u.default.isNul(o)) {
                                var P = u.default.extent(k),
                                    E = r(P, 2),
                                    A = E[0],
                                    L = E[1];
                                o = u.default.isNul(o) ? A : o, i = u.default.isNul(i) ? L : i
                            }
                            var C = [o, i];
                            "quantile" === h && (C = u.default.sortedUniq(k));
                            var S = c.Scale.create(h).domain(C).range(j),
                                T = void 0;
                            u.default.isArray(m) && (T = c.Scale.create().domain(C).range(m));
                            var D = void 0;
                            u.default.isArray(M) && (D = c.Scale.create().domain(C).range(M)), _ = x ? _ - x / 2 : _;
                            for (var I = [], R = -1, N = t.length; ++R < N;) {
                                var z = t[R],
                                    F = z[s],
                                    U = S(F),
                                    B = T ? T(F) : m,
                                    q = D ? D(F) : M,
                                    G = u.default.defaults({}, {
                                        fill: U,
                                        stroke: O,
                                        lineWidth: w,
                                        fillOpacity: B,
                                        radius: _,
                                        size: 2 * _,
                                        height: q
                                    }, a),
                                    V = {
                                        position: [z.x, z.y],
                                        style: G,
                                        selectStyle: f,
                                        type: l,
                                        data: z,
                                        value: F,
                                        heightUnit: y
                                    };
                                I.push(V)
                            }
                            return I
                        }
                    }, {
                        key: "_resetBin",
                        value: function() {
                            delete this._binData
                        }
                    }, {
                        key: "onAdd",
                        value: function(t) {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "onAdd", this).call(this, t);
                            var n = this._owner;
                            this._group && this._group.addTo(n)
                        }
                    }, {
                        key: "onRemove",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "onRemove", this).call(this), this._group && this._group.remove()
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                e._group && e._group.setZIndex(t)
                            }), this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), this._group.destroy(), delete this._group, delete this._binData, delete this._attrList, delete this._dataOptions, delete this._attrOptions
                        }
                    }]), e
                }();
            e.GridHeatMapFeatureGroup = l, e.gridHeatMapFeatureGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(l, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                if (t && t.__esModule) return t;
                var e = {};
                if (null != t)
                    for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e.default = t, e
            }

            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapContourFeatureGroup = e.MapContourFeatureGroup = void 0;
            var o = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                a = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                u = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                c = n(6),
                f = i(n(0)),
                s = n(1),
                l = n(184),
                h = r(n(3)),
                p = r(n(14)),
                d = i(n(241)),
                v = i(n(114)),
                y = i(n(134)),
                _ = v.default.chaikinPolygonInterpolate,
                g = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, c.OverlayGroup), a(e, [{
                        key: "_initProperties",
                        value: function() {
                            u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this)
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            this._map = this._owner.getMap();
                            var e = this._owner._is2D();
                            this._group = new(e ? c.MapOverlayGroup : c.Map3DOverlayGroup)([], this._options), this._group.addTo(this._owner), f.default.callFn(t, this)
                        }
                    }, {
                        key: "setData",
                        value: function(t, e) {
                            return this._data = t || [], this._dataOptions = f.default.defaults(e), this.p20Arr = this.getP20Data(t), this.valueArr = this.getValueAndBounds(t), this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t) {
                            var e = t.interpolation,
                                n = void 0 === e ? {} : e,
                                r = n.step,
                                i = n.effectRadius;
                            f.default.merge(n, {
                                step: 100 * r,
                                effectRadius: 100 * i
                            }), this._options = t
                        }
                    }, {
                        key: "getP20Data",
                        value: function(t) {
                            var e = (this._dataOptions || {}).lnglat || "lnglat",
                                n = this._owner._is2D(),
                                r = this._map;
                            if (e) {
                                return f.default.map(t, function(t) {
                                    var i = t[e],
                                        o = new(Function.prototype.bind.apply(AMap.LngLat, [null].concat(function(t) {
                                            if (Array.isArray(t)) {
                                                for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
                                                return n
                                            }
                                            return Array.from(t)
                                        }(i.split(",")))));
                                    return n ? r.lnglatToPixel(o, 20) : r.lngLatToGeodeticCoord(o)
                                })
                            }
                            return []
                        }
                    }, {
                        key: "getValueAndBounds",
                        value: function(t) {
                            var e = 1 / 0,
                                n = -1 / 0,
                                r = (this._dataOptions || {}).value || "count";
                            if (r) {
                                var i = f.default.map(t, function(t) {
                                    var i = parseFloat(t[r]);
                                    return i < e && (e = i), i > n && (n = i), i
                                });
                                return this.value = {
                                    min: e,
                                    max: n
                                }, i
                            }
                            return this.value = {
                                min: 0,
                                max: 0
                            }, []
                        }
                    }, {
                        key: "getBoundLnglat",
                        value: function() {
                            for (var t = 1 / 0, e = 1 / 0, n = -1 / 0, r = -1 / 0, i = this.p20Arr || [], o = 0; o < i.length; o++) {
                                var a = i[o],
                                    u = a.x,
                                    c = a.y;
                                u <= t && (t = u), u >= n && (n = u), c <= e && (e = c), c >= r && (r = c)
                            }
                            this.bounds = {
                                minLng: t,
                                minLat: e,
                                maxLng: n,
                                maxLat: r
                            }
                        }
                    }, {
                        key: "getGridNum",
                        value: function() {
                            var t = this._options.interpolation || {},
                                e = t.effectRadius,
                                n = t.step,
                                r = this.bounds || {},
                                i = r.minLng,
                                o = r.minLat,
                                a = r.maxLng,
                                u = r.maxLat,
                                c = (a += e) - (i -= e),
                                f = (u += e) - (o -= e),
                                s = Math.ceil(c / n),
                                l = Math.ceil(f / n);
                            if (s > 1024 || l > 1024) {
                                var h = a - i,
                                    p = Math.ceil(h / 90),
                                    d = "您设置的 step 过小将会导致性能问题，建议您设置的 step 范围为 [" + Math.ceil(.2 * p) + ", " + Math.ceil(3 * p) + "] ，并且 effectRadius 不超过 5 * step，threshold 不要过小。";
                                console.warn(d)
                            }
                            this.bounds = {
                                minLng: i,
                                minLat: o,
                                maxLng: a,
                                maxLat: u
                            }, this.gridNum = {
                                m: s,
                                n: l
                            }
                        }
                    }, {
                        key: "initOriginGrid",
                        value: function() {
                            for (var t = (this._options || {}).interpolation, e = (void 0 === t ? {} : t).step, n = this.gridNum, r = n.m, i = n.n, o = new Array(i), a = this.valueArr || [], u = this.p20Arr || [], c = this.bounds, f = c.minLng, s = c.minLat, l = (c.maxLng, c.maxLat, 0); l < i; l++) o[l] = new Array(r);
                            u.forEach(function(t, n) {
                                var r = t.x,
                                    i = t.y,
                                    u = Math.floor((r - f) / e),
                                    c = Math.floor((i - s) / e);
                                o[c][u] ? o[c][u] = o[c][u] < a[n] ? a[n] : o[c][u] : o[c][u] = a[n]
                            }), this.originGrid = o
                        }
                    }, {
                        key: "interpolate",
                        value: function() {
                            var t = f.default.cloneDeep(this.originGrid),
                                e = this.bounds,
                                n = e.minLng,
                                r = (e.minLat, e.maxLng),
                                i = (e.maxLat, (this._options || {}).interpolation),
                                o = void 0 === i ? {} : i,
                                a = o.step,
                                u = o.effectRadius,
                                c = o.enable;
                            if (u = void 0 === u ? Math.ceil(Math.ceil(r - n) / 3) : u, c) {
                                var s = {
                                    gridNum: this.gridNum,
                                    dataOpts: this.value,
                                    effectRadius: u,
                                    extendGrid: t,
                                    step: a
                                };
                                this.extendGridWithData = y.default.set(s)
                            } else {
                                for (var l = f.default.cloneDeep(t), h = 0; h < t.length; h++)
                                    for (var p = t[h], d = 0; d < p.length; d++) {
                                        var v = p[d];
                                        l[h][d] = void 0 === v ? 0 : v
                                    }
                                this.extendGridWithData = l
                            }
                        }
                    }, {
                        key: "getFixed2Data",
                        value: function(t, e) {
                            return parseFloat(t.toFixed(e || 2))
                        }
                    }, {
                        key: "getContourMinVal",
                        value: function() {
                            for (var t = this.extendGridWithData || [], e = [], n = (this._options || {}).interpolation, r = void 0 === n ? {} : n, i = r.effectRadius, o = r.step, a = Math.ceil(i / o), u = t.length, c = 0; c < u; c++) {
                                var s = t[c];
                                if (c <= a || u - c <= a) e.push(s);
                                else {
                                    var l = s.length;
                                    e.push(s.slice(0, a)), e.push(s.slice(l - a, l))
                                }
                            }
                            var h = e.join(",").split(","),
                                p = h.length,
                                d = (h = f.default.map(h, function(t) {
                                    return parseFloat(t)
                                })).sort(function(t, e) {
                                    return t - e
                                }),
                                v = (d[p - 1] - d[0]) / p,
                                y = d[Math.ceil(.7 * p)];
                            return this.getFixed2Data(parseFloat(y) + v)
                        }
                    }, {
                        key: "getContour",
                        value: function() {
                            var t = this._dataOptions || {},
                                e = t.min,
                                n = t.max,
                                r = this.gridNum,
                                i = r.m,
                                o = r.n,
                                a = (this._options || {}).threshold;
                            void 0 === e && (e = this.getContourMinVal()), void 0 === n && (n = this.value.max), this.geoJson = (0, l.contours)().size([i, o]).thresholds(h.range(e, n, a))(this.flatGrid)
                        }
                    }, {
                        key: "filterSamePoint",
                        value: function() {
                            this._options;
                            for (var t = this.geoJson, e = 0; e < t.length; e++)
                                for (var n = t[e].coordinates, r = 0; r < n.length; r++) {
                                    for (var i = n[r], a = 0; a < i.length; a++) {
                                        for (var u = i[a], c = 0; c < u.length - 1; c++) {
                                            var f = o(u[c], 2),
                                                s = f[0],
                                                l = f[1],
                                                h = o(u[c + 1], 2),
                                                p = h[0],
                                                d = h[1];
                                            s === p && l === d && (u.splice(c, 1), c--)
                                        }
                                        u.pop(), i[a] = u
                                    }
                                    t[e].coordinates[r] = i
                                }
                            this.geoJson = t
                        }
                    }, {
                        key: "smooth",
                        value: function() {
                            var t = (this._options || {}).smoothNumber;
                            t = t > 20 ? 20 : t;
                            for (var e = this.geoJson, n = 0; n < e.length; n++)
                                for (var r = e[n].coordinates, i = 0; i < r.length; i++) {
                                    for (var o = r[i], a = 0; a < o.length; a++) {
                                        for (var u = o[a], c = 0; c < t; c++) u = _(u);
                                        u.push(u[0]), o[a] = u
                                    }
                                    e[n].coordinates[i] = o
                                }
                        }
                    }, {
                        key: "setBounds",
                        value: function() {
                            var t = this._map,
                                e = this._owner._is2D(),
                                n = this.bounds,
                                r = n.minLng,
                                i = n.minLat,
                                o = n.maxLng,
                                a = n.maxLat,
                                u = void 0,
                                c = void 0;
                            e ? (u = t.pixelToLngLat(new AMap.Pixel(r, i), 20) + "", c = t.pixelToLngLat(new AMap.Pixel(o, a), 20) + "") : (u = t.geodeticCoordToLngLat(new AMap.Pixel(r, i)) + "", c = t.geodeticCoordToLngLat(new AMap.Pixel(o, a)) + ""), this._bounds = new s.LngLatBounds(u.split(","), c.split(","))
                        }
                    }, {
                        key: "getCurColor",
                        value: function(t, e, n) {
                            if (e <= 1) return t[0];
                            var r = e - 1,
                                i = t.length,
                                o = n / r,
                                a = parseInt(o * i);
                            if (a >= i - 1) return t[i - 1];
                            var u = t[a],
                                c = t[a + 1],
                                f = o * i - a;
                            return p.interpolate(u, c)(f).toString()
                        }
                    }, {
                        key: "draw2D",
                        value: function() {
                            for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = this._options || {}, n = e.style, r = void 0 === n ? {} : n, i = e.shape, o = r.color, a = r.strokeWeight, u = r.strokeColor, f = [], s = t.length, l = 0; l < s; l++)
                                for (var h = t[l] || [], p = this.getCurColor(o, s, l), d = 0; d < h.length; d++) {
                                    var v = h[d],
                                        y = void 0;
                                    y = "isoband" === i ? new c.MapPolygon(v, {
                                        type: "polygon",
                                        isP20: !0,
                                        style: {
                                            stroke: u,
                                            lineWidth: a,
                                            fill: p
                                        }
                                    }) : new c.MapLine(v, {
                                        type: "line",
                                        isP20: !0,
                                        style: {
                                            stroke: p,
                                            lineWidth: a
                                        }
                                    }), f.push(y)
                                }
                            this._group.addOverlay(f)
                        }
                    }, {
                        key: "draw3D",
                        value: function(t) {
                            for (var e = this._options, n = e.style, r = void 0 === n ? {} : n, i = e.shape, o = r.height, a = r.color, u = t.length, f = [], s = [], l = 0; l < u; l++) {
                                var h = d.default.normal.pdf(l, u, u / 3 * 2);
                                s.push(h)
                            }
                            for (var p = 1 / (s[u - 1] - s[0]), v = 0; v < u; v++)
                                for (var y = t[v] || [], _ = y.length, g = 1 == u ? o : (s[v] - s[0]) * p * o, b = this.getCurColor(a, u, v), m = 0; m < _; m++) {
                                    var w = y[m],
                                        O = void 0;
                                    "isoline" === i ? (O = new c.Map3DLine(w, {
                                        isG20: !0,
                                        style: {
                                            stroke: b,
                                            height: g
                                        }
                                    }), f.push(O)) : O = new c.Map3DContour(w, {
                                        style: {
                                            color: b,
                                            height: g
                                        }
                                    }), f.push(O)
                                }
                            this._group.addOverlay(f)
                        }
                    }, {
                        key: "draw",
                        value: function() {
                            for (var t = this._options || {}, e = t.style, n = t.shape, r = ((void 0 === e ? {} : e).color, this.bounds || {}), i = r.minLng, a = r.minLat, u = r.maxLng, c = r.maxLat, f = this.gridNum || {}, s = f.m, l = f.n, h = this.geoJson, p = (this._map, this._owner._is2D() ? "2D" : "3D"), d = [], v = (u - i) / s, y = (c - a) / l, _ = 0; _ < h.length; _++) {
                                for (var g = h[_].coordinates, b = [], m = 0; m < g.length; m++) {
                                    for (var w = g[m], O = [], x = 0; x < 1; x++) {
                                        for (var M = w[x], j = [], k = M[0] || [], P = o(k, 2), E = P[0], A = P[1], L = 0; L < M.length; L++) {
                                            var C = o(M[L], 2),
                                                S = C[0],
                                                T = C[1];
                                            if ("isoline" !== n && S == E && T === A && 0 !== L) break;
                                            var D = [i + v * S, a + y * T];
                                            j.push(D)
                                        }
                                        j.length && O.push(j)
                                    }
                                    b.push(O.concat([]))
                                }
                                d.push(b.concat([]))
                            }
                            "3D" === p ? this.draw3D(d) : this.draw2D(d), this.setBounds(), this.setFitView()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                t._group.removeLayer(), t._render()
                            })
                        }
                    }, {
                        key: "_render",
                        value: function() {
                            if (this.p20Arr && this.p20Arr.length && this.valueArr && this.valueArr.length) {
                                this.getBoundLnglat(), this.getGridNum(), this.initOriginGrid(), this.interpolate();
                                var t = this.extendGridWithData || [];
                                return this.flatGrid = f.default.map(t.join(",").split(","), function(t) {
                                    return parseFloat(t)
                                }), this.getContour(), this.filterSamePoint(), this.smooth(), this.draw(), this
                            }
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                e._group.setZIndex(t)
                            }), this
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                t._owner.setBounds(t._bounds)
                            }), this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this._group && this._group.destroy(), u(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this)
                        }
                    }]), e
                }();
            e.MapContourFeatureGroup = g, e.mapContourFeatureGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(g, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !e || "object" != typeof e && "function" != typeof e ? t : e
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapGridHeatMapFeatureGroup = e.MapGridHeatMapFeatureGroup = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                a = n(6),
                u = n(4),
                c = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                f = n(1),
                s = n(5),
                l = "center",
                h = {
                    position: "position",
                    value: "value"
                },
                p = {
                    style: {
                        gap: 0,
                        opacity: 1,
                        lineWidth: 1,
                        color: ["#eff3ff", "#c6dbef", "#9ecae1", "#6baed6", "#3182bd", "#08519c"]
                    },
                    mode: "count",
                    shape: "hexagon",
                    unit: "px",
                    heightUnit: "px"
                },
                d = function(t) {
                    function e() {
                        var t, n, i, o;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        for (var u = arguments.length, f = Array(u), s = 0; s < u; s++) f[s] = arguments[s];
                        return n = i = r(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [this].concat(f))), i.render = c.default.debounce(function() {
                            i.whenReady(function() {
                                i._group.removeLayer(), i._updateBinning();
                                var t = i._binData;
                                if (t) {
                                    var e = i._attrOptions,
                                        n = e.shape,
                                        r = e.mode,
                                        o = i._styleList = i._updateStyle(t, e);
                                    if (i._owner._is2D()) {
                                        for (var u = [], f = -1, s = t.length; ++f < s;) {
                                            var h = t[f],
                                                p = o[f],
                                                d = c.default.defaults({
                                                    position: "center",
                                                    style: p
                                                }, e),
                                                v = new a.MapPoint(h, d);
                                            v.addEventParent(i, function(t) {
                                                var e = t.target._data,
                                                    n = e[l],
                                                    i = e.rawData,
                                                    o = e.indexes;
                                                return t.indexes = c.default.clone(o), t.rawData = c.default.clone(i), t.lngLat = c.default.clone(n), t.value = e[r], t
                                            }), u.push(v)
                                        }
                                        i._group.addOverlay(u)
                                    } else {
                                        var y = void 0;
                                        switch (n) {
                                            case "hexagon":
                                                y = 6;
                                                break;
                                            case "rectangle":
                                            default:
                                                y = 4
                                        }
                                        var _ = 2 / Math.pow(2, .5),
                                            g = Math.PI / y,
                                            b = o.map(function(t) {
                                                return 4 == y && (t.radius = t.radius * _), t.rotate = g, t
                                            }),
                                            m = new a.Map3DAcceptLightPrism(t, c.default.defaults({
                                                position: "center",
                                                vertex: y,
                                                style: b
                                            }, e));
                                        m.addEventParent(i, function(t) {
                                            var e = t.target,
                                                n = e._data,
                                                i = e._selectIdx,
                                                o = n[i];
                                            if (-1 !== i && o) {
                                                var a = o[l],
                                                    u = o.rawData,
                                                    f = o.indexes;
                                                t.indexes = c.default.clone(f), t.rawData = c.default.clone(u), t.lngLat = c.default.clone(a), t.value = o[r]
                                            }
                                            return t
                                        }), i._group.addOverlay(m)
                                    }
                                    i._hasRender = !0
                                }
                            })
                        }, 80), o = n, r(i, o)
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a.OverlayGroup), i(e, [{
                        key: "_initProperties",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._data = [], this._attrOptions = {}, this._points = [], this._binMap = {}, this._colorLegend = []
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            var e = this,
                                n = this._owner;
                            this._map = n.getMap();
                            var r = n._is2D();
                            this._group = new(r ? a.MapOverlayGroup : a.Map3DOverlayGroup)([], this._options), this._map.on(u.Event.ZOOM_END, function() {
                                e.emit(u.Event.ZOOM_END)
                            }), c.default.callFn(t, this)
                        }
                    }, {
                        key: "_bindEvent",
                        value: function() {
                            var t = this;
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_bindEvent", this).call(this), this.on(u.Event.ZOOM_END, function() {
                                var e = t._attrOptions.unit,
                                    n=true;
                                    // n = t._owner._is2D();
                                ("meter" !== e || n) && t._hasRender && (t._resetBin(), t.render())
                            })
                        }
                    }, {
                        key: "setData",
                        value: function(t, e) {
                            return this._data = c.default.cloneDeep(t || []), this._dataOptions = c.default.defaults({}, e, h), this._buildPointIdx(), this._resetBin(), this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t) {
                            return this._attrOptions = (0, f.formatVisualOptions)(t, p), this._resetBin(), this
                        }
                    }, {
                        key: "_buildPointIdx",
                        value: function() {
                            this._bounds = new f.LngLatBounds;
                            for (var t = this._dataOptions, e = t.position, n = t.value, r = [], i = this._data, o = -1, a = i.length; ++o < a;) {
                                var u = i[o],
                                    c = (0, f.toLngLat)((0, f.getByKey)(u, e, this, o)),
                                    l = +(0, f.getByKey)(u, n, this, o);
                                this._bounds.expend(c);
                                var h = (0, s.lngLat2Pixel)(c.valueOf(), 20);
                                h.value = l, h.lngLat = c.valueOf(), r.push(h)
                            }
                            this._points = r
                        }
                    }, {
                        key: "_updateBinning",
                        value: function() {
                            if (!this._binData) {
                                var t = this._attrOptions,
                                    e = t.style,
                                    n = e.size,
                                    r = e.radius,
                                    i = t.unit,
                                    o = t.shape;
                                r = c.default.isNil(r) ? (c.default.isNil(n[0]) ? n : n[0]) / 2 : r;
                                var a = this._map.getZoom(),
                                    u = "meter" === i ? i : a,
                                    h = this._binMap[u];
                                if (!h) {
                                    if ("meter" === i) {
                                        var p = this._bounds.getCenter();
                                        r /= (0, s.getGroundResolution)(p.getLat(), 20)
                                    } else r *= (0, s.getScaleInLv)(20 - a);
                                    h = (0, f.binning)(this._points, {
                                        radius: r,
                                        shape: o
                                    });
                                    for (var d = -1, v = (h = this._addHeatValue(h)).length; ++d < v;) {
                                        for (var y = [], _ = [], g = [], b = [], m = h[d], w = -1, O = m.length; ++w < O;) {
                                            var x = m[w],
                                                M = x.lngLat,
                                                j = x.index,
                                                k = x.value;
                                            g.push(j), b.push(k), y.push(M), _.push(this._data[j])
                                        }
                                        var P = (0, s.pixel2LngLat)([m.x, m.y], 20);
                                        m[l] = P, m.indexes = g, m.values = b, m.lngLats = y, m.rawData = _
                                    }
                                    this._binMap[u] = h
                                }
                                this._binData = h
                            }
                        }
                    }, {
                        key: "_addHeatValue",
                        value: function(t) {
                            for (var e = -1, n = t.length; ++e < n;) {
                                var r = t[e];
                                r.count = r.length, r.count > 0 && (r.sum = c.default.sumBy(r, "value"), r.mean = c.default.meanBy(r, "value"), r.max = c.default.maxBy(r, "value").value, r.min = c.default.minBy(r, "value").value, r.median = c.default.median(r, "value"))
                            }
                            return t
                        }
                    }, {
                        key: "_updateStyle",
                        value: function(t, e) {
                            var n = this,
                                r = e.style,
                                i = e.style,
                                o = i.radius,
                                a = i.opacity,
                                s = i.color,
                                l = i.gap,
                                h = i.height,
                                p = e.mode,
                                d = t.map(function(t) {
                                    return t[p]
                                }),
                                v = c.default.extent(d),
                                y = (0, f.toAttrOption)(s, {
                                    scale: "quantile",
                                    input: v
                                }),
                                _ = y.value,
                                g = y.scale,
                                b = y.input;
                            "quantile" === g && (b = c.default.chain(d).uniq().sortBy().value());
                            var m = f.Scale.create(g).domain(b).range(_);
                            m.nice && m.nice(), this._colorLegend = [], _.forEach(function(t) {
                                var e = m.invertExtent(t);
                                n._colorLegend.push({
                                    color: t,
                                    range: e
                                })
                            });
                            var w = void 0;
                            c.default.isArray(a) && (w = f.Scale.create().domain(v).range(a));
                            var O = (0, f.toAttrOption)(h, {
                                    scale: "linear",
                                    input: v,
                                    clamp: !0
                                }),
                                x = O.value,
                                M = O.scale,
                                j = O.input,
                                k = O.clamp,
                                P = void 0;
                            c.default.isArray(x) && (P = f.Scale.create(M).domain(j).range(x)).clamp && P.clamp(k), o -= l / 2;
                            for (var E = [], A = -1, L = t.length; ++A < L;) {
                                var C = t[A][p],
                                    S = m(C),
                                    T = w ? w(C) : a,
                                    D = P ? P(C) : x,
                                    I = c.default.defaults({
                                        color: S,
                                        opacity: T,
                                        radius: o,
                                        size: 2 * o,
                                        height: D
                                    }, r);
                                E.push(I)
                            }
                            return this.emit(u.Event.LEGEND_UPDATE, {
                                colorLegend: this._colorLegend
                            }, !0), E
                        }
                    }, {
                        key: "_resetBin",
                        value: function() {
                            delete this._binData
                        }
                    }, {
                        key: "onAdd",
                        value: function(t) {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "onAdd", this).call(this, t), this._group && this._group.addTo(this._owner)
                        }
                    }, {
                        key: "onRemove",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "onRemove", this).call(this), this._group && this._group.remove()
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                e._group.setZIndex(t)
                            }), this
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                t._owner.setBounds(t._bounds)
                            }), this
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            o(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this), this._group.destroy(), delete this._group, delete this._binData, delete this._styleList, delete this._dataOptions, delete this._attrOptions
                        }
                    }]), e
                }();
            e.MapGridHeatMapFeatureGroup = d, e.mapGridHeatMapFeatureGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(d, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapHeatMapFeatureGroup = e.MapHeatMapFeatureGroup = void 0;
            var r = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = n(6),
                a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                u = n(1),
                c = {
                    position: "position",
                    value: "value"
                },
                f = {
                    gradient: {.5: "#2c7bb6", .65: "#abd9e9", .7: "#ffffbf", .9: "#fde468", 1: "#d7191c"
                    }
                },
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o.MapGroup), i(e, [{
                        key: "_initLayout",
                        value: function(t) {
                            var e = this,
                                n = this._map = this._owner.getMap();
                            n.plugin(["AMap.Heatmap"], function() {
                                e._heatmap = new AMap.Heatmap(n), a.default.callFn(t, e)
                            })
                        }
                    }, {
                        key: "_removeLayout",
                        value: function() {
                            var t = this._heatmap;
                            t && (t.setMap(null), delete this._heatmap)
                        }
                    }, {
                        key: "delegateEvent",
                        value: function(t, e) {}
                    }, {
                        key: "setData",
                        value: function(t, e) {
                            var n = this;
                            this._bounds = new u.LngLatBounds, this._data = a.default.clone(t);
                            var i = this._dataOptions = a.default.defaults({}, e, c),
                                o = i.position,
                                f = i.value;
                            return this._heatData = a.default.map(this._data, function(t, e) {
                                var i = (0, u.toLngLat)((0, u.getByKey)(t, o, n, e)),
                                    a = +(0, u.getByKey)(t, f, n, e);
                                n._bounds.expend(i);
                                var c = i.valueOf(),
                                    s = r(c, 2);
                                return {
                                    lng: s[0],
                                    lat: s[1],
                                    count: a
                                }
                            }), this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t) {
                            return this._attrOptions = (0, u.formatVisualOptions)(t, f), this
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this;
                            this.whenReady(function() {
                                var e = t._attrOptions,
                                    n = t._heatData,
                                    r = t._heatmap;
                                if (n && e) {
                                    var i = e.style,
                                        o = i.color,
                                        a = i.radius,
                                        u = i.opacity,
                                        c = e.fitView,
                                        f = t._dataOptions,
                                        s = f.max,
                                        l = f.min;
                                    r.setDataSet({
                                        data: n,
                                        max: s,
                                        min: l
                                    }), r.setOptions({
                                        radius: a,
                                        gradient: o.value,
                                        opacity: u
                                    }), c && t.setFitView()
                                }
                            })
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenReady(function() {
                                e._heatmap.setzIndex(t)
                            }), this
                        }
                    }]), e
                }();
            e.MapHeatMapFeatureGroup = s, e.mapHeatMapFeatureGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DOverlayGroup = e.Map3DOverlayGroup = void 0;
            var o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = function t(e, n, r) {
                    null === e && (e = Function.prototype);
                    var i = Object.getOwnPropertyDescriptor(e, n);
                    if (void 0 === i) {
                        var o = Object.getPrototypeOf(e);
                        return null === o ? void 0 : t(o, n, r)
                    }
                    if ("value" in i) return i.value;
                    var a = i.get;
                    if (void 0 !== a) return a.call(r)
                },
                u = r(n(25)),
                c = r(n(0)),
                f = n(4),
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, u["default"]), o(e, [{
                        key: "_initProperties",
                        value: function() {
                            a(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._3DLayer, this._eventPool = {}
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            var e = this._owner;
                            if (AMap && AMap.Object3DLayer && e && e._map) {
                                if (!this._3DLayer) {
                                    var n = this._options,
                                        r = this._context = this._3DLayer = new AMap.Object3DLayer(null, n);
                                    e._map.add(r);
                                    n.fitView && this.setFitView(), c.default.callFn(t, this)
                                }
                                this._bindMapEvent()
                            }
                        }
                    }, {
                        key: "_removeLayout",
                        value: function() {
                            var t = this._3DLayer;
                            t && t.setMap(null)
                        }
                    }, {
                        key: "_onRedraw",
                        value: function() {
                            if (this._owner)
                                for (var t = this._overlays, e = -1, n = t.length; ++e < n;) {
                                    t[e]._refreshStyle()
                                }
                        }
                    }, {
                        key: "delegateEvent",
                        value: function(t, n) {
                            this.inMapChange || a(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "delegateEvent", this).call(this, t, n)
                        }
                    }, {
                        key: "_bindMapEvent",
                        value: function() {
                            var t, e = this;
                            this._eventPool = (t = {}, i(t, f.Event.MOVE, function() {
                                e.inMapChange = !0
                            }), i(t, f.Event.ZOOM, function() {
                                e.inMapChange = !0
                            }), i(t, f.Event.MOVE_END, function() {
                                e.inMapChange = !1
                            }), i(t, f.Event.ZOOM_END, function() {
                                e.inMapChange = !1
                            }), t);
                            var n = this._eventPool;
                            for (var r in n) this._owner.on(r, n[r])
                        }
                    }, {
                        key: "_removeMapEvent",
                        value: function() {
                            var t = this._owner,
                                e = this._eventPool || {};
                            if (t)
                                for (var n in e) {
                                    var r = e[n];
                                    r && t.off(n, r)
                                }
                            this._eventPool = {}
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            this.whenReady(function() {
                                e._3DLayer.setzIndex(t)
                            })
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this._removeMapEvent(), a(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "destroy", this).call(this)
                        }
                    }]), e
                }();
            e.Map3DOverlayGroup = s, e.map3DOverlayGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapOverlayGroup = e.MapOverlayGroup = void 0;
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(25)),
                u = n(4),
                c = r(n(0)),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_initProperties",
                        value: function() {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._customLayer
                        }
                    }, {
                        key: "_initLayout",
                        value: function(t) {
                            var e = this,
                                n = this._owner;
                            n.getMap().plugin(["AMap.CustomLayer"], function() {
                                if (!e._customLayer) {
                                    var r = e._options,
                                        o = r.opacity,
                                        a = r.blendMode,
                                        f = i(n._size, 2),
                                        s = f[0],
                                        l = f[1],
                                        h = c.default.getPixelRatio(),
                                        p = e._domContainer = c.default.createElement("canvas", {
                                            width: s * h,
                                            height: l * h
                                        }, {
                                            width: s + "px",
                                            height: l + "px"
                                        });
                                    e._setContextConfig({
                                        canvas: p,
                                        baseline: "bottom",
                                        opacity: o,
                                        blendMode: a
                                    });
                                    var d = e._customLayer = new AMap.CustomLayer(p, r);
                                    d.render = function() {
                                        e._onRedraw(), e.emit(u.Event.RENDER)
                                    }, d.setMap(n._map), n.on(u.Event.RESIZE, c.default.debounce(function() {
                                        var t = n.getSize(),
                                            r = i(t, 2),
                                            o = r[0],
                                            c = r[1];
                                        p.width = o * h, p.height = c * h, p.style.width = o + "px", p.style.height = c + "px", e._setContextConfig({
                                            canvas: p,
                                            blendMode: a
                                        }), e._onRedraw(), e.emit(u.Event.RENDER)
                                    }, 300)), c.default.callFn(t, e)
                                }
                            })
                        }
                    }, {
                        key: "_removeLayout",
                        value: function() {
                            var t = this._customLayer;
                            t && (t.render = void 0, t.setMap(null), delete this._customLayer)
                        }
                    }, {
                        key: "_setContextConfig",
                        value: function(t) {
                            var e = t.canvas,
                                n = t.baseline,
                                r = t.opacity,
                                i = t.blendMode;
                            e && (this._context = e.getContext("2d"));
                            var o = this._context;
                            if (o) return n && (o.textBaseline = n), r && (o.globalAlpha = r), i && (o.globalCompositeOperation = i), o
                        }
                    }, {
                        key: "_onRedraw",
                        value: function() {
                            var t = this._owner;
                            if (t) {
                                this.clear(), t.updateMapStatus();
                                for (var e = -1, n = this._overlays, r = n.length; ++e < r;) {
                                    n[e].onAdd()
                                }
                            }
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            this.whenReady(function() {
                                e._customLayer.setzIndex(t)
                            })
                        }
                    }, {
                        key: "getZIndex",
                        value: function() {
                            var t = this._domContainer,
                                e = void 0;
                            return t && (e = t.parentNode) && e.style.zIndex
                        }
                    }, {
                        key: "clear",
                        value: function() {
                            var t = this._domContainer;
                            if (t && this._context) {
                                var e = t.width,
                                    n = t.height;
                                this._context.clearRect(0, 0, e, n)
                            }
                        }
                    }]), e
                }();
            e.MapOverlayGroup = f, e.mapOverlayGroup = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(f, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DAcceptLightPrism = e.Map3DAcceptLightPrism = void 0;
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(12)),
                u = n(1),
                c = n(5),
                f = r(n(0)),
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_initProperties",
                        value: function() {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initProperties", this).call(this), this._defaults = {
                                type: "Map3DAcceptLightPrism",
                                unit: "meter",
                                heightUnit: "meter"
                            }
                        }
                    }, {
                        key: "_initialize",
                        value: function(t, e) {
                            var n = this;
                            this._data = t;
                            var r = this._options = f.default.defaults(e, this._defaults),
                                i = r.position,
                                o = r.heightUnit;
                            this._coord = t.map(function(t, e) {
                                return (0, u.getByKey)(t, i, n, e)
                            });
                            for (var a = this._options, s = a.style, l = a.selectStyle, h = [], p = [], d = -1, v = this._coord.length; ++d < v;) {
                                var y = f.default.clone(s[d] || s),
                                    _ = y.radius,
                                    g = y.topRadius,
                                    b = void 0 === g ? _ : g,
                                    m = y.bottomRadius,
                                    w = void 0 === m ? _ : m,
                                    O = y.height,
                                    x = void 0 === O ? 0 : O,
                                    M = y.altitude,
                                    j = void 0 === M ? 0 : M,
                                    k = y.color,
                                    P = y.opacity,
                                    E = void 0 === P ? 1 : P,
                                    A = y.sideColor,
                                    L = void 0 === A ? k : A,
                                    C = y.sideTopColor,
                                    S = void 0 === C ? L : C,
                                    T = y.sideBottomColor,
                                    D = void 0 === T ? L : T,
                                    I = y.topSideColor,
                                    R = void 0 === I ? k : I,
                                    N = y.topSideOpacity,
                                    z = void 0 === N ? E : N;
                                y.radius = [w, b], "meter" === o && (x = (0, c.meter2Pn)(x), j = (0, c.meter2Pn)(j)), y.height = [x + j, j];
                                var F = u.Color.toFragColor(D, E),
                                    U = u.Color.toFragColor(S, E);
                                if (y.color = [F, U], y.topSideColor = u.Color.toFragColor(R, z), h.push(y), !f.default.isNil(l)) {
                                    var B = f.default.clone(l[d] || l);
                                    k = B.color;
                                    var q = B.opacity;
                                    E = void 0 === q ? E : q;
                                    var G = B.sideColor;
                                    L = void 0 === G ? k : G;
                                    var V = B.sideTopColor;
                                    S = void 0 === V ? L : V;
                                    var Y = B.sideBottomColor;
                                    D = void 0 === Y ? L : Y;
                                    var W = B.topSideColor;
                                    R = void 0 === W ? k : W;
                                    var H = B.topSideOpacity;
                                    z = void 0 === H ? E : H, B.color = [], f.default.isNil(D) || (B.color[0] = u.Color.toFragColor(D, E)), f.default.isNil(S) || (B.color[1] = u.Color.toFragColor(S, E)), f.default.isNil(R) || (B.topSideColor = u.Color.toFragColor(R, z)), p.push(B)
                                }
                            }
                            this._options.style = h, this._options.selectStyle = p.length ? p : void 0, this._setLngLat(this._coord), this._selectIdx = -1, this._preSelectMeshIdx = -1, this._preSelectIdxInMesh = -1, this._selectMeshIdx = -1, this._selectIdxInMesh = -1
                        }
                    }, {
                        key: "_setLngLat",
                        value: function(t) {
                            this._bounds = new u.LngLatBounds, this._coord = (0, u.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "setLngLat",
                        value: function(t) {
                            this._setLngLat(t), this.render()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this._options,
                                e = t.vertex,
                                n = void 0 === e ? 4 : e,
                                r = t.unit,
                                i = t.light,
                                o = void 0 === i ? {
                                    ambient: !0,
                                    directional: !0
                                } : i,
                                a = o.ambient,
                                f = o.directional,
                                s = this.getContainer().getMap();
                            if (a) {
                                var l = a.color,
                                    h = void 0 === l ? "#ffffff" : l,
                                    p = a.intensity,
                                    d = void 0 === p ? .5 : p,
                                    v = new AMap.Lights.AmbientLight(u.Color.toFragColor(h), d);
                                s.AmbientLight = v
                            }
                            if (f) {
                                var y = f.color,
                                    _ = void 0 === y ? "#ffffff" : y,
                                    g = f.intensity,
                                    b = void 0 === g ? .5 : g,
                                    m = f.direction,
                                    w = void 0 === m ? [1, -1, 2] : m,
                                    O = new AMap.Lights.DirectionLight(w, u.Color.toFragColor(_), b);
                                s.DirectionLight = O
                            }
                            for (var x = 2 * n, M = x + 2 * (1 + n), j = M * this._coord.length, k = Math.ceil(j / 65535), P = -1; ++P < k;) {
                                var E = Math.ceil(65535 * P / M),
                                    A = Math.ceil(E + 65535 / M),
                                    L = this._coord.slice(E, A),
                                    C = this._options.style.slice(E, A),
                                    S = [],
                                    T = [],
                                    D = this.getContainer().getZoom(),
                                    I = new AMap.Object3D.MeshAcceptLights;
                                I._dataLength = L.length;
                                for (var R = I.geometry, N = R.vertices, z = R.vertexColors, F = R.faces, U = R.vertexNormals, B = -1, q = L.length; ++B < q;) {
                                    var G = L[B],
                                        V = (0, c.lngLat2G20)(G.valueOf());
                                    S.push(V);
                                    var Y = C[B],
                                        W = Y.radius,
                                        H = Y.height,
                                        Z = Y.color,
                                        X = Y.rotate,
                                        Q = void 0;
                                    if ("meter" === r) {
                                        var $ = (0, c.getGroundResolution)(G.getLat(), 20);
                                        Q = [W[0] / $, W[1] / $]
                                    } else {
                                        var K = (0, c.getScaleInLv)(20) / (0, c.getScaleInLv)(D);
                                        Q = [W[0] * K, W[1] * K]
                                    }
                                    var J = (0, u.getRegularCorners)(V, Q[0], n, X),
                                        tt = (0, u.getRegularCorners)(V, Q[1], n, X);
                                    T.push(tt);
                                    for (var et = B * x, nt = -1; ++nt < n;) {
                                        var rt = tt[nt],
                                            it = J[nt];
                                        N.push(it[0], it[1], -H[1]), N.push(rt[0], rt[1], -H[0]), z.push.apply(z, Z[0]), z.push.apply(z, Z[1]);
                                        var ot = 2 * Math.PI * nt / n,
                                            at = (0, u.cos)(ot),
                                            ut = (0, u.sin)(ot);
                                        U.push(at, ut, 0), U.push(at, ut, 0);
                                        var ct = 2 * nt + et,
                                            ft = ct + 1,
                                            st = (ct + 2) % x + et,
                                            lt = (ct + 3) % x + et;
                                        F.push(ct, ft, lt), F.push(ct, lt, st)
                                    }
                                }
                                for (var ht = q * n * 2, pt = -1; ++pt < q;) {
                                    var dt = C[pt],
                                        vt = (H = dt.height, dt.topSideColor),
                                        yt = S[pt],
                                        _t = T[pt];
                                    N.push(yt[0], yt[1], -H[0]), z.push.apply(z, vt), U.push(0, 0, -1);
                                    for (var gt = -1; ++gt < n;) {
                                        var bt = _t[gt];
                                        N.push(bt[0], bt[1], -H[0]), z.push.apply(z, vt), U.push(0, 0, -1)
                                    }
                                    for (var mt = -1, wt = n * pt + ht + 1 * pt; ++mt < n;) {
                                        var Ot = (wt + 2 + mt) % wt,
                                            xt = wt + 1 + mt,
                                            Mt = Ot <= n ? wt + Ot : Ot % n + wt;
                                        F.push(wt, Mt, xt)
                                    }
                                }
                                I.transparent = !0, this._obj3D.push(I), this._owner._3DLayer.add(I)
                            }
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = this._options.vertex,
                                r = void 0 === n ? 4 : n,
                                i = this.getContainer().getMap().getObject3DByContainerPos({
                                    x: t,
                                    y: e
                                }, [this._owner._3DLayer]);
                            if (this._selectIdx = -1, this._selectMeshIdx = -1, this._selectIdxInMesh = -1, !i) return !1;
                            for (var o = i.object, a = i.index, u = -1, c = this._obj3D.length, f = 0; ++u < c;) {
                                var s = this._obj3D[u];
                                if (s.id === o.id) {
                                    var l = -1,
                                        h = s._dataLength * r * 2;
                                    return l = a >= h ? (a -= h) / r >> 0 : a / r / 2 >> 0, this._selectMeshIdx = u, this._selectIdxInMesh = l, l += f, this._selectIdx = l, !0
                                }
                                f += s._dataLength
                            }
                            return !1
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function() {
                            if (this._obj3D.length) {
                                var t = this._options,
                                    e = t.style,
                                    n = t.selectStyle,
                                    r = t.vertex,
                                    o = this._selectIdx,
                                    a = this._preSelectIdx,
                                    u = this._preSelectMeshIdx,
                                    c = this._preSelectIdxInMesh;
                                if (-1 !== c && -1 !== u && -1 !== a) {
                                    for (var s = e[a] || e[0], l = s.color, h = s.topSideColor, p = this._obj3D[u], d = p._dataLength, v = p.geometry.vertexColors, y = i(l, 2), _ = y[0], g = y[1], b = -1; ++b < r;) {
                                        var m = 4 * (c * r + b) * 2,
                                            w = i(_, 4),
                                            O = w[0],
                                            x = w[1],
                                            M = w[2],
                                            j = w[3];
                                        v.splice(m, 4, O, x, M, j);
                                        var k = i(g, 4);
                                        O = k[0], x = k[1], M = k[2], j = k[3], v.splice(m + 4, 4, O, x, M, j)
                                    }
                                    var P = d * r * 2 * 4,
                                        E = c * (1 + r) * 4,
                                        A = i(h, 4),
                                        L = A[0],
                                        C = A[1],
                                        S = A[2],
                                        T = A[3];
                                    for (v.splice(P + E, 4, L, C, S, T), b = -1; ++b < r;) v.splice(P + E + 4 * (b + 1), 4, L, C, S, T);
                                    p.needUpdate = !0, p.reDraw()
                                }
                                var D = this._selectMeshIdx,
                                    I = this._selectIdxInMesh;
                                if (this._select && -1 !== o) {
                                    this._preSelectIdx = o, this._preSelectMeshIdx = D, this._preSelectIdxInMesh = I;
                                    for (var R = this._obj3D[D], N = R._dataLength, z = R.geometry.vertexColors, F = n[o] || n[0], U = F.color, B = F.topSideColor, q = i(U, 2), G = q[0], V = q[1], Y = -1; ++Y < r;) {
                                        var W = 4 * (I * r + Y) * 2,
                                            H = void 0,
                                            Z = void 0,
                                            X = void 0,
                                            Q = void 0;
                                        if (!f.default.isNil(G)) {
                                            var $ = i(G, 4);
                                            H = $[0], Z = $[1], X = $[2], Q = $[3], z.splice(W, 4, H, Z, X, Q)
                                        }
                                        if (!f.default.isNil(V)) {
                                            var K = i(V, 4);
                                            H = K[0], Z = K[1], X = K[2], Q = K[3], z.splice(W + 4, 4, H, Z, X, Q)
                                        }
                                    }
                                    if (!f.default.isNil(B)) {
                                        var J = i(B, 4),
                                            tt = J[0],
                                            et = J[1],
                                            nt = J[2],
                                            rt = J[3],
                                            it = N * r * 2 * 4,
                                            ot = I * (1 + r) * 4;
                                        for (z.splice(it + ot, 4, tt, et, nt, rt), Y = -1; ++Y < r;) z.splice(it + ot + 4 * (Y + 1), 4, tt, et, nt, rt)
                                    }
                                    R.needUpdate = !0, R.reDraw()
                                }
                            }
                        }
                    }, {
                        key: "getData",
                        value: function(t) {
                            if ((t || {}).selectSingle) {
                                var e = this._selectIdx;
                                if (f.default.isNul(e) || -1 === e) return;
                                var n = f.default.clone(this._data[e]);
                                return n.index = e, n
                            }
                            return f.default.clone(this._data)
                        }
                    }]), e
                }();
            e.Map3DAcceptLightPrism = s, e.map3DAcceptLightPrism = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t) {
                if (Array.isArray(t)) {
                    for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
                    return n
                }
                return Array.from(t)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DContour = e.Map3DContour = void 0;
            var o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(12)),
                u = n(1),
                c = r(n(0)),
                f = {
                    zIndex: 0
                },
                s = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_initialize",
                        value: function(t, e) {
                            this._data = t, this._options = c.default.defaults(e, this._defaults, f), this._coord = t || []
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this._coord.concat([]),
                                e = t.shift(),
                                n = this._options,
                                r = n.style,
                                o = void 0 === r ? {} : r,
                                a = (n.type, o.height),
                                c = o.innerHeight,
                                f = o.color,
                                s = o.opacity,
                                l = void 0 === s ? 1 : s,
                                h = u.Color.toFragColor(f, l),
                                p = AMap.GeometryUtil.triangulateShape(e, t),
                                d = new AMap.Object3D.Mesh;
                            d.backOrFront = "both", d.transparent = !0;
                            var v = d.geometry,
                                y = v.vertices,
                                _ = v.vertexColors,
                                g = v.faces;
                            return e.forEach(function(t) {
                                y.push.apply(y, i(t).concat([-a])), _.push.apply(_, i(h))
                            }), t && t.length && t.forEach(function(t) {
                                t.forEach(function(t) {
                                    y.push.apply(y, i(t).concat([-c])), _.push.apply(_, i(f))
                                })
                            }), p.forEach(function(t) {
                                g.push(t)
                            }), this._owner._3DLayer.add(d), this._obj3D = [d], this
                        }
                    }, {
                        key: "_setLngLat",
                        value: function(t) {
                            this._bounds = new u.LngLatBounds, this._coord = (0, u.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "setLngLat",
                        value: function(t) {
                            this._setLngLat(t), this.render()
                        }
                    }]), e
                }();
            e.Map3DContour = s, e.map3DContour = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(s, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t) {
                if (Array.isArray(t)) {
                    for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
                    return n
                }
                return Array.from(t)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DLine = e.Map3DLine = void 0;
            var o = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                a = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                u = r(n(12)),
                c = n(1),
                f = n(5),
                s = r(n(0)),
                l = r(n(59)),
                h = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, u["default"]), a(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), this._setLngLats(this._coord)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this._coord,
                                e = this._options,
                                n = e.isG20,
                                r = e.heightUnit,
                                a = n ? t : this._lngLats2Container(t),
                                u = this._style || this._options.style,
                                h = [];
                            if (u) {
                                u._coord_ = a;
                                var p = u.stroke,
                                    d = u.color,
                                    v = void 0 === d ? p : d,
                                    y = u.opacity,
                                    _ = void 0 === y ? 1 : y,
                                    g = u.curveness,
                                    b = void 0 === g ? 0 : g,
                                    m = u.height,
                                    w = void 0 === m ? 0 : m;
                                "meter" === r && (w = (0, f.meter2Pn)(w));
                                var O = c.Color.toFragColor(v, _),
                                    x = o(O, 4),
                                    M = x[0],
                                    j = x[1],
                                    k = x[2],
                                    P = x[3];
                                s.default.is2DimArr(a) && (a = [a]);
                                for (var E = 0; E < a.length; E++) {
                                    var A = a[E],
                                        L = A.length,
                                        C = void 0;
                                    if (b) {
                                        var S = [].concat(i(A[0]), [0]),
                                            T = [].concat(i(A[L - 1]), [0]),
                                            D = [(T[0] + S[0]) / 2, (T[1] + S[1]) / 2, 2e6 * b],
                                            I = new l.default([].concat(i(S), D, i(T))),
                                            R = I.length(),
                                            N = R > 500 ? 500 : R;
                                        C = I.getLUT(N)
                                    }
                                    var z = new AMap.Object3D.Line,
                                        F = z.geometry;
                                    z.transparent = !0, b && (L = (A = C).length);
                                    for (var U = 0; U < L; U++) {
                                        var B = A[U];
                                        B.x && (B = [B.x, B.y, B.z]);
                                        var q = o(B, 3),
                                            G = q[0],
                                            V = q[1],
                                            Y = q[2];
                                        F.vertices.push(G, V, -(Y || w || 0)), U < L - 1 && F.segments.push(U, (U + 1) % L), F.vertexColors.push(M, j, k, P)
                                    }
                                    this._owner._3DLayer.add(z), h.push(z)
                                }
                            }
                            return this._obj3D = h, this
                        }
                    }, {
                        key: "_lngLats2Container",
                        value: function(t) {
                            for (var e = [], n = this.getContainer(), r = -1, i = t.length; ++r < i;) {
                                var o = t[r];
                                o instanceof c.LngLat ? e.push(n.lngLat2GeodeticCoord(o)) : e.push(this._lngLats2Container(o))
                            }
                            return e
                        }
                    }, {
                        key: "_setLngLats",
                        value: function(t) {
                            var e = !!this._options.isG20;
                            this._bounds = new c.LngLatBounds, this._coord = e ? t : (0, c.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "setLngLats",
                        value: function(t) {
                            this._setLngLats(t), this.render()
                        }
                    }]), e
                }();
            e.Map3DLine = h, e.map3DLine = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(h, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DPoint = e.Map3DPoint = void 0;
            var r = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(12)),
                a = n(1),
                u = n(5),
                c = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), this._setLngLat(this._coord)
                        }
                    }, {
                        key: "getGridBounds",
                        value: function(t, e) {
                            var n = r(t, 2),
                                i = n[0],
                                o = n[1];
                            return [
                                [i - e, o - e],
                                [i + e, o - e],
                                [i + e, o + e],
                                [i - e, o + e]
                            ].reverse()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.getContainer().getMap();
                            t.AmbientLight = new AMap.Lights.AmbientLight([1, 1, 1], .5), t.DirectionLight = new AMap.Lights.DirectionLight([-6, -2, 14], [1, 1, 1], .5);
                            var e = this._lngLats2Container(this._coord),
                                n = this._style || this._options.style,
                                r = this._options,
                                i = r.type,
                                o = r.heightUnit,
                                c = [];
                            if (n) {
                                n._coord_ = e;
                                var f = n.color,
                                    s = n.fill,
                                    l = void 0 === s ? f : s,
                                    h = n.opacity,
                                    p = void 0 === h ? 1 : h,
                                    d = n.height,
                                    v = void 0 === d ? 0 : d,
                                    y = n.radius,
                                    _ = void 0 === y ? 0 : y,
                                    g = n.fillOpacity,
                                    b = void 0 === g ? p : g;
                                "meter" === o && (v = (0, u.meter2Pn)(v));
                                var m = a.Color.toFragColor(l, b),
                                    w = void 0;
                                w = "hexagon" === i ? a.hexHelper.getHexCorners(e, _) : this.getGridBounds(e, _);
                                var O = new AMap.Object3D.Prism({
                                    path: [w],
                                    height: v || 0,
                                    color: m
                                });
                                O.transparent = !0, O.backAndFront = "both", this._owner._3DLayer.add(O), c.push(O)
                            }
                            return this._obj3D = c, this
                        }
                    }, {
                        key: "_lngLats2Container",
                        value: function(t) {
                            var e = this.getContainer();
                            return t = this._options.isP20 ? (0, u.p20ToG20)([t.getLng(), t.getLat()]) : e.lngLat2GeodeticCoord(t)
                        }
                    }, {
                        key: "_setLngLat",
                        value: function(t) {
                            this._coord = (0, a.toLngLat)(t), this._bounds = new a.LngLatBounds(this._coord)
                        }
                    }, {
                        key: "setLngLat",
                        value: function(t) {
                            this._setLngLat(t), this.render()
                        }
                    }]), e
                }();
            e.Map3DPoint = c, e.map3DPoint = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(c, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DPoints = e.Map3DPoints = void 0;
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                a = r(n(12)),
                u = n(1),
                c = n(5),
                f = r(n(23)),
                s = r(n(0)),
                l = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, a["default"]), o(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            var r = this;
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), this._data = t;
                            var i = (this._options = s.default.defaults(n, this._defaults)).position;
                            this._coord = t.map(function(t, e) {
                                return (0, u.getByKey)(t, i, r, e)
                            }), this.on("imgLoad", function() {
                                r._load = !0
                            });
                            var o = this._options,
                                a = o.style,
                                c = o.selectStyle,
                                l = o.source;
                            "image" === o.type ? (s.default.isArray(l) || (l = [l]), this._options.source = l, f.default.sources2Textures(l, function(t) {
                                r._textures = t, r.emit("imgLoad")
                            }, a[0])) : this.emit("imgLoad"), this._options.style = s.default.isArray(a) ? a : [a], s.default.isNil(c) || (this._options.selectStyle = s.default.isArray(c) ? c : [c]), this._setLngLat(this._coord), this._obj3D = [], this._preSelectIdx = -1, this._selectIdx = -1
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this;
                            return this.whenReady(function() {
                                var e = t._options,
                                    n = e.style,
                                    r = e.heightUnit,
                                    i = e.type,
                                    o = void 0 === i ? "circle" : i,
                                    a = e.crossDateLine,
                                    f = e.source,
                                    l = s.default.getPixelRatio(),
                                    h = void 0;
                                if ("image" === o) {
                                    h = new AMap.Object3D.Points;
                                    var p = t._textures,
                                        d = p.canvas,
                                        v = p.imgAttrMap,
                                        y = d.width,
                                        _ = d.height;
                                    h.textures.push(d);
                                    for (var g = h.geometry, b = -1, m = t._coord.length; ++b < m;) {
                                        var w = t._coord[b],
                                            O = f[b] || f[0];
                                        s.default.isImg(O) && (O = O.src);
                                        var x = n[b] || n[0],
                                            M = (0, c.p20ToG20)((0, c.lngLat2Pixel)(w.valueOf())),
                                            j = v[encodeURI(O)],
                                            k = j.startX,
                                            P = j.endX,
                                            E = j.startY,
                                            A = j.endY,
                                            L = j.width,
                                            C = j.height,
                                            S = x.size,
                                            T = x.altitude,
                                            D = void 0 === T ? 0 : T;
                                        "meter" === r && (D = (0, c.meter2Pn)(D)), g.vertices.push(M[0], M[1], -D);
                                        var I = 0,
                                            R = 0;
                                        s.default.isArray(S) ? (I = +S[0], R = +S[1]) : R = (I = +S) * C / L;
                                        var N = I > R ? I : R;
                                        if (g.pointSizes.push(N * l), I > R) {
                                            var z = (N - R) / N / 2;
                                            g.pointAreas.push(0, z, 1, 1 - z)
                                        } else {
                                            var F = (N - I) / N / 2;
                                            g.pointAreas.push(F, 0, 1 - F, 1)
                                        }
                                        g.vertexUVs.push(k / y, E / _, P / y, A / _)
                                    }
                                } else if ("circle" === o)
                                    for (var U = (h = new AMap.Object3D.RoundPoints).geometry, B = -1, q = t._coord.length; ++B < q;) {
                                        var G = t._coord[B],
                                            V = n[B] || n[0],
                                            Y = G.valueOf(),
                                            W = void 0;
                                        W = a ? (0, c.transCrossDateLine)(Y) : (0, c.lngLat2Pixel)(Y);
                                        var H = (0, c.p20ToG20)(W),
                                            Z = V.radius,
                                            X = V.altitude,
                                            Q = (D = void 0 === X ? 0 : X, V.fill),
                                            $ = V.color,
                                            K = void 0 === $ ? Q : $,
                                            J = V.opacity;
                                        if ("meter" === r && (D = (0, c.meter2Pn)(D)), U.vertices.push(H[0], H[1], -D), U.pointSizes.push(Z * l * 2), !s.default.isNil(K)) {
                                            var tt = u.Color.toFragColor(K, J);
                                            U.vertexColors.push.apply(U.vertexColors, tt)
                                        }
                                    }
                                h.transparent = !0;
                                var et = n[0],
                                    nt = et.stroke,
                                    rt = et.borderColor,
                                    it = void 0 === rt ? nt : rt,
                                    ot = et.lineWidth,
                                    at = et.borderWidth,
                                    ut = void 0 === at ? ot : at,
                                    ct = et.opacity;
                                if (it) {
                                    var ft = u.Color.toFragColor(it, ct);
                                    h.borderColor = ft, h.borderWeight = ut
                                }
                                t._owner._3DLayer.add(h), t._obj3D.push(h)
                            })
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function() {
                            var t = this._obj3D[0];
                            if (t) {
                                var e = t.geometry,
                                    n = e.pointSizes,
                                    r = e.vertexColors,
                                    o = s.default.getPixelRatio(),
                                    a = this._options,
                                    c = a.style,
                                    f = a.selectStyle,
                                    l = this._preSelectIdx;
                                if (-1 !== l) {
                                    var h = c[l] || c[0],
                                        p = h.radius,
                                        d = h.size,
                                        v = h.fill,
                                        y = h.color,
                                        _ = void 0 === y ? v : y,
                                        g = h.opacity;
                                    if (s.default.isNil(p) ? s.default.isNil(d) || (n[l] = d * o) : n[l] = p * o * 2, !s.default.isNil(_)) {
                                        var b = u.Color.toFragColor(_, g),
                                            m = i(b, 4),
                                            w = m[0],
                                            O = m[1],
                                            x = m[2],
                                            M = m[3];
                                        r.splice(4 * l, 4, w, O, x, M)
                                    }
                                    t.needUpdate = !0, t.reDraw()
                                }
                                var j = this._selectIdx;
                                if (this._select && -1 !== j) {
                                    this._preSelectIdx = j;
                                    var k = f[j] || f[0],
                                        P = k.radius,
                                        E = k.fill,
                                        A = k.color,
                                        L = void 0 === A ? E : A,
                                        C = k.opacity;
                                    if (s.default.isNil(P) || (e.pointSizes[j] = P * o * 2), !s.default.isNul(L)) {
                                        var S = u.Color.toFragColor(L, C),
                                            T = i(S, 4),
                                            D = T[0],
                                            I = T[1],
                                            R = T[2],
                                            N = T[3];
                                        e.vertexColors.splice(4 * j, 4, D, I, R, N)
                                    }
                                    t.needUpdate = !0, t.reDraw()
                                }
                            }
                        }
                    }, {
                        key: "_setLngLat",
                        value: function(t) {
                            this._bounds = new u.LngLatBounds, this._coord = (0, u.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "setLngLat",
                        value: function(t) {
                            this._setLngLat(t), this.render()
                        }
                    }, {
                        key: "contains",
                        value: function(t, e) {
                            var n = this.getContainer().getMap().getObject3DByContainerPos({
                                x: t,
                                y: e
                            }, [this._owner._3DLayer]);
                            if (this._selectIdx = -1, !n) return !1;
                            var r = n.object,
                                i = n.index;
                            return this._obj3D[0].id === r.id && (this._selectIdx = i, !0)
                        }
                    }, {
                        key: "getData",
                        value: function(t) {
                            var e = (t || {}).selectSingle,
                                n = this._selectIdx;
                            if (e && -1 != n) {
                                if (s.default.isNul(n)) return;
                                var r = s.default.clone(this._data[n]);
                                return r.index = n, r
                            }
                            return s.default.clone(this._data)
                        }
                    }, {
                        key: "whenReady",
                        value: function(t) {
                            return this._load ? t.call(this) : this.on("imgLoad", t), this
                        }
                    }]), e
                }();
            e.Map3DPoints = l, e.map3DPoints = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(l, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.map3DPolygon = e.Map3DPolygon = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(12)),
                a = n(1),
                u = n(5),
                c = r(n(0)),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), this._setLngLats(this._coord)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.getContainer().getMap(),
                                e = this._owner._3DLayer;
                            this._setLight || (t.AmbientLight = new AMap.Lights.AmbientLight([1, 1, 1], .5), t.DirectionLight = new AMap.Lights.DirectionLight([-6, -2, 14], [1, 1, 1], .5), this._setLight = !0);
                            var n = this._obj3D;
                            n && n.length > 0 && n.forEach(function(t) {
                                e.remove(t)
                            });
                            var r = this._lngLats2Container(this._coord),
                                i = this._style || this._options.style,
                                o = this._options.heightUnit,
                                f = [];
                            if (i) {
                                i._coord_ = r;
                                var s = i.fill,
                                    l = i.color,
                                    h = void 0 === l ? s : l,
                                    p = i.fillOpacity,
                                    d = void 0 === p ? 1 : p,
                                    v = i.height,
                                    y = i.opacity,
                                    _ = void 0 === y ? d : y;
                                if (!h) return this;
                                "meter" === o && (v = (0, u.meter2Pn)(v));
                                var g = a.Color.toFragColor(h, _);
                                c.default.isArray(r) && c.default.isArray(r[0]) || (r = [r]);
                                var b = new AMap.Object3D.Prism({
                                    path: r,
                                    height: v || 0,
                                    color: g
                                });
                                b.transparent = !0, e.add(b), f.push(b)
                            }
                            return this._obj3D = f, this
                        }
                    }, {
                        key: "_lngLats2Container",
                        value: function(t) {
                            for (var e = [], n = -1, r = t.length; ++n < r;) {
                                var i = t[n];
                                i instanceof a.LngLat ? e.push(new AMap.LngLat(i.getLng(), i.getLat())) : e.push(this._lngLats2Container(i))
                            }
                            return e
                        }
                    }, {
                        key: "_setLngLats",
                        value: function(t) {
                            this._bounds = new a.LngLatBounds, this._coord = (0, a.toLngLats)(t, this._bounds)
                        }
                    }, {
                        key: "setLngLats",
                        value: function(t) {
                            this._setLngLats(t), this.render()
                        }
                    }, {
                        key: "_refreshStyle",
                        value: function() {
                            var t = this._options,
                                e = t.selectStyle,
                                n = t.style;
                            this._style = this._select ? c.default.merge({}, n, e) : n, this.render()
                        }
                    }]), e
                }();
            e.Map3DPolygon = f, e.map3DPolygon = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(f, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapPoint = e.MapPoint = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(50)),
                a = r(n(0)),
                u = n(1),
                c = n(5),
                f = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_initialize",
                        value: function(t, n) {
                            (function t(e, n, r) {
                                null === e && (e = Function.prototype);
                                var i = Object.getOwnPropertyDescriptor(e, n);
                                if (void 0 === i) {
                                    var o = Object.getPrototypeOf(e);
                                    return null === o ? void 0 : t(o, n, r)
                                }
                                if ("value" in i) return i.value;
                                var a = i.get;
                                if (void 0 !== a) return a.call(r)
                            })(e.prototype.__proto__ || Object.getPrototypeOf(e.prototype), "_initialize", this).call(this, t, n), this._setLngLat(this._coord)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.getContainer(),
                                e = this._coord,
                                n = t.lngLat2Container(e),
                                r = this._style;
                            if (r) {
                                var i = this._options.unit;
                                if ("meter" === (void 0 === i ? "px" : i)) {
                                    var o = t.getGroundResolution(e),
                                        u = r.radius;
                                    u && (r.r = u / o);
                                    var c = r.size;
                                    if (c) {
                                        a.default.isArray(c) || (c = [c]), r.s = [];
                                        for (var f = -1, s = c.length; ++f < s;) r.s.push(c[f] / o)
                                    }
                                } else r.r = r.radius, r.s = r.size;
                                r._coord_ = n, this._shape.update(n, r).render()
                            }
                            return this
                        }
                    }, {
                        key: "_lngLats2Container",
                        value: function() {}
                    }, {
                        key: "setLngLat",
                        value: function(t) {
                            this._setLngLat(t), this.render()
                        }
                    }, {
                        key: "_setLngLat",
                        value: function(t) {
                            this._options.isP20 && (t = (0, c.pixel2LngLat)(t)), this._coord = (0, u.toLngLat)(t), this._bounds = new u.LngLatBounds(this._coord)
                        }
                    }, {
                        key: "getLngLat",
                        value: function() {
                            return this._coord
                        }
                    }]), e
                }();
            e.MapPoint = f, e.mapPoint = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(f, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.mapPolygon = e.MapPolygon = void 0;
            var r = n(49),
                i = function(t) {
                    function e() {
                        return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e),
                            function(t, e) {
                                if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !e || "object" != typeof e && "function" != typeof e ? t : e
                            }(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, r.MapLine), e
                }();
            e.MapPolygon = i, e.mapPolygon = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(i, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            (function(t, r) {
                var i, o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                    return typeof t
                } : function(t) {
                    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                };
                (function() {
                    function a() {
                        return tn.Date.now()
                    }

                    function u(t, e) {
                        return t.set(e[0], e[1]), t
                    }

                    function c(t, e) {
                        return t.add(e), t
                    }

                    function f(t, e, n) {
                        switch (n.length) {
                            case 0:
                                return t.call(e);
                            case 1:
                                return t.call(e, n[0]);
                            case 2:
                                return t.call(e, n[0], n[1]);
                            case 3:
                                return t.call(e, n[0], n[1], n[2])
                        }
                        return t.apply(e, n)
                    }

                    function s(t, e) {
                        for (var n = -1, r = null == t ? 0 : t.length; ++n < r && !1 !== e(t[n], n, t););
                    }

                    function l(t, e) {
                        for (var n = -1, r = null == t ? 0 : t.length, i = 0, o = []; ++n < r;) {
                            var a = t[n];
                            e(a, n, t) && (o[i++] = a)
                        }
                        return o
                    }

                    function h(t, e) {
                        var n;
                        if (n = !(null == t || !t.length)) {
                            if (e == e) t: {
                                n = -1;
                                for (var r = t.length; ++n < r;)
                                    if (t[n] === e) break t;
                                n = -1
                            } else t: {
                                n = g;
                                r = t.length;
                                for (var i = -1; ++i < r;)
                                    if (n(t[i], i, t)) {
                                        n = i;
                                        break t
                                    }
                                n = -1
                            }
                            n = -1 < n
                        }
                        return n
                    }

                    function p(t, e, n) {
                        for (var r = -1, i = null == t ? 0 : t.length; ++r < i;)
                            if (n(e, t[r])) return !0;
                        return !1
                    }

                    function d(t, e) {
                        for (var n = -1, r = null == t ? 0 : t.length, i = Array(r); ++n < r;) i[n] = e(t[n], n, t);
                        return i
                    }

                    function v(t, e) {
                        for (var n = -1, r = e.length, i = t.length; ++n < r;) t[i + n] = e[n];
                        return t
                    }

                    function y(t, e, n) {
                        for (var r = -1, i = null == t ? 0 : t.length; ++r < i;) n = e(n, t[r], r, t);
                        return n
                    }

                    function _(t, e) {
                        for (var n = -1, r = null == t ? 0 : t.length; ++n < r;)
                            if (e(t[n], n, t)) return !0;
                        return !1
                    }

                    function g(t) {
                        return t != t
                    }

                    function b(t, e) {
                        var n = null == t ? 0 : t.length;
                        return n ? m(t, e) / n : Ae
                    }

                    function m(t, e) {
                        for (var n, r = -1, i = t.length; ++r < i;) {
                            var o = e(t[r]);
                            o !== Pe && (n = n === Pe ? o : n + o)
                        }
                        return n
                    }

                    function w(t) {
                        return function(e) {
                            return t(e)
                        }
                    }

                    function O(t, e) {
                        return t.has(e)
                    }

                    function x(t) {
                        var e = -1,
                            n = Array(t.size);
                        return t.forEach(function(t, r) {
                            n[++e] = [r, t]
                        }), n
                    }

                    function M(t) {
                        var e = Object;
                        return function(n) {
                            return t(e(n))
                        }
                    }

                    function j(t, e) {
                        for (var n = -1, r = t.length, i = 0, o = []; ++n < r;) {
                            var a = t[n];
                            a !== e && "__lodash_placeholder__" !== a || (t[n] = "__lodash_placeholder__", o[i++] = n)
                        }
                        return o
                    }

                    function k(t) {
                        var e = -1,
                            n = Array(t.size);
                        return t.forEach(function(t) {
                            n[++e] = t
                        }), n
                    }

                    function P(t) {
                        if (ie(t) && !dr(t) && !(t instanceof L)) {
                            if (t instanceof A) return t;
                            if (ln.call(t, "__wrapped__")) return Gt(t)
                        }
                        return new A(t)
                    }

                    function E() {}

                    function A(t, e) {
                        this.__wrapped__ = t, this.__actions__ = [], this.__chain__ = !!e, this.__index__ = 0, this.__values__ = Pe
                    }

                    function L(t) {
                        this.__wrapped__ = t, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = 4294967295, this.__views__ = []
                    }

                    function C(t) {
                        var e = -1,
                            n = null == t ? 0 : t.length;
                        for (this.clear(); ++e < n;) {
                            var r = t[e];
                            this.set(r[0], r[1])
                        }
                    }

                    function S(t) {
                        var e = -1,
                            n = null == t ? 0 : t.length;
                        for (this.clear(); ++e < n;) {
                            var r = t[e];
                            this.set(r[0], r[1])
                        }
                    }

                    function T(t) {
                        var e = -1,
                            n = null == t ? 0 : t.length;
                        for (this.clear(); ++e < n;) {
                            var r = t[e];
                            this.set(r[0], r[1])
                        }
                    }

                    function D(t) {
                        var e = -1,
                            n = null == t ? 0 : t.length;
                        for (this.__data__ = new T; ++e < n;) this.add(t[e])
                    }

                    function I(t) {
                        this.size = (this.__data__ = new S(t)).size
                    }

                    function R(t, e) {
                        var n = dr(t),
                            r = !n && pr(t),
                            i = !n && !r && vr(t),
                            o = !n && !r && !i && yr(t);
                        if (n = n || r || i || o) {
                            r = t.length;
                            for (var a = String, u = -1, c = Array(r); ++u < r;) c[u] = a(u);
                            r = c
                        } else r = [];
                        var f;
                        a = r.length;
                        for (f in t)!e && !ln.call(t, f) || n && ("length" == f || i && ("offset" == f || "parent" == f) || o && ("buffer" == f || "byteLength" == f || "byteOffset" == f) || St(f, a)) || r.push(f);
                        return r
                    }

                    function N(t, e, n) {
                        (n === Pe || Kt(t[e], n)) && (n !== Pe || e in t) || U(t, e, n)
                    }

                    function z(t, e, n) {
                        var r = t[e];
                        ln.call(t, e) && Kt(r, n) && (n !== Pe || e in t) || U(t, e, n)
                    }

                    function F(t, e) {
                        for (var n = t.length; n--;)
                            if (Kt(t[n][0], e)) return n;
                        return -1
                    }

                    function U(t, e, n) {
                        "__proto__" == e && En ? En(t, e, {
                            configurable: !0,
                            enumerable: !0,
                            value: n,
                            writable: !0
                        }) : t[e] = n
                    }

                    function B(t, e, n, r, i, o) {
                        var a, f = 1 & e,
                            l = 2 & e,
                            h = 4 & e;
                        if (n && (a = i ? n(t, r, i, o) : n(t)), a !== Pe) return a;
                        if (!re(t)) return t;
                        if (r = dr(t)) {
                            if (a = function(t) {
                                var e = t.length,
                                    n = t.constructor(e);
                                return e && "string" == typeof t[0] && ln.call(t, "index") && (n.index = t.index, n.input = t.input), n
                            }(t), !f) return dt(t, a)
                        } else {
                            var p = ur(t),
                                d = "[object Function]" == p || "[object GeneratorFunction]" == p;
                            if (vr(t)) return ft(t, f);
                            if ("[object Object]" == p || "[object Arguments]" == p || d && !i) {
                                if (a = l || d ? {} : Lt(t), !f) return l ? function(t, e) {
                                    return vt(t, ar(t), e)
                                }(t, function(t, e) {
                                    return t && vt(e, _e(e), t)
                                }(a, t)) : function(t, e) {
                                    return vt(t, or(t), e)
                                }(t, function(t, e) {
                                    return t && vt(e, ye(e), t)
                                }(a, t))
                            } else {
                                if (!Xe[p]) return i ? t : {};
                                a = function(t, e, n, r) {
                                    var i = t.constructor;
                                    switch (e) {
                                        case "[object ArrayBuffer]":
                                            return st(t);
                                        case "[object Boolean]":
                                        case "[object Date]":
                                            return new i(+t);
                                        case "[object DataView]":
                                            return e = r ? st(t.buffer) : t.buffer, new t.constructor(e, t.byteOffset, t.byteLength);
                                        case "[object Float32Array]":
                                        case "[object Float64Array]":
                                        case "[object Int8Array]":
                                        case "[object Int16Array]":
                                        case "[object Int32Array]":
                                        case "[object Uint8Array]":
                                        case "[object Uint8ClampedArray]":
                                        case "[object Uint16Array]":
                                        case "[object Uint32Array]":
                                            return lt(t, r);
                                        case "[object Map]":
                                            return e = r ? n(x(t), 1) : x(t), y(e, u, new t.constructor);
                                        case "[object Number]":
                                        case "[object String]":
                                            return new i(t);
                                        case "[object RegExp]":
                                            return e = new t.constructor(t.source, Ue.exec(t)), e.lastIndex = t.lastIndex, e;
                                        case "[object Set]":
                                            return e = r ? n(k(t), 1) : k(t), y(e, c, new t.constructor);
                                        case "[object Symbol]":
                                            return Qn ? Object(Qn.call(t)) : {}
                                    }
                                }(t, p, B, f)
                            }
                        } if (o || (o = new I), i = o.get(t)) return i;
                        o.set(t, a);
                        l = h ? l ? jt : Mt : l ? _e : ye;
                        var v = r ? Pe : l(t);
                        return s(v || t, function(r, i) {
                            v && (i = r, r = t[i]), z(a, i, B(r, e, n, i, t, o))
                        }), a
                    }

                    function q(t, e, n) {
                        for (var r = -1, i = t.length; ++r < i;) {
                            var o = t[r],
                                a = e(o);
                            if (null != a && (u === Pe ? a == a && !ue(a) : n(a, u))) var u = a,
                                c = o
                        }
                        return c
                    }

                    function G(t, e, n, r, i) {
                        var o = -1,
                            a = t.length;
                        for (n || (n = Ct), i || (i = []); ++o < a;) {
                            var u = t[o];
                            0 < e && n(u) ? 1 < e ? G(u, e - 1, n, r, i) : v(i, u) : r || (i[i.length] = u)
                        }
                        return i
                    }

                    function V(t, e) {
                        return t && tr(t, e, ye)
                    }

                    function Y(t, e) {
                        return l(e, function(e) {
                            return ee(t[e])
                        })
                    }

                    function W(t, e) {
                        for (var n = 0, r = (e = ct(e, t)).length; null != t && n < r;) t = t[Ut(e[n++])];
                        return n && n == r ? t : Pe
                    }

                    function H(t, e, n) {
                        return e = e(t), dr(t) ? e : v(e, n(t))
                    }

                    function Z(t) {
                        if (null == t) t = t === Pe ? "[object Undefined]" : "[object Null]";
                        else if (Pn && Pn in Object(t)) {
                            var e = ln.call(t, Pn),
                                n = t[Pn];
                            try {
                                t[Pn] = Pe;
                                var r = !0
                            } catch (t) {}
                            var i = pn.call(t);
                            r && (e ? t[Pn] = n : delete t[Pn]), t = i
                        } else t = pn.call(t);
                        return t
                    }

                    function X(t, e) {
                        return t > e
                    }

                    function Q(t) {
                        return ie(t) && "[object Arguments]" == Z(t)
                    }

                    function $(t, e, n, r, i) {
                        if (t === e) e = !0;
                        else if (null == t || null == e || !ie(t) && !ie(e)) e = t != t && e != e;
                        else t: {
                            var o = dr(t),
                                a = dr(e),
                                u = o ? "[object Array]" : ur(t),
                                c = a ? "[object Array]" : ur(e),
                                f = "[object Object]" == (u = "[object Arguments]" == u ? "[object Object]" : u);
                            a = "[object Object]" == (c = "[object Arguments]" == c ? "[object Object]" : c);
                            if ((c = u == c) && vr(t)) {
                                if (!vr(e)) {
                                    e = !1;
                                    break t
                                }
                                o = !0, f = !1
                            }
                            if (c && !f) i || (i = new I), e = o || yr(t) ? xt(t, e, n, r, $, i) : function(t, e, n, r, i, o, a) {
                                switch (n) {
                                    case "[object DataView]":
                                        if (t.byteLength != e.byteLength || t.byteOffset != e.byteOffset) break;
                                        t = t.buffer, e = e.buffer;
                                    case "[object ArrayBuffer]":
                                        if (t.byteLength != e.byteLength || !o(new bn(t), new bn(e))) break;
                                        return !0;
                                    case "[object Boolean]":
                                    case "[object Date]":
                                    case "[object Number]":
                                        return Kt(+t, +e);
                                    case "[object Error]":
                                        return t.name == e.name && t.message == e.message;
                                    case "[object RegExp]":
                                    case "[object String]":
                                        return t == e + "";
                                    case "[object Map]":
                                        var u = x;
                                    case "[object Set]":
                                        if (u || (u = k), t.size != e.size && !(1 & r)) break;
                                        return (n = a.get(t)) ? n == e : (r |= 2, a.set(t, e), e = xt(u(t), u(e), r, i, o, a), a.delete(t), e);
                                    case "[object Symbol]":
                                        if (Qn) return Qn.call(t) == Qn.call(e)
                                }
                                return !1
                            }(t, e, u, n, r, $, i);
                            else {
                                if (!(1 & n) && (o = f && ln.call(t, "__wrapped__"), u = a && ln.call(e, "__wrapped__"), o || u)) {
                                    t = o ? t.value() : t, e = u ? e.value() : e, i || (i = new I), e = $(t, e, n, r, i);
                                    break t
                                }
                                if (c) e: if (i || (i = new I), o = 1 & n, u = Mt(t), a = u.length, c = Mt(e).length, a == c || o) {
                                    for (f = a; f--;) {
                                        var s = u[f];
                                        if (!(o ? s in e : ln.call(e, s))) {
                                            e = !1;
                                            break e
                                        }
                                    }
                                    if ((c = i.get(t)) && i.get(e)) e = c == e;
                                    else {
                                        c = !0, i.set(t, e), i.set(e, t);
                                        for (var l = o; ++f < a;) {
                                            var h = t[s = u[f]],
                                                p = e[s];
                                            if (r) var d = o ? r(p, h, s, e, t, i) : r(h, p, s, t, e, i);
                                            if (d === Pe ? h !== p && !$(h, p, n, r, i) : !d) {
                                                c = !1;
                                                break
                                            }
                                            l || (l = "constructor" == s)
                                        }
                                        c && !l && (n = t.constructor, r = e.constructor, n != r && "constructor" in t && "constructor" in e && !("function" == typeof n && n instanceof n && "function" == typeof r && r instanceof r) && (c = !1)), i.delete(t), i.delete(e), e = c
                                    }
                                } else e = !1;
                                else e = !1
                            }
                        }
                        return e
                    }

                    function K(t) {
                        return "function" == typeof t ? t : null == t ? me : "object" == (void 0 === t ? "undefined" : o(t)) ? dr(t) ? function(t, e) {
                            return Dt(t) && e == e && !re(e) ? Rt(Ut(t), e) : function(n) {
                                var r = de(n, t);
                                return r === Pe && r === e ? ve(n, t) : $(e, r, 3)
                            }
                        }(t[0], t[1]) : function(t) {
                            var e = function(t) {
                                for (var e = ye(t), n = e.length; n--;) {
                                    var r = e[n],
                                        i = t[r];
                                    e[n] = [r, i, i == i && !re(i)]
                                }
                                return e
                            }(t);
                            return 1 == e.length && e[0][2] ? Rt(e[0][0], e[0][1]) : function(n) {
                                return n === t || function(t, e) {
                                    var n = e.length,
                                        r = n;
                                    if (null == t) return !r;
                                    for (t = Object(t); n--;)
                                        if ((i = e[n])[2] ? i[1] !== t[i[0]] : !(i[0] in t)) return !1;
                                    for (; ++n < r;) {
                                        var i, o = (i = e[n])[0],
                                            a = t[o],
                                            u = i[1];
                                        if (i[2]) {
                                            if (a === Pe && !(o in t)) return !1
                                        } else if (i = new I, void 0 !== Pe || !$(u, a, 3, void 0, i)) return !1
                                    }
                                    return !0
                                }(n, e)
                            }
                        }(t) : Me(t)
                    }

                    function J(t, e) {
                        return t < e
                    }

                    function tt(t, e) {
                        var n = -1,
                            r = Jt(t) ? Array(t.length) : [];
                        return Jn(t, function(t, i, o) {
                            r[++n] = e(t, i, o)
                        }), r
                    }

                    function et(t, e, n, r, i) {
                        t !== e && tr(e, function(o, a) {
                            if (re(o)) {
                                i || (i = new I);
                                var u = i,
                                    c = t[a],
                                    f = e[a];
                                if (d = u.get(f)) N(t, a, d);
                                else {
                                    var s = (d = r ? r(c, f, a + "", t, e, u) : Pe) === Pe;
                                    if (s) {
                                        var l = dr(f),
                                            h = !l && vr(f),
                                            p = !l && !h && yr(f),
                                            d = f;
                                        l || h || p ? dr(c) ? d = c : te(c) ? d = dt(c) : h ? (s = !1, d = ft(f, !0)) : p ? (s = !1, d = lt(f, !0)) : d = [] : oe(f) || pr(f) ? (d = c, pr(c) ? d = he(c) : (!re(c) || n && ee(c)) && (d = Lt(f))) : s = !1
                                    }
                                    s && (u.set(f, d), et(d, f, n, r, u), u.delete(f)), N(t, a, d)
                                }
                            } else(u = r ? r(t[a], o, a + "", t, e, i) : Pe) === Pe && (u = o), N(t, a, u)
                        }, _e)
                    }

                    function nt(t) {
                        return fr(Nt(t, void 0, me), t + "")
                    }

                    function rt(t, e) {
                        for (var n = -1, r = t.length, i = 0, o = []; ++n < r;) {
                            var a = t[n],
                                u = e ? e(a) : a;
                            if (!n || !Kt(u, c)) {
                                var c = u;
                                o[i++] = 0 === a ? 0 : a
                            }
                        }
                        return o
                    }

                    function it(t) {
                        return "number" == typeof t ? t : ue(t) ? Ae : +t
                    }

                    function ot(t) {
                        if ("string" == typeof t) return t;
                        if (dr(t)) return d(t, ot) + "";
                        if (ue(t)) return $n ? $n.call(t) : "";
                        var e = t + "";
                        return "0" == e && 1 / t == -Ee ? "-0" : e
                    }

                    function at(t, e, n) {
                        var r = -1,
                            i = h,
                            o = t.length,
                            a = !0,
                            u = [],
                            c = u;
                        if (n) a = !1, i = p;
                        else if (200 <= o) {
                            if (i = e ? null : rr(t)) return k(i);
                            a = !1, i = O, c = new D
                        } else c = e ? [] : u;
                        t: for (; ++r < o;) {
                            var f = t[r],
                                s = e ? e(f) : f;
                            f = n || 0 !== f ? f : 0;
                            if (a && s == s) {
                                for (var l = c.length; l--;)
                                    if (c[l] === s) continue t;
                                e && c.push(s), u.push(f)
                            } else i(c, s, n) || (c !== u && c.push(s), u.push(f))
                        }
                        return u
                    }

                    function ut(t, e) {
                        var n = t;
                        return n instanceof L && (n = n.value()), y(e, function(t, e) {
                            return e.func.apply(e.thisArg, v([t], e.args))
                        }, n)
                    }

                    function ct(t, e) {
                        return dr(t) ? t : Dt(t, e) ? [t] : sr(pe(t))
                    }

                    function ft(t, e) {
                        if (e) return t.slice();
                        var n = t.length;
                        n = mn ? mn(n) : new t.constructor(n);
                        return t.copy(n), n
                    }

                    function st(t) {
                        var e = new t.constructor(t.byteLength);
                        return new bn(e).set(new bn(t)), e
                    }

                    function lt(t, e) {
                        return new t.constructor(e ? st(t.buffer) : t.buffer, t.byteOffset, t.length)
                    }

                    function ht(t, e, n, r) {
                        var i = -1,
                            o = t.length,
                            a = n.length,
                            u = -1,
                            c = e.length,
                            f = Sn(o - a, 0),
                            s = Array(c + f);
                        for (r = !r; ++u < c;) s[u] = e[u];
                        for (; ++i < a;)(r || i < o) && (s[n[i]] = t[i]);
                        for (; f--;) s[u++] = t[i++];
                        return s
                    }

                    function pt(t, e, n, r) {
                        var i = -1,
                            o = t.length,
                            a = -1,
                            u = n.length,
                            c = -1,
                            f = e.length,
                            s = Sn(o - u, 0),
                            l = Array(s + f);
                        for (r = !r; ++i < s;) l[i] = t[i];
                        for (s = i; ++c < f;) l[s + c] = e[c];
                        for (; ++a < u;)(r || i < o) && (l[s + n[a]] = t[i++]);
                        return l
                    }

                    function dt(t, e) {
                        var n = -1,
                            r = t.length;
                        for (e || (e = Array(r)); ++n < r;) e[n] = t[n];
                        return e
                    }

                    function vt(t, e, n, r) {
                        var i = !n;
                        n || (n = {});
                        for (var o = -1, a = e.length; ++o < a;) {
                            var u = e[o],
                                c = r ? r(n[u], t[u], u, n, t) : Pe;
                            c === Pe && (c = t[u]), i ? U(n, u, c) : z(n, u, c)
                        }
                        return n
                    }

                    function yt(t) {
                        return nt(function(e, n) {
                            var r = -1,
                                i = n.length,
                                o = 1 < i ? n[i - 1] : Pe,
                                a = 2 < i ? n[2] : Pe;
                            o = 3 < t.length && "function" == typeof o ? (i--, o) : Pe;
                            for (a && Tt(n[0], n[1], a) && (o = 3 > i ? Pe : o, i = 1), e = Object(e); ++r < i;)(a = n[r]) && t(e, a, r, o);
                            return e
                        })
                    }

                    function _t(t) {
                        return function() {
                            switch ((e = arguments).length) {
                                case 0:
                                    return new t;
                                case 1:
                                    return new t(e[0]);
                                case 2:
                                    return new t(e[0], e[1]);
                                case 3:
                                    return new t(e[0], e[1], e[2]);
                                case 4:
                                    return new t(e[0], e[1], e[2], e[3]);
                                case 5:
                                    return new t(e[0], e[1], e[2], e[3], e[4]);
                                case 6:
                                    return new t(e[0], e[1], e[2], e[3], e[4], e[5]);
                                case 7:
                                    return new t(e[0], e[1], e[2], e[3], e[4], e[5], e[6])
                            }
                            var e, n = Kn(t.prototype);
                            return re(e = t.apply(n, e)) ? e : n
                        }
                    }

                    function gt(t, e, n, r, i, o, a, u, c, f) {
                        function s() {
                            for (var _ = arguments.length, g = Array(_), b = _; b--;) g[b] = arguments[b];
                            if (d) {
                                var m, w = kt(s);
                                b = g.length;
                                for (m = 0; b--;) g[b] === w && ++m
                            }
                            if (r && (g = ht(g, r, i, d)), o && (g = pt(g, o, a, d)), _ -= m, d && _ < f) return w = j(g, w), mt(t, e, gt, s.placeholder, n, g, w, u, c, f - _);
                            if (w = h ? n : this, b = p ? w[t] : t, _ = g.length, u) {
                                m = g.length;
                                for (var O = Tn(u.length, m), x = dt(g); O--;) {
                                    var M = u[O];
                                    g[O] = St(M, m) ? x[M] : Pe
                                }
                            } else v && 1 < _ && g.reverse();
                            return l && c < _ && (g.length = c), this && this !== tn && this instanceof s && (b = y || _t(b)), b.apply(w, g)
                        }
                        var l = 128 & e,
                            h = 1 & e,
                            p = 2 & e,
                            d = 24 & e,
                            v = 512 & e,
                            y = p ? Pe : _t(t);
                        return s
                    }

                    function bt(t, e) {
                        return function(n, r) {
                            var i;
                            if (n === Pe && r === Pe) return e;
                            if (n !== Pe && (i = n), r !== Pe) {
                                if (i === Pe) return r;
                                "string" == typeof n || "string" == typeof r ? (n = ot(n), r = ot(r)) : (n = it(n), r = it(r)), i = t(n, r)
                            }
                            return i
                        }
                    }

                    function mt(t, e, n, r, i, o, a, u, c, f) {
                        var s = 8 & e,
                            l = s ? a : Pe;
                        a = s ? Pe : a;
                        var h = s ? o : Pe;
                        o = s ? Pe : o, 4 & (e = (e | (s ? 32 : 64)) & ~(s ? 64 : 32)) || (e &= -4), i = [t, e, i, h, l, o, a, u, c, f], n = n.apply(Pe, i);
                        t: for (u = t.name + "", c = Gn[u], f = ln.call(Gn, u) ? c.length : 0; f--;)
                            if (s = c[f], null == (l = s.func) || l == t) {
                                u = s.name;
                                break t
                            }
                        return "function" == typeof(c = P[u]) && u in L.prototype ? t === c ? u = !0 : (u = ir(c), u = !!u && t === u[0]) : u = !1, u && cr(n, i), n.placeholder = r, zt(n, t, e)
                    }

                    function wt(t) {
                        var e = Math[t];
                        return function(t, n) {
                            if (t = le(t), n = null == n ? 0 : Tn(se(n), 292)) {
                                var r = (pe(t) + "e").split("e");
                                return +((r = (pe(r = e(r[0] + "e" + (+r[1] + n))) + "e").split("e"))[0] + "e" + (+r[1] - n))
                            }
                            return e(t)
                        }
                    }

                    function Ot(t, e, n, r) {
                        return t === Pe || Kt(t, cn[n]) && !ln.call(r, n) ? e : t
                    }

                    function xt(t, e, n, r, i, o) {
                        var a = 1 & n,
                            u = t.length;
                        if (u != (c = e.length) && !(a && c > u)) return !1;
                        if ((c = o.get(t)) && o.get(e)) return c == e;
                        var c = -1,
                            f = !0,
                            s = 2 & n ? new D : Pe;
                        for (o.set(t, e), o.set(e, t); ++c < u;) {
                            var l = t[c],
                                h = e[c];
                            if (r) var p = a ? r(h, l, c, e, t, o) : r(l, h, c, t, e, o);
                            if (p !== Pe) {
                                if (p) continue;
                                f = !1;
                                break
                            }
                            if (s) {
                                if (!_(e, function(t, e) {
                                    if (!O(s, e) && (l === t || i(l, t, n, r, o))) return s.push(e)
                                })) {
                                    f = !1;
                                    break
                                }
                            } else if (l !== h && !i(l, h, n, r, o)) {
                                f = !1;
                                break
                            }
                        }
                        return o.delete(t), o.delete(e), f
                    }

                    function Mt(t) {
                        return H(t, ye, or)
                    }

                    function jt(t) {
                        return H(t, _e, ar)
                    }

                    function kt(t) {
                        return (ln.call(P, "placeholder") ? P : t).placeholder
                    }

                    function Pt() {
                        var t = (t = P.iteratee || we) === we ? K : t;
                        return arguments.length ? t(arguments[0], arguments[1]) : t
                    }

                    function Et(t, e) {
                        var n = t.__data__,
                            r = void 0 === e ? "undefined" : o(e);
                        return ("string" == r || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== e : null === e) ? n["string" == typeof e ? "string" : "hash"] : n.map
                    }

                    function At(t, e) {
                        var n = null == t ? Pe : t[e];
                        return !re(n) || hn && hn in n || !(ee(n) ? yn : Ge).test(Bt(n)) ? Pe : n
                    }

                    function Lt(t) {
                        return "function" != typeof t.constructor || It(t) ? {} : Kn(wn(t))
                    }

                    function Ct(t) {
                        return dr(t) || pr(t) || !!(jn && t && t[jn])
                    }

                    function St(t, e) {
                        return !!(e = null == e ? 9007199254740991 : e) && ("number" == typeof t || Ye.test(t)) && -1 < t && 0 == t % 1 && t < e
                    }

                    function Tt(t, e, n) {
                        if (!re(n)) return !1;
                        var r = void 0 === e ? "undefined" : o(e);
                        return !!("number" == r ? Jt(n) && St(e, n.length) : "string" == r && e in n) && Kt(n[e], t)
                    }

                    function Dt(t, e) {
                        if (dr(t)) return !1;
                        var n = void 0 === t ? "undefined" : o(t);
                        return !("number" != n && "symbol" != n && "boolean" != n && null != t && !ue(t)) || Se.test(t) || !Ce.test(t) || null != e && t in Object(e)
                    }

                    function It(t) {
                        var e = t && t.constructor;
                        return t === ("function" == typeof e && e.prototype || cn)
                    }

                    function Rt(t, e) {
                        return function(n) {
                            return null != n && n[t] === e && (e !== Pe || t in Object(n))
                        }
                    }

                    function Nt(t, e, n) {
                        return e = Sn(e === Pe ? t.length - 1 : e, 0),
                            function() {
                                for (var r = arguments, i = -1, o = Sn(r.length - e, 0), a = Array(o); ++i < o;) a[i] = r[e + i];
                                for (i = -1, o = Array(e + 1); ++i < e;) o[i] = r[i];
                                return o[e] = n(a), f(t, this, o)
                            }
                    }

                    function zt(t, e, n) {
                        var r = e + "";
                        e = fr;
                        var i, o = qt;
                        return i = (i = r.match(Ne)) ? i[1].split(ze) : [], n = o(i, n), (o = n.length) && (i = o - 1, n[i] = (1 < o ? "& " : "") + n[i], n = n.join(2 < o ? ", " : " "), r = r.replace(Re, "{\n/* [wrapped with " + n + "] */\n")), e(t, r)
                    }

                    function Ft(t) {
                        var e = 0,
                            n = 0;
                        return function() {
                            var r = Dn(),
                                i = 16 - (r - n);
                            if (n = r, 0 < i) {
                                if (800 <= ++e) return arguments[0]
                            } else e = 0;
                            return t.apply(Pe, arguments)
                        }
                    }

                    function Ut(t) {
                        if ("string" == typeof t || ue(t)) return t;
                        var e = t + "";
                        return "0" == e && 1 / t == -Ee ? "-0" : e
                    }

                    function Bt(t) {
                        if (null != t) {
                            try {
                                return sn.call(t)
                            } catch (t) {}
                            return t + ""
                        }
                        return ""
                    }

                    function qt(t, e) {
                        return s(Le, function(n) {
                            var r = "_." + n[0];
                            e & n[1] && !h(t, r) && t.push(r)
                        }), t.sort()
                    }

                    function Gt(t) {
                        if (t instanceof L) return t.clone();
                        var e = new A(t.__wrapped__, t.__chain__);
                        return e.__actions__ = dt(t.__actions__), e.__index__ = t.__index__, e.__values__ = t.__values__, e
                    }

                    function Vt(t) {
                        return null != t && t.length ? G(t, 1) : []
                    }

                    function Yt(t) {
                        var e = null == t ? 0 : t.length;
                        return e ? t[e - 1] : Pe
                    }

                    function Wt(t) {
                        return null == t ? t : In.call(t)
                    }

                    function Ht(t) {
                        return t = P(t), t.__chain__ = !0, t
                    }

                    function Zt(t, e) {
                        return e(t)
                    }

                    function Xt(t, e, n) {
                        function r(e) {
                            var n = f,
                                r = s;
                            return f = s = Pe, v = e, h = t.apply(r, n)
                        }

                        function i(t) {
                            var n = t - d;
                            return t -= v, d === Pe || n >= e || 0 > n || _ && t >= l
                        }

                        function o() {
                            var t = a();
                            if (i(t)) return u(t);
                            var n, r = setTimeout;
                            n = t - v, t = e - (t - d), n = _ ? Tn(t, l - n) : t, p = r(o, n)
                        }

                        function u(t) {
                            return p = Pe, g && f ? r(t) : (f = s = Pe, h)
                        }

                        function c() {
                            var t = a(),
                                n = i(t);
                            if (f = arguments, s = this, d = t, n) {
                                if (p === Pe) return v = t = d, p = setTimeout(o, e), y ? r(t) : h;
                                if (_) return p = setTimeout(o, e), r(d)
                            }
                            return p === Pe && (p = setTimeout(o, e)), h
                        }
                        var f, s, l, h, p, d, v = 0,
                            y = !1,
                            _ = !1,
                            g = !0;
                        if ("function" != typeof t) throw new TypeError("Expected a function");
                        return e = le(e) || 0, re(n) && (y = !!n.leading, l = (_ = "maxWait" in n) ? Sn(le(n.maxWait) || 0, e) : l, g = "trailing" in n ? !!n.trailing : g), c.cancel = function() {
                            p !== Pe && clearTimeout(p), v = 0, f = d = s = p = Pe
                        }, c.flush = function() {
                            return p === Pe ? h : u(a())
                        }, c
                    }

                    function Qt(t, e) {
                        function n() {
                            var r = arguments,
                                i = e ? e.apply(this, r) : r[0],
                                o = n.cache;
                            return o.has(i) ? o.get(i) : (r = t.apply(this, r), n.cache = o.set(i, r) || o, r)
                        }
                        if ("function" != typeof t || null != e && "function" != typeof e) throw new TypeError("Expected a function");
                        return n.cache = new(Qt.Cache || T), n
                    }

                    function $t(t) {
                        if ("function" != typeof t) throw new TypeError("Expected a function");
                        return function() {
                            var e = arguments;
                            switch (e.length) {
                                case 0:
                                    return !t.call(this);
                                case 1:
                                    return !t.call(this, e[0]);
                                case 2:
                                    return !t.call(this, e[0], e[1]);
                                case 3:
                                    return !t.call(this, e[0], e[1], e[2])
                            }
                            return !t.apply(this, e)
                        }
                    }

                    function Kt(t, e) {
                        return t === e || t != t && e != e
                    }

                    function Jt(t) {
                        return null != t && ne(t.length) && !ee(t)
                    }

                    function te(t) {
                        return ie(t) && Jt(t)
                    }

                    function ee(t) {
                        return !!re(t) && ("[object Function]" == (t = Z(t)) || "[object GeneratorFunction]" == t || "[object AsyncFunction]" == t || "[object Proxy]" == t)
                    }

                    function ne(t) {
                        return "number" == typeof t && -1 < t && 0 == t % 1 && 9007199254740991 >= t
                    }

                    function re(t) {
                        var e = void 0 === t ? "undefined" : o(t);
                        return null != t && ("object" == e || "function" == e)
                    }

                    function ie(t) {
                        return null != t && "object" == (void 0 === t ? "undefined" : o(t))
                    }

                    function oe(t) {
                        return !(!ie(t) || "[object Object]" != Z(t)) && (null === (t = wn(t)) || "function" == typeof(t = ln.call(t, "constructor") && t.constructor) && t instanceof t && sn.call(t) == dn)
                    }

                    function ae(t) {
                        return "string" == typeof t || !dr(t) && ie(t) && "[object String]" == Z(t)
                    }

                    function ue(t) {
                        return "symbol" == (void 0 === t ? "undefined" : o(t)) || ie(t) && "[object Symbol]" == Z(t)
                    }

                    function ce(t) {
                        if (!t) return [];
                        if (Jt(t)) return ae(t) ? He.test(t) ? t.match(We) || [] : t.split("") : dt(t);
                        if (kn && t[kn]) {
                            t = t[kn]();
                            for (var e, n = []; !(e = t.next()).done;) n.push(e.value);
                            return n
                        }
                        return ("[object Map]" == (e = ur(t)) ? x : "[object Set]" == e ? k : ge)(t)
                    }

                    function fe(t) {
                        return t ? (t = le(t)) === Ee || t === -Ee ? 1.7976931348623157e308 * (0 > t ? -1 : 1) : t == t ? t : 0 : 0 === t ? t : 0
                    }

                    function se(t) {
                        var e = (t = fe(t)) % 1;
                        return t == t ? e ? t - e : t : 0
                    }

                    function le(t) {
                        if ("number" == typeof t) return t;
                        if (ue(t)) return Ae;
                        if (re(t) && (t = "function" == typeof t.valueOf ? t.valueOf() : t, t = re(t) ? t + "" : t), "string" != typeof t) return 0 === t ? t : +t;
                        t = t.replace(Ie, "");
                        var e = qe.test(t);
                        return e || Ve.test(t) ? $e(t.slice(2), e ? 2 : 8) : Be.test(t) ? Ae : +t
                    }

                    function he(t) {
                        return vt(t, _e(t))
                    }

                    function pe(t) {
                        return null == t ? "" : ot(t)
                    }

                    function de(t, e, n) {
                        return (t = null == t ? Pe : W(t, e)) === Pe ? n : t
                    }

                    function ve(t, e) {
                        var n;
                        if (n = null != t) {
                            for (var r, i = -1, o = (r = ct(e, n = t)).length, a = !1; ++i < o;) {
                                var u = Ut(r[i]);
                                if (!(a = null != n && null != n && u in Object(n))) break;
                                n = n[u]
                            }
                            a || ++i != o ? n = a : (o = null == n ? 0 : n.length, n = !!o && ne(o) && St(u, o) && (dr(n) || pr(n)))
                        }
                        return n
                    }

                    function ye(t) {
                        if (Jt(t)) t = R(t);
                        else if (It(t)) {
                            var e, n = [];
                            for (e in Object(t)) ln.call(t, e) && "constructor" != e && n.push(e);
                            t = n
                        } else t = Cn(t);
                        return t
                    }

                    function _e(t) {
                        if (Jt(t)) t = R(t, !0);
                        else if (re(t)) {
                            var e, n = It(t),
                                r = [];
                            for (e in t)("constructor" != e || !n && ln.call(t, e)) && r.push(e);
                            t = r
                        } else {
                            if (e = [], null != t)
                                for (n in Object(t)) e.push(n);
                            t = e
                        }
                        return t
                    }

                    function ge(t) {
                        return null == t ? [] : function(t, e) {
                            return d(e, function(e) {
                                return t[e]
                            })
                        }(t, ye(t))
                    }

                    function be(t) {
                        return function() {
                            return t
                        }
                    }

                    function me(t) {
                        return t
                    }

                    function we(t) {
                        return K("function" == typeof t ? t : B(t, 1))
                    }

                    function Oe(t, e, n) {
                        var r = ye(e),
                            i = Y(e, r);
                        null != n || re(e) && (i.length || !r.length) || (n = e, e = t, t = this, i = Y(e, ye(e)));
                        var o = !(re(n) && "chain" in n && !n.chain),
                            a = ee(t);
                        return s(i, function(n) {
                            var r = e[n];
                            t[n] = r, a && (t.prototype[n] = function() {
                                var e = this.__chain__;
                                if (o || e) {
                                    var n = t(this.__wrapped__);
                                    return (n.__actions__ = dt(this.__actions__)).push({
                                        func: r,
                                        args: arguments,
                                        thisArg: t
                                    }), n.__chain__ = e, n
                                }
                                return r.apply(t, v([this.value()], arguments))
                            })
                        }), t
                    }

                    function xe() {}

                    function Me(t) {
                        return Dt(t) ? function(t) {
                            return function(e) {
                                return null == e ? Pe : e[t]
                            }
                        }(Ut(t)) : function(t) {
                            return function(e) {
                                return W(e, t)
                            }
                        }(t)
                    }

                    function je() {
                        return []
                    }

                    function ke() {
                        return !1
                    }
                    var Pe, Ee = 1 / 0,
                        Ae = NaN,
                        Le = [
                            ["ary", 128],
                            ["bind", 1],
                            ["bindKey", 2],
                            ["curry", 8],
                            ["curryRight", 16],
                            ["flip", 512],
                            ["partial", 32],
                            ["partialRight", 64],
                            ["rearg", 256]
                        ],
                        Ce = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
                        Se = /^\w*$/,
                        Te = /^\./,
                        De = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
                        Ie = /^\s+|\s+$/g,
                        Re = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
                        Ne = /\{\n\/\* \[wrapped with (.+)\] \*/,
                        ze = /,? & /,
                        Fe = /\\(\\)?/g,
                        Ue = /\w*$/,
                        Be = /^[-+]0x[0-9a-f]+$/i,
                        qe = /^0b[01]+$/i,
                        Ge = /^\[object .+?Constructor\]$/,
                        Ve = /^0o[0-7]+$/i,
                        Ye = /^(?:0|[1-9]\d*)$/,
                        We = RegExp("\\ud83c[\\udffb-\\udfff](?=\\ud83c[\\udffb-\\udfff])|(?:[^\\ud800-\\udfff][\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]?|[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|(?:\\ud83c[\\udde6-\\uddff]){2}|[\\ud800-\\udbff][\\udc00-\\udfff]|[\\ud800-\\udfff])[\\ufe0e\\ufe0f]?(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?(?:\\u200d(?:[^\\ud800-\\udfff]|(?:\\ud83c[\\udde6-\\uddff]){2}|[\\ud800-\\udbff][\\udc00-\\udfff])[\\ufe0e\\ufe0f]?(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?)*", "g"),
                        He = RegExp("[\\u200d\\ud800-\\udfff\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff\\ufe0e\\ufe0f]"),
                        Ze = {};
                    Ze["[object Float32Array]"] = Ze["[object Float64Array]"] = Ze["[object Int8Array]"] = Ze["[object Int16Array]"] = Ze["[object Int32Array]"] = Ze["[object Uint8Array]"] = Ze["[object Uint8ClampedArray]"] = Ze["[object Uint16Array]"] = Ze["[object Uint32Array]"] = !0, Ze["[object Arguments]"] = Ze["[object Array]"] = Ze["[object ArrayBuffer]"] = Ze["[object Boolean]"] = Ze["[object DataView]"] = Ze["[object Date]"] = Ze["[object Error]"] = Ze["[object Function]"] = Ze["[object Map]"] = Ze["[object Number]"] = Ze["[object Object]"] = Ze["[object RegExp]"] = Ze["[object Set]"] = Ze["[object String]"] = Ze["[object WeakMap]"] = !1;
                    var Xe = {};
                    Xe["[object Arguments]"] = Xe["[object Array]"] = Xe["[object ArrayBuffer]"] = Xe["[object DataView]"] = Xe["[object Boolean]"] = Xe["[object Date]"] = Xe["[object Float32Array]"] = Xe["[object Float64Array]"] = Xe["[object Int8Array]"] = Xe["[object Int16Array]"] = Xe["[object Int32Array]"] = Xe["[object Map]"] = Xe["[object Number]"] = Xe["[object Object]"] = Xe["[object RegExp]"] = Xe["[object Set]"] = Xe["[object String]"] = Xe["[object Symbol]"] = Xe["[object Uint8Array]"] = Xe["[object Uint8ClampedArray]"] = Xe["[object Uint16Array]"] = Xe["[object Uint32Array]"] = !0, Xe["[object Error]"] = Xe["[object Function]"] = Xe["[object WeakMap]"] = !1;
                    var Qe, $e = parseInt,
                        Ke = "object" == (void 0 === t ? "undefined" : o(t)) && t && t.Object === Object && t,
                        Je = "object" == ("undefined" == typeof self ? "undefined" : o(self)) && self && self.Object === Object && self,
                        tn = Ke || Je || Function("return this")(),
                        en = "object" == o(e) && e && !e.nodeType && e,
                        nn = en && "object" == o(r) && r && !r.nodeType && r,
                        rn = nn && nn.exports === en,
                        on = rn && Ke.process;
                    t: {
                        try {
                            Qe = on && on.binding && on.binding("util");
                            break t
                        } catch (a) {}
                        Qe = void 0
                    }
                    var an = Qe && Qe.isTypedArray,
                        un = Array.prototype,
                        cn = Object.prototype,
                        fn = tn["__core-js_shared__"],
                        sn = Function.prototype.toString,
                        ln = cn.hasOwnProperty,
                        hn = function() {
                            var t = /[^.]+$/.exec(fn && fn.keys && fn.keys.IE_PROTO || "");
                            return t ? "Symbol(src)_1." + t : ""
                        }(),
                        pn = cn.toString,
                        dn = sn.call(Object),
                        vn = tn._,
                        yn = RegExp("^" + sn.call(ln).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                        _n = rn ? tn.Buffer : Pe,
                        gn = tn.Symbol,
                        bn = tn.Uint8Array,
                        mn = _n ? _n.f : Pe,
                        wn = M(Object.getPrototypeOf),
                        On = Object.create,
                        xn = cn.propertyIsEnumerable,
                        Mn = un.splice,
                        jn = gn ? gn.isConcatSpreadable : Pe,
                        kn = gn ? gn.iterator : Pe,
                        Pn = gn ? gn.toStringTag : Pe,
                        En = function() {
                            try {
                                var t = At(Object, "defineProperty");
                                return t({}, "", {}), t
                            } catch (t) {}
                        }(),
                        An = Object.getOwnPropertySymbols,
                        Ln = _n ? _n.isBuffer : Pe,
                        Cn = M(Object.keys),
                        Sn = Math.max,
                        Tn = Math.min,
                        Dn = Date.now,
                        In = un.reverse,
                        Rn = At(tn, "DataView"),
                        Nn = At(tn, "Map"),
                        zn = At(tn, "Promise"),
                        Fn = At(tn, "Set"),
                        Un = At(tn, "WeakMap"),
                        Bn = At(Object, "create"),
                        qn = Un && new Un,
                        Gn = {},
                        Vn = Bt(Rn),
                        Yn = Bt(Nn),
                        Wn = Bt(zn),
                        Hn = Bt(Fn),
                        Zn = Bt(Un),
                        Xn = gn ? gn.prototype : Pe,
                        Qn = Xn ? Xn.valueOf : Pe,
                        $n = Xn ? Xn.toString : Pe,
                        Kn = function() {
                            function t() {}
                            return function(e) {
                                return re(e) ? On ? On(e) : (t.prototype = e, e = new t, t.prototype = Pe, e) : {}
                            }
                        }();
                    (P.prototype = E.prototype).constructor = P, (A.prototype = Kn(E.prototype)).constructor = A, (L.prototype = Kn(E.prototype)).constructor = L, C.prototype.clear = function() {
                        this.__data__ = Bn ? Bn(null) : {}, this.size = 0
                    }, C.prototype.delete = function(t) {
                        return t = this.has(t) && delete this.__data__[t], this.size -= t ? 1 : 0, t
                    }, C.prototype.get = function(t) {
                        var e = this.__data__;
                        return Bn ? "__lodash_hash_undefined__" === (t = e[t]) ? Pe : t : ln.call(e, t) ? e[t] : Pe
                    }, C.prototype.has = function(t) {
                        var e = this.__data__;
                        return Bn ? e[t] !== Pe : ln.call(e, t)
                    }, C.prototype.set = function(t, e) {
                        var n = this.__data__;
                        return this.size += this.has(t) ? 0 : 1, n[t] = Bn && e === Pe ? "__lodash_hash_undefined__" : e, this
                    }, S.prototype.clear = function() {
                        this.__data__ = [], this.size = 0
                    }, S.prototype.delete = function(t) {
                        var e = this.__data__;
                        return !(0 > (t = F(e, t)) || (t == e.length - 1 ? e.pop() : Mn.call(e, t, 1), --this.size, 0))
                    }, S.prototype.get = function(t) {
                        var e = this.__data__;
                        return 0 > (t = F(e, t)) ? Pe : e[t][1]
                    }, S.prototype.has = function(t) {
                        return -1 < F(this.__data__, t)
                    }, S.prototype.set = function(t, e) {
                        var n = this.__data__,
                            r = F(n, t);
                        return 0 > r ? (++this.size, n.push([t, e])) : n[r][1] = e, this
                    }, T.prototype.clear = function() {
                        this.size = 0, this.__data__ = {
                            hash: new C,
                            map: new(Nn || S),
                            string: new C
                        }
                    }, T.prototype.delete = function(t) {
                        return t = Et(this, t).delete(t), this.size -= t ? 1 : 0, t
                    }, T.prototype.get = function(t) {
                        return Et(this, t).get(t)
                    }, T.prototype.has = function(t) {
                        return Et(this, t).has(t)
                    }, T.prototype.set = function(t, e) {
                        var n = Et(this, t),
                            r = n.size;
                        return n.set(t, e), this.size += n.size == r ? 0 : 1, this
                    }, D.prototype.add = D.prototype.push = function(t) {
                        return this.__data__.set(t, "__lodash_hash_undefined__"), this
                    }, D.prototype.has = function(t) {
                        return this.__data__.has(t)
                    }, I.prototype.clear = function() {
                        this.__data__ = new S, this.size = 0
                    }, I.prototype.delete = function(t) {
                        var e = this.__data__;
                        return t = e.delete(t), this.size = e.size, t
                    }, I.prototype.get = function(t) {
                        return this.__data__.get(t)
                    }, I.prototype.has = function(t) {
                        return this.__data__.has(t)
                    }, I.prototype.set = function(t, e) {
                        var n = this.__data__;
                        if (n instanceof S) {
                            var r = n.__data__;
                            if (!Nn || 199 > r.length) return r.push([t, e]), this.size = ++n.size, this;
                            n = this.__data__ = new T(r)
                        }
                        return n.set(t, e), this.size = n.size, this
                    };
                    var Jn = function(t, e) {
                            return function(e, n) {
                                if (null == e) return e;
                                if (!Jt(e)) return t(e, n);
                                for (var r = e.length, i = -1, o = Object(e); ++i < r && !1 !== n(o[i], i, o););
                                return e
                            }
                        }(V),
                        tr = function(t, e, n) {
                            for (var r = -1, i = Object(t), o = (n = n(t)).length; o--;) {
                                var a = n[++r];
                                if (!1 === e(i[a], a, i)) break
                            }
                            return t
                        },
                        er = qn ? function(t, e) {
                            return qn.set(t, e), t
                        } : me,
                        nr = En ? function(t, e) {
                            return En(t, "toString", {
                                configurable: !0,
                                enumerable: !1,
                                value: be(e),
                                writable: !0
                            })
                        } : me,
                        rr = Fn && 1 / k(new Fn([, -0]))[1] == Ee ? function(t) {
                            return new Fn(t)
                        } : xe,
                        ir = qn ? function(t) {
                            return qn.get(t)
                        } : xe,
                        or = An ? function(t) {
                            return null == t ? [] : (t = Object(t), l(An(t), function(e) {
                                return xn.call(t, e)
                            }))
                        } : je,
                        ar = An ? function(t) {
                            for (var e = []; t;) v(e, or(t)), t = wn(t);
                            return e
                        } : je,
                        ur = Z;
                    (Rn && "[object DataView]" != ur(new Rn(new ArrayBuffer(1))) || Nn && "[object Map]" != ur(new Nn) || zn && "[object Promise]" != ur(zn.resolve()) || Fn && "[object Set]" != ur(new Fn) || Un && "[object WeakMap]" != ur(new Un)) && (ur = function(t) {
                        var e = Z(t);
                        if (t = (t = "[object Object]" == e ? t.constructor : Pe) ? Bt(t) : "") switch (t) {
                            case Vn:
                                return "[object DataView]";
                            case Yn:
                                return "[object Map]";
                            case Wn:
                                return "[object Promise]";
                            case Hn:
                                return "[object Set]";
                            case Zn:
                                return "[object WeakMap]"
                        }
                        return e
                    });
                    var cr = Ft(er),
                        fr = Ft(nr),
                        sr = function(t) {
                            var e = (t = Qt(t, function(t) {
                                return 500 === e.size && e.clear(), t
                            })).cache;
                            return t
                        }(function(t) {
                            var e = [];
                            return Te.test(t) && e.push(""), t.replace(De, function(t, n, r, i) {
                                e.push(r ? i.replace(Fe, "$1") : n || t)
                            }), e
                        });
                    ! function(t) {
                        fr(Nt(t, Pe, Vt), t + "")
                    }(function(t) {
                        function e(e) {
                            for (var n = -1, r = t.length, i = Array(r), o = null == e; ++n < r;) i[n] = o ? Pe : de(e, t[n]);
                            return i
                        }
                        var n = t.length,
                            r = n ? t[0] : 0,
                            i = this.__wrapped__;
                        return !(1 < n || this.__actions__.length) && i instanceof L && St(r) ? ((i = i.slice(r, +r + (n ? 1 : 0))).__actions__.push({
                            func: Zt,
                            args: [e],
                            thisArg: Pe
                        }), new A(i, this.__chain__).thru(function(t) {
                            return n && !t.length && t.push(Pe), t
                        })) : this.thru(e)
                    });
                    var lr = nt(function(t, e) {
                            if (null == t) return [];
                            var n = e.length;
                            return 1 < n && Tt(t, e[0], e[1]) ? e = [] : 2 < n && Tt(e[0], e[1], e[2]) && (e = [e[0]]),
                                function(t, e) {
                                    var n = [],
                                        r = -1;
                                    return e = d(e.length ? e : [me], w(Pt())),
                                        function(t, e) {
                                            var n = t.length;
                                            for (t.sort(e); n--;) t[n] = t[n].c;
                                            return t
                                        }(tt(t, function(t) {
                                            return {
                                                a: d(e, function(e) {
                                                    return e(t)
                                                }),
                                                b: ++r,
                                                c: t
                                            }
                                        }), function(t, e) {
                                            var r;
                                            t: {
                                                r = -1;
                                                for (var i = t.a, o = e.a, a = i.length, u = n.length; ++r < a;) {
                                                    var c;
                                                    e: {
                                                        c = i[r];
                                                        var f = o[r];
                                                        if (c !== f) {
                                                            var s = c !== Pe,
                                                                l = null === c,
                                                                h = c == c,
                                                                p = ue(c),
                                                                d = f !== Pe,
                                                                v = null === f,
                                                                y = f == f,
                                                                _ = ue(f);
                                                            if (!v && !_ && !p && c > f || p && d && y && !v && !_ || l && d && y || !s && y || !h) {
                                                                c = 1;
                                                                break e
                                                            }
                                                            if (!l && !p && !_ && c < f || _ && s && h && !l && !p || v && s && h || !d && h || !y) {
                                                                c = -1;
                                                                break e
                                                            }
                                                        }
                                                        c = 0
                                                    }
                                                    if (c) {
                                                        r = r >= u ? c : c * ("desc" == n[r] ? -1 : 1);
                                                        break t
                                                    }
                                                }
                                                r = t.b - e.b
                                            }
                                            return r
                                        })
                                }(t, G(e, 1))
                        }),
                        hr = nt(function(t, e, n) {
                            var r = 1;
                            if (n.length) {
                                var i = j(n, kt(hr));
                                r = 32 | r
                            }
                            var o, a, u = e,
                                c = n,
                                s = i;
                            if (!(i = 2 & r) && "function" != typeof t) throw new TypeError("Expected a function");
                            if ((n = c ? c.length : 0) || (r &= -97, c = s = Pe), o = o === Pe ? o : Sn(se(o), 0), a = a === Pe ? a : se(a), n -= s ? s.length : 0, 64 & r) {
                                var l = c,
                                    h = s;
                                c = s = Pe
                            }
                            return e = i ? Pe : ir(t), o = [t, r, u, c, s, l, h, void 0, o, a], e && (l = o[1], a = e[1], t = l | a, h = 128 == a && 8 == l || 128 == a && 256 == l && o[7].length <= e[8] || 384 == a && e[7].length <= e[8] && 8 == l, 131 > t || h) && (1 & a && (o[2] = e[2], t |= 1 & l ? 0 : 4), (l = e[3]) && (h = o[3], o[3] = h ? ht(h, l, e[4]) : l, o[4] = h ? j(o[3], "__lodash_placeholder__") : e[4]), (l = e[5]) && (h = o[5], o[5] = h ? pt(h, l, e[6]) : l, o[6] = h ? j(o[5], "__lodash_placeholder__") : e[6]), (l = e[7]) && (o[7] = l), 128 & a && (o[8] = null == o[8] ? e[8] : Tn(o[8], e[8])), null == o[9] && (o[9] = e[9]), o[0] = e[0], o[1] = t), t = o[0], r = o[1], u = o[2], c = o[3], s = o[4], !(a = o[9] = o[9] === Pe ? i ? 0 : t.length : Sn(o[9] - n, 0)) && 24 & r && (r &= -25), zt((e ? er : cr)(r && 1 != r ? 8 == r || 16 == r ? function(t, e, n) {
                                function r() {
                                    for (var o = arguments.length, a = Array(o), u = o, c = kt(r); u--;) a[u] = arguments[u];
                                    return u = 3 > o && a[0] !== c && a[o - 1] !== c ? [] : j(a, c), (o -= u.length) < n ? mt(t, e, gt, r.placeholder, Pe, a, u, Pe, Pe, n - o) : f(this && this !== tn && this instanceof r ? i : t, this, a)
                                }
                                var i = _t(t);
                                return r
                            }(t, r, a) : 32 != r && 33 != r || s.length ? gt.apply(Pe, o) : function(t, e, n, r) {
                                function i() {
                                    for (var e = -1, u = arguments.length, c = -1, s = r.length, l = Array(s + u), h = this && this !== tn && this instanceof i ? a : t; ++c < s;) l[c] = r[c];
                                    for (; u--;) l[c++] = arguments[++e];
                                    return f(h, o ? n : this, l)
                                }
                                var o = 1 & e,
                                    a = _t(t);
                                return i
                            }(t, r, u, c) : function(t, e, n) {
                                function r() {
                                    return (this && this !== tn && this instanceof r ? o : t).apply(i ? n : this, arguments)
                                }
                                var i = 1 & e,
                                    o = _t(t);
                                return r
                            }(t, r, u), o), t, r)
                        });
                    Qt.Cache = T;
                    var pr = Q(function() {
                            return arguments
                        }()) ? Q : function(t) {
                            return ie(t) && ln.call(t, "callee") && !xn.call(t, "callee")
                        },
                        dr = Array.isArray,
                        vr = Ln || ke,
                        yr = an ? w(an) : function(t) {
                            return ie(t) && ne(t.length) && !!Ze[Z(t)]
                        },
                        _r = yt(function(t, e) {
                            vt(e, _e(e), t)
                        }),
                        gr = yt(function(t, e, n, r) {
                            vt(e, _e(e), t, r)
                        }),
                        br = nt(function(t) {
                            return t.push(Pe, Ot), f(gr, Pe, t)
                        }),
                        mr = yt(function(t, e, n) {
                            et(t, e, n)
                        }),
                        wr = bt(function(t, e) {
                            return t + e
                        }, 0),
                        Or = wt("ceil"),
                        xr = bt(function(t, e) {
                            return t / e
                        }, 1),
                        Mr = wt("floor"),
                        jr = bt(function(t, e) {
                            return t * e
                        }, 1),
                        kr = wt("round"),
                        Pr = bt(function(t, e) {
                            return t - e
                        }, 0);
                    P.after = function(t, e) {
                        if ("function" != typeof e) throw new TypeError("Expected a function");
                        return t = se(t),
                            function() {
                                if (1 > --t) return e.apply(this, arguments)
                            }
                    }, P.assignIn = _r, P.assignInWith = gr, P.bind = hr, P.chain = Ht, P.constant = be, P.debounce = Xt, P.defaults = br, P.flatten = Vt, P.iteratee = we, P.keys = ye, P.keysIn = _e, P.map = function(t, e) {
                        return (dr(t) ? d : tt)(t, Pt(e, 3))
                    }, P.memoize = Qt, P.merge = mr, P.mixin = Oe, P.negate = $t, P.property = Me, P.reverse = Wt, P.sortBy = lr, P.sortedUniq = function(t) {
                        return t && t.length ? rt(t) : []
                    }, P.sortedUniqBy = function(t, e) {
                        return t && t.length ? rt(t, Pt(e, 2)) : []
                    }, P.tap = function(t, e) {
                        return e(t), t
                    }, P.throttle = function(t, e, n) {
                        var r = !0,
                            i = !0;
                        if ("function" != typeof t) throw new TypeError("Expected a function");
                        return re(n) && (r = "leading" in n ? !!n.leading : r, i = "trailing" in n ? !!n.trailing : i), Xt(t, e, {
                            leading: r,
                            maxWait: e,
                            trailing: i
                        })
                    }, P.thru = Zt, P.toArray = ce, P.toPlainObject = he, P.uniq = function(t) {
                        return t && t.length ? at(t) : []
                    }, P.uniqBy = function(t, e) {
                        return t && t.length ? at(t, Pt(e, 2)) : []
                    }, P.uniqWith = function(t, e) {
                        return e = "function" == typeof e ? e : Pe, t && t.length ? at(t, Pe, e) : []
                    }, P.values = ge, P.extend = _r, P.extendWith = gr, Oe(P, P), P.add = wr, P.ceil = Or, P.clone = function(t) {
                        return B(t, 4)
                    }, P.cloneDeep = function(t) {
                        return B(t, 5)
                    }, P.cloneWith = function(t, e) {
                        return e = "function" == typeof e ? e : Pe, B(t, 4, e)
                    }, P.divide = xr, P.eq = Kt, P.floor = Mr, P.get = de, P.hasIn = ve, P.identity = me, P.isArguments = pr, P.isArray = dr, P.isArrayLike = Jt, P.isArrayLikeObject = te, P.isBuffer = vr, P.isFunction = ee, P.isLength = ne, P.isNil = function(t) {
                        return null == t
                    }, P.isNumber = function(t) {
                        return "number" == typeof t || ie(t) && "[object Number]" == Z(t)
                    }, P.isObject = re, P.isObjectLike = ie, P.isPlainObject = oe, P.isString = ae, P.isSymbol = ue, P.isTypedArray = yr, P.last = Yt, P.max = function(t) {
                        return t && t.length ? q(t, me, X) : Pe
                    }, P.maxBy = function(t, e) {
                        return t && t.length ? q(t, Pt(e, 2), X) : Pe
                    }, P.mean = function(t) {
                        return b(t, me)
                    }, P.meanBy = function(t, e) {
                        return b(t, Pt(e, 2))
                    }, P.min = function(t) {
                        return t && t.length ? q(t, me, J) : Pe
                    }, P.minBy = function(t, e) {
                        return t && t.length ? q(t, Pt(e, 2), J) : Pe
                    }, P.stubArray = je, P.stubFalse = ke, P.multiply = jr, P.noConflict = function() {
                        return tn._ === this && (tn._ = vn), this
                    }, P.noop = xe, P.now = a, P.round = kr, P.subtract = Pr, P.sum = function(t) {
                        return t && t.length ? m(t, me) : 0
                    }, P.sumBy = function(t, e) {
                        return t && t.length ? m(t, Pt(e, 2)) : 0
                    }, P.toFinite = fe, P.toInteger = se, P.toNumber = le, P.toString = pe, Oe(P, function() {
                        var t = {};
                        return V(P, function(e, n) {
                            ln.call(P.prototype, n) || (t[n] = e)
                        }), t
                    }(), {
                        chain: !1
                    }), P.VERSION = "4.17.4", hr.placeholder = P, s(["drop", "take"], function(t, e) {
                        L.prototype[t] = function(n) {
                            n = n === Pe ? 1 : Sn(se(n), 0);
                            var r = this.__filtered__ && !e ? new L(this) : this.clone();
                            return r.__filtered__ ? r.__takeCount__ = Tn(n, r.__takeCount__) : r.__views__.push({
                                size: Tn(n, 4294967295),
                                type: t + (0 > r.__dir__ ? "Right" : "")
                            }), r
                        }, L.prototype[t + "Right"] = function(e) {
                            return this.reverse()[t](e).reverse()
                        }
                    }), s(["filter", "map", "takeWhile"], function(t, e) {
                        var n = e + 1,
                            r = 1 == n || 3 == n;
                        L.prototype[t] = function(t) {
                            var e = this.clone();
                            return e.__iteratees__.push({
                                iteratee: Pt(t, 3),
                                type: n
                            }), e.__filtered__ = e.__filtered__ || r, e
                        }
                    }), s(["head", "last"], function(t, e) {
                        var n = "take" + (e ? "Right" : "");
                        L.prototype[t] = function() {
                            return this[n](1).value()[0]
                        }
                    }), s(["initial", "tail"], function(t, e) {
                        var n = "drop" + (e ? "" : "Right");
                        L.prototype[t] = function() {
                            return this.__filtered__ ? new L(this) : this[n](1)
                        }
                    }), L.prototype.compact = function() {
                        return this.filter(me)
                    }, L.prototype.find = function(t) {
                        return this.filter(t).head()
                    }, L.prototype.findLast = function(t) {
                        return this.reverse().find(t)
                    }, L.prototype.invokeMap = nt(function(t, e) {
                        return "function" == typeof t ? new L(this) : this.map(function(n) {
                            var r = n,
                                i = n = ct(n = t, r);
                            if (!(2 > i.length)) {
                                var o = 0,
                                    a = -1,
                                    u = -1,
                                    c = i.length;
                                for (0 > o && (o = -o > c ? 0 : c + o), 0 > (a = a > c ? c : a) && (a += c), c = o > a ? 0 : a - o >>> 0, o >>>= 0, a = Array(c); ++u < c;) a[u] = i[u + o];
                                r = W(r, a)
                            }
                            return null == (n = null == r ? r : r[Ut(Yt(n))]) ? Pe : f(n, r, e)
                        })
                    }), L.prototype.reject = function(t) {
                        return this.filter($t(Pt(t)))
                    }, L.prototype.slice = function(t, e) {
                        t = se(t);
                        var n = this;
                        return n.__filtered__ && (0 < t || 0 > e) ? new L(n) : (0 > t ? n = n.takeRight(-t) : t && (n = n.drop(t)), e !== Pe && (e = se(e), n = 0 > e ? n.dropRight(-e) : n.take(e - t)), n)
                    }, L.prototype.takeRightWhile = function(t) {
                        return this.reverse().takeWhile(t).reverse()
                    }, L.prototype.toArray = function() {
                        return this.take(4294967295)
                    }, V(L.prototype, function(t, e) {
                        var n = /^(?:filter|find|map|reject)|While$/.test(e),
                            r = /^(?:head|last)$/.test(e),
                            i = P[r ? "take" + ("last" == e ? "Right" : "") : e],
                            o = r || /^find/.test(e);
                        i && (P.prototype[e] = function() {
                            function e(t) {
                                return t = i.apply(P, v([t], u)), r && l ? t[0] : t
                            }
                            var a = this.__wrapped__,
                                u = r ? [1] : arguments,
                                c = a instanceof L,
                                f = u[0],
                                s = c || dr(a);
                            s && n && "function" == typeof f && 1 != f.length && (c = s = !1);
                            var l = this.__chain__,
                                h = !!this.__actions__.length;
                            f = o && !l, c = c && !h;
                            return !o && s ? (a = c ? a : new L(this), (a = t.apply(a, u)).__actions__.push({
                                func: Zt,
                                args: [e],
                                thisArg: Pe
                            }), new A(a, l)) : f && c ? t.apply(this, u) : (a = this.thru(e), f ? r ? a.value()[0] : a.value() : a)
                        })
                    }), s("pop push shift sort splice unshift".split(" "), function(t) {
                        var e = un[t],
                            n = /^(?:push|sort|unshift)$/.test(t) ? "tap" : "thru",
                            r = /^(?:pop|shift)$/.test(t);
                        P.prototype[t] = function() {
                            var t = arguments;
                            if (r && !this.__chain__) {
                                var i = this.value();
                                return e.apply(dr(i) ? i : [], t)
                            }
                            return this[n](function(n) {
                                return e.apply(dr(n) ? n : [], t)
                            })
                        }
                    }), V(L.prototype, function(t, e) {
                        var n = P[e];
                        if (n) {
                            var r = n.name + "";
                            (Gn[r] || (Gn[r] = [])).push({
                                name: e,
                                func: n
                            })
                        }
                    }), Gn[gt(Pe, 2).name] = [{
                        name: "wrapper",
                        func: Pe
                    }], L.prototype.clone = function() {
                        var t = new L(this.__wrapped__);
                        return t.__actions__ = dt(this.__actions__), t.__dir__ = this.__dir__, t.__filtered__ = this.__filtered__, t.__iteratees__ = dt(this.__iteratees__), t.__takeCount__ = this.__takeCount__, t.__views__ = dt(this.__views__), t
                    }, L.prototype.reverse = function() {
                        if (this.__filtered__) {
                            var t = new L(this);
                            t.__dir__ = -1, t.__filtered__ = !0
                        } else t = this.clone(), t.__dir__ *= -1;
                        return t
                    }, L.prototype.value = function() {
                        var t, e = this.__wrapped__.value(),
                            n = this.__dir__,
                            r = dr(e),
                            i = 0 > n,
                            o = r ? e.length : 0;
                        t = o;
                        for (var a = this.__views__, u = 0, c = -1, f = a.length; ++c < f;) {
                            var s = a[c],
                                l = s.size;
                            switch (s.type) {
                                case "drop":
                                    u += l;
                                    break;
                                case "dropRight":
                                    t -= l;
                                    break;
                                case "take":
                                    t = Tn(t, u + l);
                                    break;
                                case "takeRight":
                                    u = Sn(u, t - l)
                            }
                        }
                        if (t = {
                            start: u,
                            end: t
                        }, a = t.start, u = t.end, t = u - a, a = i ? u : a - 1, u = this.__iteratees__, c = u.length, f = 0, s = Tn(t, this.__takeCount__), !r || !i && o == t && s == t) return ut(e, this.__actions__);
                        r = [];
                        t: for (; t-- && f < s;) {
                            for (i = -1, o = e[a += n]; ++i < c;) {
                                l = (h = u[i]).type;
                                var h = (0, h.iteratee)(o);
                                if (2 == l) o = h;
                                else if (!h) {
                                    if (1 == l) continue t;
                                    break t
                                }
                            }
                            r[f++] = o
                        }
                        return r
                    }, P.prototype.chain = function() {
                        return Ht(this)
                    }, P.prototype.commit = function() {
                        return new A(this.value(), this.__chain__)
                    }, P.prototype.next = function() {
                        this.__values__ === Pe && (this.__values__ = ce(this.value()));
                        var t = this.__index__ >= this.__values__.length;
                        return {
                            done: t,
                            value: t ? Pe : this.__values__[this.__index__++]
                        }
                    }, P.prototype.plant = function(t) {
                        for (var e, n = this; n instanceof E;) {
                            var r = Gt(n);
                            r.__index__ = 0, r.__values__ = Pe, e ? i.__wrapped__ = r : e = r;
                            var i = r;
                            n = n.__wrapped__
                        }
                        return i.__wrapped__ = t, e
                    }, P.prototype.reverse = function() {
                        var t = this.__wrapped__;
                        return t instanceof L ? (this.__actions__.length && (t = new L(this)), (t = t.reverse()).__actions__.push({
                            func: Zt,
                            args: [Wt],
                            thisArg: Pe
                        }), new A(t, this.__chain__)) : this.thru(Wt)
                    }, P.prototype.toJSON = P.prototype.valueOf = P.prototype.value = function() {
                        return ut(this.__wrapped__, this.__actions__)
                    }, P.prototype.first = P.prototype.head, kn && (P.prototype[kn] = function() {
                        return this
                    }), "object" == o(n(102)) && n(102) ? (tn._ = P, void 0 === (i = function() {
                        return P
                    }.call(e, n, e, r)) || (r.exports = i)) : nn ? ((nn.exports = P)._ = P, en._ = P) : tn._ = P
                }).call(void 0)
            }).call(e, n(242), n(243)(t))
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Clip = e.Animation = e.DataSet = e.Util = void 0;
            var i = n(104);
            Object.keys(i).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return i[t]
                    }
                })
            });
            var o = n(41);
            Object.keys(o).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return o[t]
                    }
                })
            });
            var a = n(6);
            Object.keys(a).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return a[t]
                    }
                })
            });
            var u = n(1);
            Object.keys(u).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return u[t]
                    }
                })
            });
            var c = n(65);
            Object.defineProperty(e, "Animation", {
                enumerable: !0,
                get: function() {
                    return c.Animation
                }
            }), Object.defineProperty(e, "Clip", {
                enumerable: !0,
                get: function() {
                    return c.Clip
                }
            });
            var f = n(142);
            Object.keys(f).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return f[t]
                    }
                })
            });
            var s = n(26),
                l = r(n(107)),
                h = r(n(112)),
                p = r(n(113)),
                d = r(n(111)),
                v = r(n(108)),
                y = r(n(109)),
                _ = r(n(110)),
                g = r(n(0)),
                b = r(n(58));
            s.Marker.registerGraph(l.default), s.Marker.registerGraph(h.default), s.Marker.registerGraph(p.default), s.Marker.registerGraph(d.default), s.Marker.registerGraph(v.default), s.Marker.registerGraph(y.default), s.Marker.registerGraph(_.default), e.Util = g.default, e.DataSet = b.default
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                var e = a[t];
                return void 0 == e && (e = a[t] = Math.sin(t)), e
            }

            function i(t) {
                var e = u[t];
                return void 0 == e && (e = u[t] = Math.cos(t)), e
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = function() {
                return function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            o = void 0;
                        try {
                            for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                        } catch (t) {
                            i = !0, o = t
                        } finally {
                            try {
                                !r && u.return && u.return()
                            } finally {
                                if (i) throw o
                            }
                        }
                        return n
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                }
            }();
            e.sin = r, e.cos = i, e.getRegularCorners = function(t, e, n) {
                var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0,
                    u = [];
                if (n < 3) return [];
                for (var f = o(t, 2), s = f[0], l = f[1], h = -1, p = n; ++h < p;) {
                    var d = c * h / n,
                        v = s + e * i(d + a),
                        y = l + e * r(d + a);
                    u.push([v, y])
                }
                return u
            };
            var a = {},
                u = {},
                c = 2 * Math.PI
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i() {
                return 1e6 * Math.random()
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var o = r(n(8)),
                a = r(n(0)).default.callFn,
                u = "//webapi.amap.com/maps",
                c = "//webapi.amap.com/ui/1.0/main-async.js",
                f = ["key", "v", "plugin", "callback"],
                s = ["ea010f7aefc7209dd1f54688cdfc23e4", "1.4.10", "AMap.CustomLayer,Map3D,", "__amap_callback__"],
                l = {
                    _AMap: null,
                    _AMapUI: null,
                    _event: new o.default,
                    init: function(t) {
                        var e = this,
                            n = t || {},
                            r = n.success,
                            o = n.uiSuccess,
                            u = n.key,
                            c = n.version,
                            f = n.plugin,
                            l = n.ui,
                            h = this._event,
                            p = void 0;
                        this._checkAMap() ? (p = this._AMap, a(r, this, p)) : (u && (s[0] = u), c && (s[1] = c), f && (s[2] += f), s[3] += Math.floor(i()), window[s[3]] = function() {
                            if (!(p = e._AMap = window.AMap)) throw new Error("AMap lib load error!");
                            h.emit("apiReady", {
                                amap: p
                            })
                        }, h.on("apiReady", function(t) {
                            var n = t.amap;
                            try {
                                a(r, e, n)
                            } catch (t) {
                                console && console.error(t)
                            }
                        }), this._loadAPI()), l && (this._checkUI() ? this._whenAMapReady(function(t) {
                            a(o, e, t, e._AMapUI)
                        }) : this._loadUI(function() {
                            e._whenAMapReady(function(t) {
                                try {
                                    window.initAMapUI();
                                    var n = e._AMapUI = window.AMapUI;
                                    a(o, e, t, n), h.emit("uiReady", {
                                        amapUI: n
                                    })
                                } catch (t) {
                                    console && console.error(t)
                                }
                            })
                        }))
                    },
                    _whenAMapReady: function(t) {
                        var e = this;
                        this._checkAMap() ? t.call(this, this._AMap) : this._event.on("apiReady", function(n) {
                            t.call(e, n.amap)
                        })
                    },
                    _whenUIReady: function(t) {
                        var e = this;
                        this._checkUI() ? t.call(this, this._AMapUI) : this._event.on("uiReady", function(n) {
                            t.call(e, n.amapUI)
                        })
                    },
                    _checkScript: function(t) {
                        for (var e = new RegExp("^(http:|https:)" + t, "ig"), n = document.getElementsByTagName("script"), r = -1, i = n.length; ++r < i;) {
                            if (n[r].src.match(e)) return !0
                        }
                        return !1
                    },
                    _checkAMap: function() {
                        var t = window.AMap;
                        return !(!this._checkScript(u) || !t) && (this._AMap = t, !0)
                    },
                    _checkUI: function() {
                        var t = window.AMapUI;
                        return !(!this._checkScript(c) || !t) && (this._AMapUI = t, !0)
                    },
                    _loadAPI: function(t) {
                        var e = {};
                        f.forEach(function(t, n) {
                            var r = s[n];
                            r && (e[t] = r)
                        }), this._appendScript(u, {
                            args: e,
                            success: t
                        })
                    },
                    _loadUI: function(t) {
                        this._appendScript(c, {
                            success: t
                        })
                    },
                    _appendScript: function(t, e) {
                        var n = this,
                            r = e.args,
                            o = e.success,
                            u = document.getElementsByTagName("head")[0],
                            c = document.createElement("script");
                        c.addEventListener && c.addEventListener("load", function(t) {
                            a(o, n, t)
                        });
                        var f = [];
                        for (var s in r) {
                            var l = r[s];
                            l && f.push(s + "=" + l)
                        }
                        f.push("_r=" + i());
                        var h = new RegExp("^(http:|https:)", "ig");
                        location && location.protocol.match(h) || (t = "http:" + t), c.src = t + "?" + f.join("&"), u.insertBefore(c, null)
                    },
                    _getAPIKey: function() {
                        return s[0]
                    }
                };
            e.default = l
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = {
                createCanvas: function(t) {
                    var e = t.width,
                        n = t.height,
                        r = document.createElement("canvas");
                    r.setAttribute("width", e), r.setAttribute("height", n);
                    return r.getContext("2d")
                },
                set: function(t) {
                    var e = t.gridNum,
                        n = t.effectRadius,
                        r = t.step,
                        i = t.blendMode,
                        o = void 0 === i ? "lighten" : i,
                        a = t.dataOpts,
                        u = void 0 === a ? {} : a,
                        c = t.extendGrid,
                        f = e.m,
                        s = e.n,
                        l = (u.min, u.max),
                        h = f,
                        p = s;
                    n /= r, r = 1;
                    var d = this.createCanvas({
                        width: h,
                        height: p
                    });
                    d.globalCompositeOperation = o || "lighten";
                    for (var v = 0; v < c.length; v++)
                        for (var y = c[v], _ = 0; _ < y.length; _++) {
                            var g = y[_];
                            if (void 0 !== g) {
                                var b = r * _ + r / 2,
                                    m = r * v + r / 2,
                                    w = d.createRadialGradient(b, m, 0, b, m, n),
                                    O = 255 / l * g >> 0;
                                w.addColorStop(0, "rgb(" + O + ", 0, 0)"), w.addColorStop(1, "rgb(0, 0, 0)"), d.beginPath(), d.fillStyle = w, d.arc(b, m, n, 0, 2 * Math.PI), d.fill()
                            }
                        }
                    window.imgData = d.getImageData(0, 0, h, p).data;
                    for (var x = h / f, M = p / s, j = 0; j < s; j++)
                        for (var k = c[j], P = 0; P < f; P++) {
                            var E = k[P],
                                A = Math.floor(P * x + .5 * x),
                                L = 4 * (Math.floor(j * M) * h + A) + 0,
                                C = window.imgData[L];
                            void 0 === E && (c[j][P] = this.getFixed2Data(C / 255 * l))
                        }
                    return c
                },
                getFixed2Data: function(t, e) {
                    return parseFloat(t.toFixed(e || 2))
                }
            };
            e.default = r
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t) {
                return t && c.default.isPlainObject(t) && t.value
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.binning = function(t, e) {
                var n = e.radius,
                    r = void 0;
                switch (e.shape.toLowerCase()) {
                    case "hex":
                    case "hexagon":
                        r = (0, o.default)().radius(n);
                        break;
                    case "rect":
                    case "rectangle":
                    case "grid":
                    default:
                        r = (0, a.default)().radius(n)
                }
                return r(t)
            }, e.sortGradientColor = function(t) {
                var e = [];
                if (c.default.isArray(t))
                    for (var n = t.length, r = -1; ++r < n;) e.push({
                        offset: (r + 1) / n,
                        color: t[r]
                    });
                else c.default.forMap(t, function(t, n) {
                    e.push({
                        offset: +n,
                        color: t
                    })
                }), e = c.default.sortBy(e, function(t) {
                    return t.offset
                });
                var i = [],
                    o = [];
                return e.forEach(function(t) {
                    i.push(t.color), o.push(t.offset)
                }), {
                    colors: i,
                    colorOffsets: o
                }
            }, e.normalize2DataMap = function(t, e) {
                var n = e.domain,
                    r = e.range,
                    i = e.type,
                    o = e.valueField,
                    a = u.default.get(i)();
                a.range(r).domain(n);
                for (var c = {}, f = -1, s = t.length; ++f < s;) {
                    var l = t[f];
                    void 0 === c[l = o ? l[o] : l] && (c[l] = a(l))
                }
                return c
            }, e.getByKey = function(t, e, n, r) {
                return e ? c.default.callFn(e, n || this, t, r) || t[e] || e : t
            }, e.isAttrOption = i, e.toAttrOption = function(t, e) {
                return i(t) || (t = {
                    value: c.default.clone(t)
                }), c.default.defaults({}, t, e || {})
            }, e.formatVisualOptions = function(t, e) {
                var n = c.default.cloneDeep(t),
                    r = n.style,
                    i = void 0 === r ? {} : r,
                    o = n.style.color,
                    a = n.gradient,
                    u = n.colorScale;
                return a && !o ? i.color = {
                    value: a,
                    scale: u
                } : o && c.default.isNil(o.value) && (i.color = {
                    value: o,
                    scale: u
                }), c.default.defaults(i, e.style), c.default.defaults(n, e)
            }, e.formatAttrKey = function(t) {
                var e = {};
                for (var n in t)
                    if (t.hasOwnProperty(n)) {
                        var r = t[n];
                        if (e[n] = c.default.clone(r), c.default.isPlainObject(r)) {
                            var i = {};
                            for (var o in r)
                                if (r.hasOwnProperty(o)) {
                                    var a = r[o];
                                    "input" === o && (o = "domain"), "value" === o && (o = "range"), i[o] = a
                                }
                            e[n] = i
                        }
                    }
                return e
            };
            var o = r(n(53)),
                a = r(n(51)),
                u = r(n(57)),
                c = r(n(0))
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return !t || t instanceof a ? t : new a(t, e)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.Bounds = void 0;
            var i = function() {
                function t(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }
                return function(e, n, r) {
                    return n && t(e.prototype, n), r && t(e, r), e
                }
            }();
            e.toBounds = r;
            var o = n(56),
                a = e.Bounds = function() {
                    function t() {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, t);
                        for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                        for (var i = 0, o = n.length; i < o; i++) this.expend(n[i])
                    }
                    return i(t, [{
                        key: "expend",
                        value: function(t) {
                            return t = (0, o.toPoint)(t), this.min || this.max ? (this.min._x = Math.min(t._x, this.min._x), this.max._x = Math.max(t._x, this.max._x), this.min._y = Math.min(t._y, this.min._y), this.max._y = Math.max(t._y, this.max._y)) : (this.min = t.clone(), this.max = t.clone()), this
                        }
                    }, {
                        key: "getCenter",
                        value: function(t) {
                            return new o.Point((this.min._x + this.max._x) / 2, (this.min._y + this.max._y) / 2, t)
                        }
                    }, {
                        key: "getSize",
                        value: function() {
                            return this.max.subtract(this.min)
                        }
                    }, {
                        key: "contains",
                        value: function(e) {
                            var n, i;
                            return (e = "number" == typeof e[0] || e instanceof o.Point ? (0, o.toPoint)(e) : r(e)) instanceof t ? (n = e.min, i = e.max) : n = i = e, n._x >= this.min._x && i._x <= this.max._x && n._y >= this.min._y && i._y <= this.max._y
                        }
                    }, {
                        key: "intersects",
                        value: function(t) {
                            t = r(t);
                            var e = this.min,
                                n = this.max,
                                i = t.min,
                                o = t.max,
                                a = o._x >= e._x && i._x <= n._x,
                                u = o._y >= e._y && i._y <= n._y;
                            return a && u
                        }
                    }, {
                        key: "overlaps",
                        value: function(t) {
                            t = r(t);
                            var e = this.min,
                                n = this.max,
                                i = t.min,
                                o = t.max,
                                a = o._x > e._x && i._x < n._x,
                                u = o._y > e._y && i._y < n._y;
                            return a && u
                        }
                    }, {
                        key: "isValid",
                        value: function() {
                            return !(!this.min || !this.max)
                        }
                    }, {
                        key: "getBottomLeft",
                        value: function() {
                            return new o.Point(this.min._x, this.max._y)
                        }
                    }, {
                        key: "getTopRight",
                        value: function() {
                            return new o.Point(this.max._x, this.min._y)
                        }
                    }, {
                        key: "getTopLeft",
                        value: function() {
                            return this.min
                        }
                    }, {
                        key: "getBottomRight",
                        value: function() {
                            return this.max
                        }
                    }, {
                        key: "valueOf",
                        value: function() {
                            return [this.getTopLeft().valueOf(), this.getBottomRight().valueOf()]
                        }
                    }]), t
                }()
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }

            function i(t, e) {
                for (var n = [], r = -1, u = t.length; ++r < u;) {
                    var c = t[r];
                    if (void 0 !== c && (!Array.isArray(c) || c.length))
                        if (o.default.is2DimArr(c)) n.push(i(c, e));
                        else {
                            var f = (0, a.toLngLat)(c);
                            e && e.expend(f), n.push(f)
                        }
                }
                return n
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.toLngLats = i, e.getControlPoint = function(t, e, n) {
                return [(t[0] + e[0]) / 2 - (t[1] - e[1]) * n, (t[1] + e[1]) / 2 - (e[0] - t[0]) * n]
            }, e.distanceSquare2Bezier = function(t, e) {
                var n = e.project({
                    x: t[0],
                    y: t[1]
                });
                return u.default.distSquare(t, [n.x, n.y])
            };
            var o = r(n(0)),
                a = n(28),
                u = (n(55), r(n(44)))
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            e.FunLog = {
                key: "",
                version: "",
                records: {},
                getKey: function(t, e) {
                    t = t || "";
                    return void 0 !== e && t ? t + "@" + e : t
                },
                record: function(t, e, n) {
                    this.records[t] || (this.records[t] = {});
                    var r = this.getKey(e, n);
                    void 0 == this.records[t][r] && (this.records[t][r] = 0)
                },
                send: function() {
                    var t = [];
                    for (var e in this.records)
                        if (this.records.hasOwnProperty(e)) {
                            var n = this.records[e],
                                r = [];
                            for (var i in n) n.hasOwnProperty(i) && 0 == n[i] && (r.push(i), n[i] = 1);
                            r.length && t.push(e + "~" + r.join(","))
                        }
                    if (t.length) {
                        var o = AMap.Browser.mobile,
                            a = AMap.Browser.plat,
                            u = "//webapi.amap.com/count?" + ["type=nfl", "k=" + this.key, "m=" + (o ? 1 : 0), "pf=" + a || "", "branch=LOCA", "v=" + this.version || "", "log=" + t.join("!")].join("&");
                        new AMap.Http.JSONP(u)
                    }
                }
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return -1 !== a.ScaleMap.continuous.indexOf(e) ? u(t) : f(t)
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.normalizeWithScale = function(t, e) {
                var n = [];
                for (var i in e)
                    if (e.hasOwnProperty(i)) {
                        var a = e[i];
                        if (l(a)) {
                            var u = a[p],
                                f = a[d],
                                s = a[v],
                                y = a[_],
                                b = void 0 === y ? "linear" : y,
                                x = a[m],
                                M = a[g],
                                j = a[w],
                                k = a[O];
                            if (u && f) {
                                b = b.toLowerCase().replace("scale", "");
                                var P = t.getData(u),
                                    E = o.Scale.get(b)();
                                if (f = c(f) ? f.call(this, P) : f, s = c(s) ? s.call(this, P) : s || r(P, b), h(f) && f.length > 1 && h(s) && s.length > 0) {
                                    E.domain && E.domain(s), E.range && E.range(f), x && E.clamp && E.clamp(x), M && E.unknown && E.unknown(M), j && E.exponent && E.exponent(j), k && E.base && E.base(k);
                                    for (var A = -1, L = P.length; ++A < L;) {
                                        var C = E(P[A]);
                                        n[A] || (n[A] = {}), n[A][i] = C
                                    }
                                }
                            } else n.style || (n.style = {}), n.style[i] = a
                        } else if (c(a))
                            for (var S = t.getData(), T = -1, D = S.length; ++T < D;) {
                                var I = a.call(this, {
                                    value: S[T],
                                    index: T
                                });
                                n[T] || (n[T] = {}), n[T][i] = I
                            } else n.style || (n.style = {}), n.style[i] = a
                    }
                return n
            }, e.transformCoordinate = function(t, e) {
                var n = t.getOptions()[y],
                    r = e[y],
                    i = void 0 === r ? n : r,
                    o = e[b],
                    a = void 0 === o ? x : o;
                return t.getData(function(t, e) {
                    var n = c(i) ? i({
                        value: t,
                        index: e
                    }) : t[i];
                    return a === x ? n.split ? n.split(",") : n : s(n, function(t) {
                        return t.split ? t.split(",") : t
                    })
                })
            }, e.checkLngLat = function(t) {
                return h(t)
            }, e.formatHeatMapOptions = function(t, e) {
                var n = i.default.cloneDeep(t),
                    r = n.style,
                    o = n.gradient,
                    a = n.colorScale;
                return o && !(r || {}).color && (r.color = {
                    value: o,
                    scale: a
                }), i.default.defaults(r, e.style), i.default.defaults(n, e)
            };
            var i = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(0)),
                o = n(1),
                a = n(4),
                u = i.default.extent,
                c = i.default.isFunction,
                f = i.default.uniq,
                s = i.default.map,
                l = i.default.isPlainObject,
                h = i.default.nativeArrCheck,
                p = "key",
                d = "value",
                v = "input",
                y = "lnglat",
                _ = "scale",
                g = "default",
                b = "type",
                m = "clamp",
                w = "exponent",
                O = "base",
                x = "point"
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.visualLayer = e.VisualLayer = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(8)),
                a = r(n(0)),
                u = r(n(58)),
                c = n(6),
                f = n(139),
                s = n(1),
                l = "heatmap",
                h = {
                    Cfg: {
                        eventSupport: !1,
                        zIndex: 200
                    },
                    Opt: {
                        animation: !1,
                        light: {
                            ambient: {
                                color: "#ffffff",
                                intensity: .5
                            },
                            directional: {
                                color: "#ffffff",
                                intensity: .7,
                                direction: [1, -1, 2]
                            }
                        }
                    },
                    Dis_Opt: {
                        style: {
                            opacity: .85,
                            height: [0, 5e4],
                            gap: 1
                        },
                        selectStyle: {
                            opacity: .95
                        },
                        gradient: {
                            0: "#eff3ff",
                            .2: "#c6dbef",
                            .4: "#9ecae1",
                            .6: "#6baed6",
                            .8: "#3182bd",
                            1: "#08519c"
                        }
                    },
                    Contour_Opts: {
                        interpolation: {
                            enable: !0,
                            step: 500,
                            effectRadius: 1e3
                        },
                        threshold: 1,
                        smoothNumber: 2,
                        style: {
                            color: ["#3656CD", "#655FE7", "#20C2E1", "#23D561", "#9CD523", "#F1E229", "#FFBF3A", "#FB8C00", "#FF5252", "#BC54E2", "#FF6FCE"],
                            strokeWeight: 1,
                            strokeColor: "transparent",
                            height: 5e4
                        }
                    }
                },
                p = ["source", "unit", "heightUnit", "invisible"],
                d = function(t) {
                    function e(t) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var n = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
                        n._config = t = a.default.defaults(t || {}, h.Cfg);
                        var r = t,
                            i = r.type,
                            o = r.shape,
                            u = r.container,
                            c = r.fitView;
                        if (!i || !o) throw new Error("VisualLayer 构造函数必须指定 type 和 shape 属性。");
                        return u && (t.visualMap = u, t.container = u._map, n.addTo(u)), n.whenOverlaysReady(function() {
                            c && n.setFitView(), s.FunLog.record("VisualLayer_init", "type", i), s.FunLog.record("VisualLayer_init", "shape", o)
                        }), n._type = i, n._shape = o, n._overlays = [], n
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "setData",
                        value: function(t, e) {
                            return this._dataSet = t instanceof u.default ? t : new u.default(t, e), this
                        }
                    }, {
                        key: "setOptions",
                        value: function(t, e) {
                            var n = this._config.type;
                            if (n === l) t.style = a.default.defaults(t.style, h.Dis_Opt.style), t = a.default.defaults(t, h.Dis_Opt), this._options = a.default.clone(t);
                            else if ("contour" === n) t.style = a.default.defaults(t.style || {}, h.Contour_Opts.style), t.interpolation = a.default.defaults(t.interpolation || {}, h.Contour_Opts.interpolation), t = a.default.defaults(t, h.Contour_Opts), this._options = a.default.clone(t);
                            else {
                                var r = this._options,
                                    i = void 0;
                                i = !r || e ? a.default.clone(a.default.defaults(t, h.Opt)) : a.default.merge(r, t), this._options = i
                            }
                            return this
                        }
                    }, {
                        key: "setStyle",
                        value: function(t, e) {
                            if (this._type !== l)
                                if (a.default.isArray(t)) this._styleList = t;
                                else {
                                    var n = this._styleList;
                                    a.default.isArray(n) && void 0 !== n[e] ? this._styleList[e] = t : this._options.style = t
                                }
                        }
                    }, {
                        key: "_updateAttr",
                        value: function() {
                            var t = this._dataSet;
                            t && (this._renderData = this.transform(t, this._options, {
                                styleList: this._styleList
                            }))
                        }
                    }, {
                        key: "transform",
                        value: function(t) {
                            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                                r = n.styleList,
                                i = n.dataOptions,
                                o = this._config,
                                c = o.type,
                                s = o.shape,
                                h = o.blendMode;
                            if (c == l || !t || !e.style && !r) return {
                                attrList: [],
                                options: e,
                                styleList: []
                            };
                            var d = e.style,
                                v = e.selectStyle;
                            e.type ? this._config.type = this._type = e.type : e.type = c, e.shape ? this._config.shape = this._shape = e.shape : e.shape = s, e.blendMode ? this._config.blendMode = e.blendMode : e.blendMode = h;
                            for (var y = t instanceof u.default ? t : new u.default(t, i), _ = r || (0, f.normalizeWithScale)(y, d), g = (0, f.transformCoordinate)(y, e), b = [], m = -1, w = g.length; ++m < w;) {
                                var O = g[m];
                                if ((0, f.checkLngLat)(O)) {
                                    for (var x = a.default.merge(_[m], _.style), M = y.getRow(m), j = {}, k = -1, P = p.length; ++k < P;) {
                                        var E = p[k],
                                            A = e[E];
                                        void 0 !== A && (j[E] = a.default.isFunction(A) ? A.call(this, {
                                            value: M,
                                            index: m
                                        }) : A)
                                    }
                                    j.position = O, j.lnglat = O, "point" === e.type && void 0 === e.shape ? j.type = "circle" : j.type = e.shape || e.type, j.data = M, j.style = x, v && (j.selectStyle = v), b.push(j)
                                }
                            }
                            return {
                                attrList: b,
                                options: e,
                                styleList: _
                            }
                        }
                    }, {
                        key: "_createGroup",
                        value: function() {
                            if (this._group) return this._group;
                            var t = "3D" === this._visualMap.getViewMode(),
                                e = this._config,
                                n = e.type,
                                r = e.shape,
                                i = (e.eventSupport, void 0);
                            if (n === l) switch (r) {
                                case "hexagon":
                                case "rectangle":
                                    i = c.MapGridHeatMapFeatureGroup;
                                    break;
                                case "district":
                                    this._groupedByAdcode = {}, i = c.Choropleth;
                                    break;
                                case "heatmap":
                                default:
                                    i = c.MapHeatMapFeatureGroup
                            } else i = "contour" === n ? c.MapContourFeatureGroup : t ? c.Map3DOverlayGroup : c.MapOverlayGroup;
                            var o = new i([], this._config);
                            return n === l && o.addEventParent(this), this._group = o, this.emit("groupReady"), o
                        }
                    }, {
                        key: "_createOverlays",
                        value: function() {
                            var t = "3D" === this._visualMap.getViewMode(),
                                e = this._config,
                                n = e.eventSupport,
                                r = e.type,
                                i = e.shape,
                                o = e.vertex,
                                a = void 0;
                            switch (r) {
                                case "line":
                                    a = t ? c.Map3DLine : c.MapLine;
                                    break;
                                case "polygon":
                                    a = t ? c.Map3DPolygon : c.MapPolygon;
                                    break;
                                case "point":
                                    a = t ? "prism" === i ? c.Map3DAcceptLightPrism : c.Map3DPoints : c.MapPoint;
                                    break;
                                default:
                                    return
                            }
                            var u = [],
                                f = this._renderData.attrList;
                            if (a == c.Map3DAcceptLightPrism || a == c.Map3DPoints) {
                                for (var s = this._options, l = s.light, h = s.heightUnit, p = s.selectStyle, d = s.crossDateLine, v = -1, y = f.length, _ = [], g = [], b = [], m = []; ++v < y;) {
                                    var w = f[v],
                                        O = w.data,
                                        x = w.lnglat,
                                        M = w.style,
                                        j = w.source;
                                    _.push(O), g.push(x), b.push(M), m.push(j)
                                }
                                var k = new a(_, {
                                    position: function(t, e) {
                                        return g[e]
                                    },
                                    crossDateLine: d,
                                    source: m,
                                    type: i,
                                    vertex: o,
                                    unit: "meter",
                                    heightUnit: h,
                                    light: l,
                                    style: b,
                                    selectStyle: p
                                });
                                u.push(k)
                            } else
                                for (var P = -1, E = f.length; ++P < E;) {
                                    var A = f[P];
                                    if (!A.invisible) {
                                        var L = new a(A.data, A);
                                        u.push(L)
                                    }
                                }
                            this._overlays = u;
                            for (var C = -1, S = u.length; ++C < S;) {
                                var T = u[C];
                                n && T.addEventParent(this, function(t) {
                                    var e = t.originalEvent,
                                        n = t.target;
                                    return {
                                        originalTarget: n,
                                        originalEvent: e,
                                        rawData: n.getData({
                                            selectSingle: 1
                                        }),
                                        lnglat: n.getPosition().valueOf()
                                    }
                                })
                            }
                        }
                    }, {
                        key: "render",
                        value: function(t) {
                            var e = this,
                                n = this._visualMap;
                            n && n.whenReady(function() {
                                var r = e._group,
                                    i = e._type,
                                    o = e._shape,
                                    u = e._dataSet,
                                    c = e._options,
                                    f = "3D" === n.getViewMode();
                                if (t ? e._renderData = t : e._updateAttr(), i === l) {
                                    var s = u.getData(),
                                        h = u.getOptions(),
                                        p = h.lnglat;
                                    a.default.isFn(p) && (h.lnglat = function(t, n) {
                                        return p.call(e, {
                                            value: t,
                                            index: n
                                        })
                                    }), h.position = h.lnglat, r.setData(s, h), c.shape = o, r.setOptions(c), r.render(), e._overlaysReady = !0, e.emit("overlaysReady")
                                } else if ("contour" === i) {
                                    var d = u.getData(),
                                        v = u.getOptions();
                                    r.setData(d, v), c.shape = o, r.setOptions(c), r.render(), e._overlaysReady = !0, e.emit("overlaysReady")
                                } else {
                                    e._createOverlays();
                                    var y = e._overlays;
                                    y && r && (f || r.whenReady(function() {
                                        r._setContextConfig({
                                            blendMode: e._renderData.options.blendMode
                                        })
                                    }), r.removeOverlay().addOverlay(y), e._overlaysReady = !0, e.emit("overlaysReady"))
                                }
                            })
                        }
                    }, {
                        key: "draw",
                        value: function(t) {
                            this._renderData = t, this.render(t)
                        }
                    }, {
                        key: "addTo",
                        value: function(t) {
                            return this._visualMap || (this._visualMap = t, t.addLayer(this)), this
                        }
                    }, {
                        key: "remove",
                        value: function() {
                            return this._visualMap && (this._visualMap.removeLayer(this), delete this._visualMap), this
                        }
                    }, {
                        key: "setZIndex",
                        value: function(t) {
                            var e = this;
                            return this.whenGroupReady(function() {
                                e._group.setZIndex(t)
                            }), this
                        }
                    }, {
                        key: "setFitView",
                        value: function() {
                            var t = this;
                            return this.whenOverlaysReady(function() {
                                t._group.setFitView()
                            }), this
                        }
                    }, {
                        key: "goto",
                        value: function(t) {
                            var e = this;
                            return this.whenGroupReady(function() {
                                e._group.goto(t)
                            }), this
                        }
                    }, {
                        key: "changeMode",
                        value: function(t) {
                            var e = this;
                            return this.whenGroupReady(function() {
                                e._group.changeMode(t)
                            }), this
                        }
                    }, {
                        key: "whenOverlaysReady",
                        value: function(t) {
                            this._overlaysReady ? t.call(this) : this.once("overlaysReady", t)
                        }
                    }, {
                        key: "whenGroupReady",
                        value: function(t) {
                            this._group ? t.call(this) : this.once("groupReady", t)
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off(), this.remove(), this._group && this._group.destroy(), delete this._group
                        }
                    }]), e
                }();
            e.VisualLayer = d, e.visualLayer = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(d, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.visualMap = e.VisualMap = void 0;
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(8)),
                a = r(n(0)),
                u = n(41),
                c = n(4),
                f = n(1),
                s = {
                    Cfg: {
                        eventSupport: !0,
                        viewMode: "3D"
                    }
                },
                l = function(t) {
                    function e(t, n) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var r = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
                        r._config = {}, r._hasLoad = !1, r._config = a.default.defaults(n || {}, s.Cfg);
                        return (r._map = new u.MapContainer(t, r._config).on(c.Event.LOAD, function() {
                            r._hasLoad = !0, r.emit(c.Event.MAP_LOAD);
                            var t = r._config,
                                e = t.log,
                                n = void 0 === e || e,
                                i = t.viewMode;
                            if (n) {
                                var o = r._map._amapLoader;
                                f.FunLog.key = o._getAPIKey(), f.FunLog.record("VisualMap_init", "viewMode", i), setInterval(function() {
                                    f.FunLog.send()
                                }, 1e4)
                            }
                        })).addEventParent(r), r
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "addLayer",
                        value: function(t) {
                            var e = this;
                            return this._map.whenReady(function() {
                                t._createGroup().addTo(e._map)
                            }), this
                        }
                    }, {
                        key: "removeLayer",
                        value: function(t) {
                            return t._group.remove(), this
                        }
                    }, {
                        key: "getMap",
                        value: function() {
                            return this._map && this._map.getMap()
                        }
                    }, {
                        key: "getViewMode",
                        value: function() {
                            return this._map && this._map.getMap().getViewMode_()
                        }
                    }, {
                        key: "whenReady",
                        value: function(t) {
                            this._hasLoad ? t.call(this) : this._map.on(c.Event.LOAD, t)
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off(), this._map && this._map.destroy(), delete this._map
                        }
                    }]), e
                }();
            e.VisualMap = l, e.visualMap = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return new(Function.prototype.bind.apply(l, [null].concat(e)))
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(141);
            Object.keys(r).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return r[t]
                    }
                })
            });
            var i = n(140);
            Object.keys(i).forEach(function(t) {
                "default" !== t && "__esModule" !== t && Object.defineProperty(e, t, {
                    enumerable: !0,
                    get: function() {
                        return i[t]
                    }
                })
            })
        },
        function(t, e, n) {
            ! function() {
                "use strict";
                var e = n(61),
                    r = function(t) {
                        this.curves = [], this._3d = !1, t && (this.curves = t, this._3d = this.curves[0]._3d)
                    };
                r.prototype = {
                    valueOf: function() {
                        return this.toString()
                    },
                    toString: function() {
                        return "[" + this.curves.map(function(t) {
                            return e.pointsToString(t.points)
                        }).join(", ") + "]"
                    },
                    addCurve: function(t) {
                        this.curves.push(t), this._3d = this._3d || t._3d
                    },
                    length: function() {
                        return this.curves.map(function(t) {
                            return t.length()
                        }).reduce(function(t, e) {
                            return t + e
                        })
                    },
                    curve: function(t) {
                        return this.curves[t]
                    },
                    bbox: function() {
                        for (var t = this.curves, n = t[0].bbox(), r = 1; r < t.length; r++) e.expandbox(n, t[r].bbox());
                        return n
                    },
                    offset: function(t) {
                        var e = [];
                        return this.curves.forEach(function(n) {
                            e = e.concat(n.offset(t))
                        }), new r(e)
                    }
                }, t.exports = r
            }()
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    function t(t, e) {
                        for (var n = 0; n < e.length; n++) {
                            var r = e[n];
                            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                        }
                    }
                    return function(e, n, r) {
                        return n && t(e.prototype, n), r && t(e, r), e
                    }
                }(),
                o = r(n(64)),
                a = r(n(148)),
                u = n(146),
                c = n(63),
                f = a.default.remove,
                s = a.default.forInMap,
                l = function(t) {
                    function e(t) {
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e);
                        var n = function(t, e) {
                            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                            return !e || "object" != typeof e && "function" != typeof e ? t : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this));
                        return n._options = {}, n._savedClipMap = {}, n._clips = [], n._clipMap = {}, n._options = t || {}, n
                    }
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, o["default"]), i(e, [{
                        key: "_startAni",
                        value: function() {
                            var t = this;
                            this._timer = (0, u.requestAnimationFrame)(function e(n) {
                                t._timer = (0, u.requestAnimationFrame)(e), t._update(n)
                            })
                        }
                    }, {
                        key: "_stopAni",
                        value: function() {
                            var t = this._timer;
                            return !!t && ((0, u.cancelAnimationFrame)(t), this._timer = null, !0)
                        }
                    }, {
                        key: "_update",
                        value: function(t) {
                            var e = this._clips;
                            this.emit(c.Ev.UPDATE, {
                                timestamp: t
                            });
                            for (var n = 0; n < e.length;) {
                                var r = e[n];
                                r.update(t) ? n++ : this._rmClip(r)
                            }
                            this._clips = e, this.emit(c.Ev.AFTER_UPDATE), 0 === e.length && (this._stopAni(), this.emit(c.Ev.COMPLETE))
                        }
                    }, {
                        key: "start",
                        value: function() {
                            var t = this._clips,
                                e = t.length;
                            if (this._timer || 0 === e) return this;
                            this.emit(c.Ev.START);
                            for (var n = -1; ++n < e;) {
                                t[n].start()
                            }
                            return this._startAni(), this
                        }
                    }, {
                        key: "stop",
                        value: function() {
                            return this._stop(!1), this
                        }
                    }, {
                        key: "pause",
                        value: function() {
                            return this._stop(!0), this
                        }
                    }, {
                        key: "reset",
                        value: function() {
                            this._stop(!1, !0, !1);
                            var t = this._savedClipMap,
                                e = [];
                            return s(t, function(t) {
                                t.stop(!0), e.push(t)
                            }), this._clips = e, this.emit(c.Ev.RESET), this
                        }
                    }, {
                        key: "_stop",
                        value: function(t, e) {
                            var n = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
                            this._stopAni();
                            var r = this._clips,
                                i = r.length;
                            if (i) {
                                for (var o = -1; ++o < i;) {
                                    var a = r[o];
                                    t ? a.pause() : a.stop(e)
                                }
                                n && this.emit(t ? c.Ev.PAUSE : c.Ev.STOP)
                            }
                        }
                    }, {
                        key: "addClip",
                        value: function(t) {
                            var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                            Array.isArray(t) || (t = [t]);
                            for (var n = -1, r = t.length; ++n < r;) {
                                var i = t[n];
                                this._hasSavedClip(i) || (this._addClip(i), this._addSavedClip(i), this._timer && e && i.start())
                            }
                            return this
                        }
                    }, {
                        key: "_addClip",
                        value: function(t) {
                            var e = this._clips; - 1 === e.indexOf(t) && (e.push(t), t._animation = this)
                        }
                    }, {
                        key: "_addSavedClip",
                        value: function(t) {
                            var e = this._savedClipMap,
                                n = t.id;
                            e[n] !== t && (e[n] = t, t._animation = this)
                        }
                    }, {
                        key: "removeClip",
                        value: function(t) {
                            var e = this._savedClipMap;
                            return t ? (this._rmClip(t), this._rmSavedClip(t), t._animation = null) : (s(e, function(t) {
                                t._animation = null
                            }), this._clips = [], this._savedClipMap = {}), this
                        }
                    }, {
                        key: "_rmClip",
                        value: function(t) {
                            f(this._clips, function(e) {
                                return e === t
                            })
                        }
                    }, {
                        key: "_rmSavedClip",
                        value: function(t) {
                            this._hasSavedClip(t) && delete this._savedClipMap[t.id]
                        }
                    }, {
                        key: "getClips",
                        value: function() {
                            return this._clips
                        }
                    }, {
                        key: "_hasSavedClip",
                        value: function(t) {
                            var e = t.id,
                                n = this._savedClipMap[e];
                            return n && n === t
                        }
                    }, {
                        key: "_hasClip",
                        value: function(t) {
                            return -1 !== this._clips.indexOf(t)
                        }
                    }, {
                        key: "destroy",
                        value: function() {
                            this.off(), this._stopAni(), this.removeClip()
                        }
                    }]), e
                }();
            l.Event = c.Ev, e.default = l
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = {
                Linear: function(t, e) {
                    var n = t.length - 1,
                        i = n * e,
                        o = Math.floor(i),
                        a = r.Utils.Linear;
                    return e < 0 ? a(t[0], t[1], i) : e > 1 ? a(t[n], t[n - 1], n - i) : a(t[o], t[o + 1 > n ? n : o + 1], i - o)
                },
                Bezier: function(t, e) {
                    for (var n = 0, i = t.length - 1, o = Math.pow, a = r.Utils.Bernstein, u = 0; u <= i; u++) n += o(1 - e, i - u) * o(e, u) * t[u] * a(i, u);
                    return n
                },
                CatmullRom: function(t, e) {
                    var n = t.length - 1,
                        i = n * e,
                        o = Math.floor(i),
                        a = r.Utils.CatmullRom;
                    return t[0] === t[n] ? (e < 0 && (o = Math.floor(i = n * (1 + e))), a(t[(o - 1 + n) % n], t[o], t[(o + 1) % n], t[(o + 2) % n], i - o)) : e < 0 ? t[0] - (a(t[0], t[0], t[1], t[1], -i) - t[0]) : e > 1 ? t[n] - (a(t[n], t[n], t[n - 1], t[n - 1], i - n) - t[n]) : a(t[o ? o - 1 : 0], t[o], t[n < o + 1 ? n : o + 1], t[n < o + 2 ? n : o + 2], i - o)
                },
                Utils: {
                    Linear: function(t, e, n) {
                        return (e - t) * n + t
                    },
                    Bernstein: function(t, e) {
                        var n = r.Utils.Factorial;
                        return n(t) / n(e) / n(t - e)
                    },
                    Factorial: function() {
                        var t = [1];
                        return function(e) {
                            var n = 1;
                            if (t[e]) return t[e];
                            for (var r = e; r > 1; r--) n *= r;
                            return t[e] = n, n
                        }
                    }(),
                    CatmullRom: function(t, e, n, r, i) {
                        var o = .5 * (n - t),
                            a = .5 * (r - e),
                            u = i * i;
                        return (2 * e - 2 * n + o + a) * (i * u) + (-3 * e + 3 * n - 2 * o - a) * u + o * i + e
                    }
                }
            };
            e.default = r
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                    value: !0
                }),
                function() {
                    if ("performance" in window == !1 && (window.performance = {}), Date.now = Date.now || function() {
                        return (new Date).getTime()
                    }, "now" in window.performance == !1) {
                        var t = window.performance.timing && window.performance.timing.navigationStart ? window.performance.timing.navigationStart : Date.now();
                        window.performance.now = function() {
                            return Date.now() - t
                        }
                    }
                }();
            var r = "undefined" != typeof window && (window.requestAnimationFrame || window.msRequestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame) || function(t) {
                    setTimeout(t, 16)
                },
                i = "undefined" != typeof window && (window.cancelAnimationFrame || window.msCancelAnimationFrame || window.mozCancelAnimationFrame || window.webkitCancelAnimationFrame) || function(t) {
                    clearTimeout(t)
                };
            e.requestAnimationFrame = r, e.cancelAnimationFrame = i
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = {
                Linear: function(t) {
                    return t
                },
                QuadraticIn: function(t) {
                    return t * t
                },
                QuadraticOut: function(t) {
                    return t * (2 - t)
                },
                QuadraticInOut: function(t) {
                    return (t *= 2) < 1 ? .5 * t * t : -.5 * (--t * (t - 2) - 1)
                },
                CubicIn: function(t) {
                    return t * t * t
                },
                CubicOut: function(t) {
                    return --t * t * t + 1
                },
                CubicInOut: function(t) {
                    return (t *= 2) < 1 ? .5 * t * t * t : .5 * ((t -= 2) * t * t + 2)
                },
                QuarticIn: function(t) {
                    return t * t * t * t
                },
                QuarticOut: function(t) {
                    return 1 - --t * t * t * t
                },
                QuarticInOut: function(t) {
                    return (t *= 2) < 1 ? .5 * t * t * t * t : -.5 * ((t -= 2) * t * t * t - 2)
                },
                QuinticIn: function(t) {
                    return t * t * t * t * t
                },
                QuinticOut: function(t) {
                    return --t * t * t * t * t + 1
                },
                QuinticInOut: function(t) {
                    return (t *= 2) < 1 ? .5 * t * t * t * t * t : .5 * ((t -= 2) * t * t * t * t + 2)
                },
                SinusoidalIn: function(t) {
                    return 1 - Math.cos(t * Math.PI / 2)
                },
                SinusoidalOut: function(t) {
                    return Math.sin(t * Math.PI / 2)
                },
                SinusoidalInOut: function(t) {
                    return .5 * (1 - Math.cos(Math.PI * t))
                },
                ExponentialIn: function(t) {
                    return 0 === t ? 0 : Math.pow(1024, t - 1)
                },
                ExponentialOut: function(t) {
                    return 1 === t ? 1 : 1 - Math.pow(2, -10 * t)
                },
                ExponentialInOut: function(t) {
                    return 0 === t ? 0 : 1 === t ? 1 : (t *= 2) < 1 ? .5 * Math.pow(1024, t - 1) : .5 * (2 - Math.pow(2, -10 * (t - 1)))
                },
                CircularIn: function(t) {
                    return 1 - Math.sqrt(1 - t * t)
                },
                CircularOut: function(t) {
                    return Math.sqrt(1 - --t * t)
                },
                CircularInOut: function(t) {
                    return (t *= 2) < 1 ? -.5 * (Math.sqrt(1 - t * t) - 1) : .5 * (Math.sqrt(1 - (t -= 2) * t) + 1)
                },
                ElasticIn: function(t) {
                    var e, n = .1;
                    return 0 === t ? 0 : 1 === t ? 1 : (!n || n < 1 ? (n = 1, e = .1) : e = .4 * Math.asin(1 / n) / (2 * Math.PI), -n * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / .4))
                },
                ElasticOut: function(t) {
                    var e, n = .1;
                    return 0 === t ? 0 : 1 === t ? 1 : (!n || n < 1 ? (n = 1, e = .1) : e = .4 * Math.asin(1 / n) / (2 * Math.PI), n * Math.pow(2, -10 * t) * Math.sin((t - e) * (2 * Math.PI) / .4) + 1)
                },
                ElasticInOut: function(t) {
                    var e, n = .1;
                    return 0 === t ? 0 : 1 === t ? 1 : (!n || n < 1 ? (n = 1, e = .1) : e = .4 * Math.asin(1 / n) / (2 * Math.PI), (t *= 2) < 1 ? n * Math.pow(2, 10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / .4) * -.5 : n * Math.pow(2, -10 * (t -= 1)) * Math.sin((t - e) * (2 * Math.PI) / .4) * .5 + 1)
                },
                BackIn: function(t) {
                    return t * t * (2.70158 * t - 1.70158)
                },
                BackOut: function(t) {
                    return --t * t * (2.70158 * t + 1.70158) + 1
                },
                BackInOut: function(t) {
                    return (t *= 2) < 1 ? t * t * (3.5949095 * t - 2.5949095) * .5 : .5 * ((t -= 2) * t * (3.5949095 * t + 2.5949095) + 2)
                },
                BounceIn: function(t) {
                    return 1 - r.BounceOut(1 - t)
                },
                BounceOut: function(t) {
                    return t < 1 / 2.75 ? 7.5625 * t * t : t < 2 / 2.75 ? 7.5625 * (t -= 1.5 / 2.75) * t + .75 : t < 2.5 / 2.75 ? 7.5625 * (t -= 2.25 / 2.75) * t + .9375 : 7.5625 * (t -= 2.625 / 2.75) * t + .984375
                },
                BounceInOut: function(t) {
                    return t < .5 ? .5 * r.BounceIn(2 * t) : .5 * r.BounceOut(2 * t - 1) + .5
                }
            };
            e.default = r
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (!Array.isArray(t)) return t;
                var n = e.type,
                    o = void 0 === n ? "" : n,
                    a = e.range,
                    u = void 0 === a ? [0, 1] : a,
                    c = e.min,
                    f = void 0 === c ? Math.min.apply(Math, t) : c,
                    s = e.max,
                    l = void 0 === s ? Math.max.apply(Math, t) : s;
                o = o.toLowerCase();
                for (var h = [], p = l - f, d = -1, v = t.length; ++d < v;) {
                    var y = t[d];
                    y > l && (y = l), y < f && (y = f);
                    var _ = void 0;
                    _ = "log" !== o ? (y - f) / p : Math.log10(y), h.push(_)
                }
                "log" === o && (h = r(h));
                var g = i(u, 2),
                    b = g[0],
                    m = g[1];
                if (0 !== b || 1 !== m) {
                    for (var w = -1, O = h.length, x = m - b, M = []; ++w < O;) {
                        var j = x * h[w] + b;
                        M.push(j)
                    }
                    h = M
                }
                return h
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                return function(t, e) {
                    if (Array.isArray(t)) return t;
                    if (Symbol.iterator in Object(t)) return function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            o = void 0;
                        try {
                            for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                        } catch (t) {
                            i = !0, o = t
                        } finally {
                            try {
                                !r && u.return && u.return()
                            } finally {
                                if (i) throw o
                            }
                        }
                        return n
                    }(t, e);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                }
            }();
            e.default = {
                remove: function(t, e) {
                    var n = [];
                    if (!t || !t.length) return n;
                    if ("function" == typeof e) {
                        for (var r = -1, i = [], o = t.length; ++r < o;) {
                            var a = t[r];
                            e(a, r, t) && (n.push(a), i.push(r))
                        }! function(t, e) {
                            for (var n = t ? e.length : 0; n-- > 0;) {
                                var r = e[n];
                                t.splice(r, 1)
                            }
                        }(t, i)
                    }
                    return n
                },
                normalize: r,
                forInMap: function(t, e) {
                    for (var n in t) t.hasOwnProperty(n) && e(t[n], n, t)
                }
            }
        },
        function(t, e, n) {
            "use strict";
            n(151)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return (t = Math.round(t)) < 0 ? 0 : t > 255 ? 255 : t
            }

            function i(t) {
                return t < 0 ? 0 : t > 1 ? 1 : t
            }

            function o(t) {
                return "%" === t[t.length - 1] ? r(parseFloat(t) / 100 * 255) : r(parseInt(t))
            }

            function a(t) {
                return "%" === t[t.length - 1] ? i(parseFloat(t) / 100) : i(parseFloat(t))
            }

            function u(t, e, n) {
                return n < 0 ? n += 1 : n > 1 && (n -= 1), 6 * n < 1 ? t + (e - t) * n * 6 : 2 * n < 1 ? e : 3 * n < 2 ? t + (e - t) * (2 / 3 - n) * 6 : t
            }

            function c(t) {
                var e = t.replace(/ /g, "").toLowerCase();
                if (e in f) return f[e].slice();
                if ("#" === e[0]) {
                    if (4 === e.length) {
                        return (n = parseInt(e.substr(1), 16)) >= 0 && n <= 4095 ? [(3840 & n) >> 4 | (3840 & n) >> 8, 240 & n | (240 & n) >> 4, 15 & n | (15 & n) << 4, 1] : null
                    }
                    if (7 === e.length) {
                        var n;
                        return (n = parseInt(e.substr(1), 16)) >= 0 && n <= 16777215 ? [(16711680 & n) >> 16, (65280 & n) >> 8, 255 & n, 1] : null
                    }
                    return null
                }
                var i = e.indexOf("("),
                    c = e.indexOf(")");
                if (-1 !== i && c + 1 === e.length) {
                    var s = e.substr(0, i),
                        l = e.substr(i + 1, c - (i + 1)).split(","),
                        h = 1;
                    switch (s) {
                        case "rgba":
                            if (4 !== l.length) return null;
                            h = a(l.pop());
                        case "rgb":
                            return 3 !== l.length ? null : [o(l[0]), o(l[1]), o(l[2]), h];
                        case "hsla":
                            if (4 !== l.length) return null;
                            h = a(l.pop());
                        case "hsl":
                            if (3 !== l.length) return null;
                            var p = (parseFloat(l[0]) % 360 + 360) % 360 / 360,
                                d = a(l[1]),
                                v = a(l[2]),
                                y = v <= .5 ? v * (d + 1) : v + d - v * d,
                                _ = 2 * v - y;
                            return [r(255 * u(_, y, p + 1 / 3)), r(255 * u(_, y, p)), r(255 * u(_, y, p - 1 / 3)), h];
                        default:
                            return null
                    }
                }
                return null
            }
            var f = {
                transparent: [0, 0, 0, 0],
                aliceblue: [240, 248, 255, 1],
                antiquewhite: [250, 235, 215, 1],
                aqua: [0, 255, 255, 1],
                aquamarine: [127, 255, 212, 1],
                azure: [240, 255, 255, 1],
                beige: [245, 245, 220, 1],
                bisque: [255, 228, 196, 1],
                black: [0, 0, 0, 1],
                blanchedalmond: [255, 235, 205, 1],
                blue: [0, 0, 255, 1],
                blueviolet: [138, 43, 226, 1],
                brown: [165, 42, 42, 1],
                burlywood: [222, 184, 135, 1],
                cadetblue: [95, 158, 160, 1],
                chartreuse: [127, 255, 0, 1],
                chocolate: [210, 105, 30, 1],
                coral: [255, 127, 80, 1],
                cornflowerblue: [100, 149, 237, 1],
                cornsilk: [255, 248, 220, 1],
                crimson: [220, 20, 60, 1],
                cyan: [0, 255, 255, 1],
                darkblue: [0, 0, 139, 1],
                darkcyan: [0, 139, 139, 1],
                darkgoldenrod: [184, 134, 11, 1],
                darkgray: [169, 169, 169, 1],
                darkgreen: [0, 100, 0, 1],
                darkgrey: [169, 169, 169, 1],
                darkkhaki: [189, 183, 107, 1],
                darkmagenta: [139, 0, 139, 1],
                darkolivegreen: [85, 107, 47, 1],
                darkorange: [255, 140, 0, 1],
                darkorchid: [153, 50, 204, 1],
                darkred: [139, 0, 0, 1],
                darksalmon: [233, 150, 122, 1],
                darkseagreen: [143, 188, 143, 1],
                darkslateblue: [72, 61, 139, 1],
                darkslategray: [47, 79, 79, 1],
                darkslategrey: [47, 79, 79, 1],
                darkturquoise: [0, 206, 209, 1],
                darkviolet: [148, 0, 211, 1],
                deeppink: [255, 20, 147, 1],
                deepskyblue: [0, 191, 255, 1],
                dimgray: [105, 105, 105, 1],
                dimgrey: [105, 105, 105, 1],
                dodgerblue: [30, 144, 255, 1],
                firebrick: [178, 34, 34, 1],
                floralwhite: [255, 250, 240, 1],
                forestgreen: [34, 139, 34, 1],
                fuchsia: [255, 0, 255, 1],
                gainsboro: [220, 220, 220, 1],
                ghostwhite: [248, 248, 255, 1],
                gold: [255, 215, 0, 1],
                goldenrod: [218, 165, 32, 1],
                gray: [128, 128, 128, 1],
                green: [0, 128, 0, 1],
                greenyellow: [173, 255, 47, 1],
                grey: [128, 128, 128, 1],
                honeydew: [240, 255, 240, 1],
                hotpink: [255, 105, 180, 1],
                indianred: [205, 92, 92, 1],
                indigo: [75, 0, 130, 1],
                ivory: [255, 255, 240, 1],
                khaki: [240, 230, 140, 1],
                lavender: [230, 230, 250, 1],
                lavenderblush: [255, 240, 245, 1],
                lawngreen: [124, 252, 0, 1],
                lemonchiffon: [255, 250, 205, 1],
                lightblue: [173, 216, 230, 1],
                lightcoral: [240, 128, 128, 1],
                lightcyan: [224, 255, 255, 1],
                lightgoldenrodyellow: [250, 250, 210, 1],
                lightgray: [211, 211, 211, 1],
                lightgreen: [144, 238, 144, 1],
                lightgrey: [211, 211, 211, 1],
                lightpink: [255, 182, 193, 1],
                lightsalmon: [255, 160, 122, 1],
                lightseagreen: [32, 178, 170, 1],
                lightskyblue: [135, 206, 250, 1],
                lightslategray: [119, 136, 153, 1],
                lightslategrey: [119, 136, 153, 1],
                lightsteelblue: [176, 196, 222, 1],
                lightyellow: [255, 255, 224, 1],
                lime: [0, 255, 0, 1],
                limegreen: [50, 205, 50, 1],
                linen: [250, 240, 230, 1],
                magenta: [255, 0, 255, 1],
                maroon: [128, 0, 0, 1],
                mediumaquamarine: [102, 205, 170, 1],
                mediumblue: [0, 0, 205, 1],
                mediumorchid: [186, 85, 211, 1],
                mediumpurple: [147, 112, 219, 1],
                mediumseagreen: [60, 179, 113, 1],
                mediumslateblue: [123, 104, 238, 1],
                mediumspringgreen: [0, 250, 154, 1],
                mediumturquoise: [72, 209, 204, 1],
                mediumvioletred: [199, 21, 133, 1],
                midnightblue: [25, 25, 112, 1],
                mintcream: [245, 255, 250, 1],
                mistyrose: [255, 228, 225, 1],
                moccasin: [255, 228, 181, 1],
                navajowhite: [255, 222, 173, 1],
                navy: [0, 0, 128, 1],
                oldlace: [253, 245, 230, 1],
                olive: [128, 128, 0, 1],
                olivedrab: [107, 142, 35, 1],
                orange: [255, 165, 0, 1],
                orangered: [255, 69, 0, 1],
                orchid: [218, 112, 214, 1],
                palegoldenrod: [238, 232, 170, 1],
                palegreen: [152, 251, 152, 1],
                paleturquoise: [175, 238, 238, 1],
                palevioletred: [219, 112, 147, 1],
                papayawhip: [255, 239, 213, 1],
                peachpuff: [255, 218, 185, 1],
                peru: [205, 133, 63, 1],
                pink: [255, 192, 203, 1],
                plum: [221, 160, 221, 1],
                powderblue: [176, 224, 230, 1],
                purple: [128, 0, 128, 1],
                rebeccapurple: [102, 51, 153, 1],
                red: [255, 0, 0, 1],
                rosybrown: [188, 143, 143, 1],
                royalblue: [65, 105, 225, 1],
                saddlebrown: [139, 69, 19, 1],
                salmon: [250, 128, 114, 1],
                sandybrown: [244, 164, 96, 1],
                seagreen: [46, 139, 87, 1],
                seashell: [255, 245, 238, 1],
                sienna: [160, 82, 45, 1],
                silver: [192, 192, 192, 1],
                skyblue: [135, 206, 235, 1],
                slateblue: [106, 90, 205, 1],
                slategray: [112, 128, 144, 1],
                slategrey: [112, 128, 144, 1],
                snow: [255, 250, 250, 1],
                springgreen: [0, 255, 127, 1],
                steelblue: [70, 130, 180, 1],
                tan: [210, 180, 140, 1],
                teal: [0, 128, 128, 1],
                thistle: [216, 191, 216, 1],
                tomato: [255, 99, 71, 1],
                turquoise: [64, 224, 208, 1],
                violet: [238, 130, 238, 1],
                wheat: [245, 222, 179, 1],
                white: [255, 255, 255, 1],
                whitesmoke: [245, 245, 245, 1],
                yellow: [255, 255, 0, 1],
                yellowgreen: [154, 205, 50, 1]
            };
            try {
                e.parseCSSColor = c
            } catch (t) {}
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = r(n(29)),
                o = r(n(66)),
                a = {
                    type: "color",
                    test: function(t, e) {
                        return o.default.isColor(t)
                    },
                    parse: function(t, e) {
                        return o.default.toNormalArray(t)
                    },
                    valueOf: function(t, e, n, r) {
                        var i = o.default.linearGradient(t, e);
                        return i = o.default.toRGBA(i)
                    }
                };
            i.default.registerPlugin(a), e.default = a
        },
        function(t, e, n) {
            "use strict";
            n(153)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                }
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var i = function() {
                    return function(t, e) {
                        if (Array.isArray(t)) return t;
                        if (Symbol.iterator in Object(t)) return function(t, e) {
                            var n = [],
                                r = !0,
                                i = !1,
                                o = void 0;
                            try {
                                for (var a, u = t[Symbol.iterator](); !(r = (a = u.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
                            } catch (t) {
                                i = !0, o = t
                            } finally {
                                try {
                                    !r && u.return && u.return()
                                } finally {
                                    if (i) throw o
                                }
                            }
                            return n
                        }(t, e);
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }
                }(),
                o = r(n(29)),
                a = r(n(154)),
                u = {
                    type: "coordinate-2d",
                    test: function(t, e) {
                        var n = !1;
                        if (Array.isArray(t))
                            for (var r = -1, o = t.length; ++r < o;) {
                                var a = t[r];
                                if (Array.isArray(a)) {
                                    var u = i(a, 2),
                                        c = u[0],
                                        f = u[1],
                                        s = [+c, +f];
                                    f = s[1], n = "number" == typeof(c = s[0]) && "number" == typeof f && isFinite(c) && isFinite(f)
                                }
                            }
                        return n
                    },
                    parse: function(t, e) {
                        for (var n = [], r = -1, o = t.length; ++r < o;) {
                            var u = t[r],
                                c = i(u, 2),
                                f = c[0],
                                s = c[1],
                                l = [+f, +s];
                            f = l[0], s = l[1], n.push([f, s])
                        }
                        return function(t) {
                            for (var e = 0, n = t.length, r = 0, i = [], o = [], u = 0; e < n - 1;) {
                                var c = t[e],
                                    f = t[e + 1],
                                    s = a.default.distance(c, f);
                                r += s, u = a.default.getAngle(f, c), i.push(c), o.push({
                                    length: r,
                                    segmentLength: s,
                                    segment: [c.slice(), f.slice()],
                                    path: i.slice(),
                                    angle: u
                                }), e++
                            }
                            return o.sum = r, o
                        }(n)
                    },
                    valueOf: function(t, e, n, r) {
                        for (var o = t.sum * e, u = -1, c = t.length, f = t[0]; ++u < c;) {
                            var s = t[u];
                            if (o <= s.length) {
                                f = s;
                                break
                            }
                        }
                        var l = i(f.segment, 2),
                            h = l[0],
                            p = l[1],
                            d = (0 == u ? o : o - t[u - 1].length) / f.segmentLength,
                            v = a.default.create(),
                            y = a.default.create();
                        return a.default.sub(v, p, h), a.default.scaleAndAdd(y, h, v, d), y.step = f, y
                    }
                };
            o.default.registerPlugin(u), e.default = u
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = "undefined" == typeof Float32Array ? Array : Float32Array,
                i = {
                    create: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0,
                            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                            n = new r(2);
                        return n[0] = t, n[1] = e, n
                    },
                    copy: function(t, e) {
                        return t[0] = e[0], t[1] = e[1], t
                    },
                    clone: function(t) {
                        var e = new r(2);
                        return e[0] = t[0], e[1] = t[1], e
                    },
                    set: function(t, e, n) {
                        return t[0] = e, t[1] = n, t
                    },
                    add: function(t, e, n) {
                        return t[0] = e[0] + n[0], t[1] = e[1] + n[1], t
                    },
                    scaleAndAdd: function(t, e, n, r) {
                        return t[0] = e[0] + n[0] * r, t[1] = e[1] + n[1] * r, t
                    },
                    sub: function(t, e, n) {
                        return t[0] = e[0] - n[0], t[1] = e[1] - n[1], t
                    },
                    length: function(t) {
                        return Math.sqrt(this.lengthSquare(t))
                    },
                    lengthSquare: function(t) {
                        return t[0] * t[0] + t[1] * t[1]
                    },
                    multiply: function(t, e, n) {
                        return t[0] = e[0] * n[0], t[1] = e[1] * n[1], t
                    },
                    divide: function(t, e, n) {
                        return t[0] = e[0] / n[0], t[1] = e[1] / n[1], t
                    },
                    dot: function(t, e) {
                        return t[0] * e[0] + t[1] * e[1]
                    },
                    scale: function(t, e, n) {
                        return t[0] = e[0] * n, t[1] = e[1] * n, t
                    },
                    normalize: function(t, e) {
                        var n = this.len(e);
                        return 0 === n ? (t[0] = 0, t[1] = 0) : (t[0] = e[0] / n, t[1] = e[1] / n), t
                    },
                    distance: function(t, e) {
                        return Math.sqrt(this.distanceSquare(t, e))
                    },
                    distanceSquare: function(t, e) {
                        return (t[0] - e[0]) * (t[0] - e[0]) + (t[1] - e[1]) * (t[1] - e[1])
                    },
                    negate: function(t, e) {
                        return t[0] = -e[0], t[1] = -e[1], t
                    },
                    lerp: function(t, e, n, r) {
                        return t[0] = e[0] + r * (n[0] - e[0]), t[1] = e[1] + r * (n[1] - e[1]), t
                    },
                    applyTransform: function(t, e, n) {
                        var r = e[0],
                            i = e[1];
                        return t[0] = n[0] * r + n[2] * i + n[4], t[1] = n[1] * r + n[3] * i + n[5], t
                    },
                    min: function(t, e, n) {
                        return t[0] = Math.min(e[0], n[0]), t[1] = Math.min(e[1], n[1]), t
                    },
                    max: function(t, e, n) {
                        return t[0] = Math.max(e[0], n[0]), t[1] = Math.max(e[1], n[1]), t
                    },
                    getAngle: function(t, e) {
                        var n = 0;
                        return 0 != t[0] - e[0] && (n = Math.atan2(t[1] - e[1], t[0] - e[0])), n
                    }
                };
            i.len = i.length, i.lenSquare = i.lengthSquare, i.dist = i.distance, i.distSquare = i.distanceSquare, e.default = i
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return function() {
                    return t
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(73);
            e.a = function(t, e, n) {
                var i, o, a, u, c = t.length,
                    f = e.length,
                    s = new Array(c * f);
                for (null == n && (n = r.b), i = a = 0; i < c; ++i)
                    for (u = t[i], o = 0; o < f; ++o, ++a) s[a] = n(u, e[o]);
                return s
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(67),
                i = n(68),
                o = n(155),
                a = n(71),
                u = n(159),
                c = n(74),
                f = n(76),
                s = n(75);
            e.a = function() {
                function t(t) {
                    var r, o, a = t.length,
                        u = new Array(a);
                    for (r = 0; r < a; ++r) u[r] = e(t[r], r, t);
                    var s = l(u),
                        p = s[0],
                        d = s[1],
                        v = h(u, p, d);
                    Array.isArray(v) || (v = n.i(f.c)(p, d, v), v = n.i(c.a)(Math.ceil(p / v) * v, Math.floor(d / v) * v, v));
                    for (var y = v.length; v[0] <= p;) v.shift(), --y;
                    for (; v[y - 1] > d;) v.pop(), --y;
                    var _, g = new Array(y + 1);
                    for (r = 0; r <= y; ++r)(_ = g[r] = []).x0 = r > 0 ? v[r - 1] : p, _.x1 = r < y ? v[r] : d;
                    for (r = 0; r < a; ++r) p <= (o = u[r]) && o <= d && g[n.i(i.a)(v, o, 0, y)].push(t[r]);
                    return g
                }
                var e = u.a,
                    l = a.a,
                    h = s.a;
                return t.value = function(r) {
                    return arguments.length ? (e = "function" == typeof r ? r : n.i(o.a)(r), t) : e
                }, t.domain = function(e) {
                    return arguments.length ? (l = "function" == typeof e ? e : n.i(o.a)([e[0], e[1]]), t) : l
                }, t.thresholds = function(e) {
                    return arguments.length ? (h = "function" == typeof e ? e : Array.isArray(e) ? n.i(o.a)(r.b.call(e)) : n.i(o.a)(e), t) : h
                }, t
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return t
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n, r, i = t.length,
                    o = -1;
                if (null == e) {
                    for (; ++o < i;)
                        if (null != (n = t[o]) && n >= n)
                            for (r = n; ++o < i;) null != (n = t[o]) && n > r && (r = n)
                } else
                    for (; ++o < i;)
                        if (null != (n = e(t[o], o, t)) && n >= n)
                            for (r = n; ++o < i;) null != (n = e(t[o], o, t)) && n > r && (r = n); return r
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(15);
            e.a = function(t, e) {
                var i, o = t.length,
                    a = o,
                    u = -1,
                    c = 0;
                if (null == e)
                    for (; ++u < o;) isNaN(i = n.i(r.a)(t[u])) ? --a : c += i;
                else
                    for (; ++u < o;) isNaN(i = n.i(r.a)(e(t[u], u, t))) ? --a : c += i; if (a) return c / a
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(13),
                i = n(15),
                o = n(30);
            e.a = function(t, e) {
                var a, u = t.length,
                    c = -1,
                    f = [];
                if (null == e)
                    for (; ++c < u;) isNaN(a = n.i(i.a)(t[c])) || f.push(a);
                else
                    for (; ++c < u;) isNaN(a = n.i(i.a)(e(t[c], c, t))) || f.push(a);
                return n.i(o.a)(f.sort(r.a), .5)
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                for (var e, n, r, i = t.length, o = -1, a = 0; ++o < i;) a += t[o].length;
                for (n = new Array(a); --i >= 0;)
                    for (e = (r = t[i]).length; --e >= 0;) n[--a] = r[e];
                return n
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                for (var n = e.length, r = new Array(n); n--;) r[n] = t[e[n]];
                return r
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(13);
            e.a = function(t, e) {
                if (n = t.length) {
                    var n, i, o = 0,
                        a = 0,
                        u = t[a];
                    for (null == e && (e = r.a); ++o < n;)(e(i = t[o], u) < 0 || 0 !== e(u, u)) && (u = i, a = o);
                    return 0 === e(u, u) ? a : void 0
                }
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e, n) {
                for (var r, i, o = (null == n ? t.length : n) - (e = null == e ? 0 : +e); o;) i = Math.random() * o-- | 0, r = t[o + e], t[o + e] = t[i + e], t[i + e] = r;
                return t
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var n, r = t.length,
                    i = -1,
                    o = 0;
                if (null == e)
                    for (; ++i < r;)(n = +t[i]) && (o += n);
                else
                    for (; ++i < r;)(n = +e(t[i], i, t)) && (o += n);
                return o
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(67),
                i = n(13),
                o = n(15),
                a = n(30);
            e.a = function(t, e, u) {
                return t = r.a.call(t, o.a).sort(i.a), Math.ceil((u - e) / (2 * (n.i(a.a)(t, .75) - n.i(a.a)(t, .25)) * Math.pow(t.length, -1 / 3)))
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(70);
            e.a = function(t, e, i) {
                return Math.ceil((i - e) / (3.5 * n.i(r.a)(t) * Math.pow(t.length, -1 / 3)))
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(77);
            e.a = function() {
                return n.i(r.a)(arguments)
            }
        },
        function(t, e, n) {
            "use strict";
            n(174), n(175);
            var r = n(31);
            n.d(e, "a", function() {
                return r.a
            });
            n(173), n(176), n(172)
        },
        function(t, e, n) {
            "use strict"
        },
        function(t, e, n) {
            "use strict"
        },
        function(t, e, n) {
            "use strict";
            n(31)
        },
        function(t, e, n) {
            "use strict";

            function r() {}

            function i(t, e) {
                var n = new r;
                if (t instanceof r) t.each(function(t) {
                    n.add(t)
                });
                else if (t) {
                    var i = -1,
                        o = t.length;
                    if (null == e)
                        for (; ++i < o;) n.add(t[i]);
                    else
                        for (; ++i < o;) n.add(e(t[i], i, t))
                }
                return n
            }
            var o = n(31),
                a = o.a.prototype;
            r.prototype = i.prototype = {
                constructor: r,
                has: a.has,
                add: function(t) {
                    return t += "", this[o.b + t] = t, this
                },
                remove: a.remove,
                clear: a.clear,
                values: a.keys,
                size: a.size,
                empty: a.empty,
                each: a.each
            }
        },
        function(t, e, n) {
            "use strict"
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, r, o) {
                return 1 === arguments.length ? function(t) {
                    if (t instanceof i) return new i(t.h, t.s, t.l, t.opacity);
                    t instanceof a.a || (t = n.i(a.b)(t));
                    var e = t.r / 255,
                        r = t.g / 255,
                        o = t.b / 255,
                        d = (p * o + l * e - h * r) / (p + l - h),
                        v = o - d,
                        y = (s * (r - d) - c * v) / f,
                        _ = Math.sqrt(y * y + v * v) / (s * d * (1 - d)),
                        g = _ ? Math.atan2(y, v) * u.a - 120 : NaN;
                    return new i(g < 0 ? g + 360 : g, _, d, t.opacity)
                }(t) : new i(t, e, r, null == o ? 1 : o)
            }

            function i(t, e, n, r) {
                this.h = +t, this.s = +e, this.l = +n, this.opacity = +r
            }
            e.a = r;
            var o = n(33),
                a = n(32),
                u = n(79),
                c = -.29227,
                f = -.90649,
                s = 1.97294,
                l = s * f,
                h = 1.78277 * s,
                p = 1.78277 * c - -.14861 * f;
            n.i(o.a)(i, r, n.i(o.b)(a.c, {
                brighter: function(t) {
                    return t = null == t ? a.d : Math.pow(a.d, t), new i(this.h, this.s, this.l * t, this.opacity)
                },
                darker: function(t) {
                    return t = null == t ? a.e : Math.pow(a.e, t), new i(this.h, this.s, this.l * t, this.opacity)
                },
                rgb: function() {
                    var t = isNaN(this.h) ? 0 : (this.h + 120) * u.b,
                        e = +this.l,
                        n = isNaN(this.s) ? 0 : this.s * e * (1 - e),
                        r = Math.cos(t),
                        i = Math.sin(t);
                    return new a.a(255 * (e + n * (-.14861 * r + 1.78277 * i)), 255 * (e + n * (c * r + f * i)), 255 * (e + n * (s * r)), this.opacity)
                }
            }))
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                if (t instanceof o) return new o(t.l, t.a, t.b, t.opacity);
                if (t instanceof l) {
                    var e = t.h * d.b;
                    return new o(t.l, Math.cos(e) * t.c, Math.sin(e) * t.c, t.opacity)
                }
                t instanceof p.a || (t = n.i(p.b)(t));
                var r = f(t.r),
                    i = f(t.g),
                    u = f(t.b),
                    c = a((.4124564 * r + .3575761 * i + .1804375 * u) / v),
                    s = a((.2126729 * r + .7151522 * i + .072175 * u) / y);
                return new o(116 * s - 16, 500 * (c - s), 200 * (s - a((.0193339 * r + .119192 * i + .9503041 * u) / _)), t.opacity)
            }

            function i(t, e, n, i) {
                return 1 === arguments.length ? r(t) : new o(t, e, n, null == i ? 1 : i)
            }

            function o(t, e, n, r) {
                this.l = +t, this.a = +e, this.b = +n, this.opacity = +r
            }

            function a(t) {
                return t > w ? Math.pow(t, 1 / 3) : t / m + g
            }

            function u(t) {
                return t > b ? t * t * t : m * (t - g)
            }

            function c(t) {
                return 255 * (t <= .0031308 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - .055)
            }

            function f(t) {
                return (t /= 255) <= .04045 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4)
            }

            function s(t, e, n, i) {
                return 1 === arguments.length ? function(t) {
                    if (t instanceof l) return new l(t.h, t.c, t.l, t.opacity);
                    t instanceof o || (t = r(t));
                    var e = Math.atan2(t.b, t.a) * d.a;
                    return new l(e < 0 ? e + 360 : e, Math.sqrt(t.a * t.a + t.b * t.b), t.l, t.opacity)
                }(t) : new l(t, e, n, null == i ? 1 : i)
            }

            function l(t, e, n, r) {
                this.h = +t, this.c = +e, this.l = +n, this.opacity = +r
            }
            e.b = i, e.a = s;
            var h = n(33),
                p = n(32),
                d = n(79),
                v = .95047,
                y = 1,
                _ = 1.08883,
                g = 4 / 29,
                b = 6 / 29,
                m = 3 * b * b,
                w = b * b * b;
            n.i(h.a)(o, i, n.i(h.b)(p.c, {
                brighter: function(t) {
                    return new o(this.l + 18 * (null == t ? 1 : t), this.a, this.b, this.opacity)
                },
                darker: function(t) {
                    return new o(this.l - 18 * (null == t ? 1 : t), this.a, this.b, this.opacity)
                },
                rgb: function() {
                    var t = (this.l + 16) / 116,
                        e = isNaN(this.a) ? t : t + this.a / 500,
                        n = isNaN(this.b) ? t : t - this.b / 200;
                    return t = y * u(t), e = v * u(e), n = _ * u(n), new p.a(c(3.2404542 * e - 1.5371385 * t - .4985314 * n), c(-.969266 * e + 1.8760108 * t + .041556 * n), c(.0556434 * e - .2040259 * t + 1.0572252 * n), this.opacity)
                }
            })), n.i(h.a)(l, s, n.i(h.b)(p.c, {
                brighter: function(t) {
                    return new l(this.h, this.c, this.l + 18 * (null == t ? 1 : t), this.opacity)
                },
                darker: function(t) {
                    return new l(this.h, this.c, this.l - 18 * (null == t ? 1 : t), this.opacity)
                },
                rgb: function() {
                    return r(this).rgb()
                }
            }))
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                for (var e = 0, n = t.length, r = t[n - 1][1] * t[0][0] - t[n - 1][0] * t[0][1]; ++e < n;) r += t[e - 1][1] * t[e][0] - t[e - 1][0] * t[e][1];
                return r
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return t - e
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e, n) {
                for (var r = t.width, i = t.height, o = 1 + (n << 1), a = 0; a < i; ++a)
                    for (var u = 0, c = 0; u < r + n; ++u) u < r && (c += t.data[u + a * r]), u >= n && (u >= o && (c -= t.data[u - o + a * r]), e.data[u - n + a * r] = c / Math.min(u + 1, r - 1 + o - u, o))
            }, e.b = function(t, e, n) {
                for (var r = t.width, i = t.height, o = 1 + (n << 1), a = 0; a < r; ++a)
                    for (var u = 0, c = 0; u < i + n; ++u) u < i && (c += t.data[a + u * r]), u >= n && (u >= o && (c -= t.data[a + (u - o) * r]), e.data[a + (u - n) * r] = c / Math.min(u + 1, i - 1 + o - u, o))
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                for (var n = e[0], r = e[1], i = -1, o = 0, a = t.length, u = a - 1; o < a; u = o++) {
                    var c = t[o],
                        f = c[0],
                        s = c[1],
                        l = t[u],
                        h = l[0],
                        p = l[1];
                    if (function(t, e, n) {
                        var r;
                        return function(t, e, n) {
                            return (e[0] - t[0]) * (n[1] - t[1]) == (n[0] - t[0]) * (e[1] - t[1])
                        }(t, e, n) && function(t, e, n) {
                            return t <= e && e <= n || n <= e && e <= t
                        }(t[r = +(t[0] === e[0])], n[r], e[r])
                    }(c, l, e)) return 0;
                    s > r != p > r && n < (h - f) * (r - s) / (p - s) + f && (i = -i)
                }
                return i
            }
            e.a = function(t, e) {
                for (var n, i = -1, o = e.length; ++i < o;)
                    if (n = r(t, e[i])) return n;
                return 0
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return t[0]
            }

            function i(t) {
                return t[1]
            }

            function o() {
                return 1
            }
            var a = n(3),
                u = n(80),
                c = n(181),
                f = n(81),
                s = n(82);
            e.a = function() {
                function t(t) {
                    var r = new Float32Array(x * M),
                        i = new Float32Array(x * M);
                    t.forEach(function(t, e, n) {
                        var i = +v(t, e, n) + O >> w,
                            o = +y(t, e, n) + O >> w,
                            a = +_(t, e, n);
                        i >= 0 && i < x && o >= 0 && o < M && (r[i + o * x] += a)
                    }), n.i(c.a)({
                        width: x,
                        height: M,
                        data: r
                    }, {
                        width: x,
                        height: M,
                        data: i
                    }, m >> w), n.i(c.b)({
                        width: x,
                        height: M,
                        data: i
                    }, {
                        width: x,
                        height: M,
                        data: r
                    }, m >> w), n.i(c.a)({
                        width: x,
                        height: M,
                        data: r
                    }, {
                        width: x,
                        height: M,
                        data: i
                    }, m >> w), n.i(c.b)({
                        width: x,
                        height: M,
                        data: i
                    }, {
                        width: x,
                        height: M,
                        data: r
                    }, m >> w), n.i(c.a)({
                        width: x,
                        height: M,
                        data: r
                    }, {
                        width: x,
                        height: M,
                        data: i
                    }, m >> w), n.i(c.b)({
                        width: x,
                        height: M,
                        data: i
                    }, {
                        width: x,
                        height: M,
                        data: r
                    }, m >> w);
                    var o = j(r);
                    if (!Array.isArray(o)) {
                        var u = n.i(a.max)(r);
                        o = n.i(a.tickStep)(0, u, o), (o = n.i(a.range)(0, Math.floor(u / o) * o, o)).shift()
                    }
                    return n.i(s.a)().thresholds(o).size([x, M])(r).map(e)
                }

                function e(t) {
                    return t.value *= Math.pow(2, -2 * w), t.coordinates.forEach(l), t
                }

                function l(t) {
                    t.forEach(h)
                }

                function h(t) {
                    t.forEach(p)
                }

                function p(t) {
                    t[0] = t[0] * Math.pow(2, w) - O, t[1] = t[1] * Math.pow(2, w) - O
                }

                function d() {
                    return O = 3 * m, x = g + 2 * O >> w, M = b + 2 * O >> w, t
                }
                var v = r,
                    y = i,
                    _ = o,
                    g = 960,
                    b = 500,
                    m = 20,
                    w = 2,
                    O = 3 * m,
                    x = g + 2 * O >> w,
                    M = b + 2 * O >> w,
                    j = n.i(f.a)(20);
                return t.x = function(e) {
                    return arguments.length ? (v = "function" == typeof e ? e : n.i(f.a)(+e), t) : v
                }, t.y = function(e) {
                    return arguments.length ? (y = "function" == typeof e ? e : n.i(f.a)(+e), t) : y
                }, t.weight = function(e) {
                    return arguments.length ? (_ = "function" == typeof e ? e : n.i(f.a)(+e), t) : _
                }, t.size = function(t) {
                    if (!arguments.length) return [g, b];
                    var e = Math.ceil(t[0]),
                        n = Math.ceil(t[1]);
                    if (!(e >= 0 || e >= 0)) throw new Error("invalid size");
                    return g = e, b = n, d()
                }, t.cellSize = function(t) {
                    if (!arguments.length) return 1 << w;
                    if (!((t = +t) >= 1)) throw new Error("invalid cell size");
                    return w = Math.floor(Math.log(t) / Math.LN2), d()
                }, t.thresholds = function(e) {
                    return arguments.length ? (j = "function" == typeof e ? e : Array.isArray(e) ? n.i(f.a)(u.a.call(e)) : n.i(f.a)(e), t) : j
                }, t.bandwidth = function(t) {
                    if (!arguments.length) return Math.sqrt(m * (m + 1));
                    if (!((t = +t) >= 0)) throw new Error("invalid bandwidth");
                    return m = Math.round((Math.sqrt(4 * t * t + 1) - 1) / 2), d()
                }, t
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(82);
            n.d(e, "contours", function() {
                return r.a
            });
            var i = n(183);
            n.d(e, "contourDensity", function() {
                return i.a
            })
        },
        function(t, e, n) {
            "use strict";
            e.a = function() {}
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return o
            }), n.d(e, "b", function() {
                return a
            }), n.d(e, "c", function() {
                return u
            }), n.d(e, "d", function() {
                return c
            });
            var r = n(34),
                i = n.i(r.a)(","),
                o = i.parse,
                a = i.parseRows,
                u = i.format,
                c = i.formatRows
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(34);
            n.d(e, "dsvFormat", function() {
                return r.a
            });
            var i = n(186);
            n.d(e, "csvParse", function() {
                return i.a
            }), n.d(e, "csvParseRows", function() {
                return i.b
            }), n.d(e, "csvFormat", function() {
                return i.c
            }), n.d(e, "csvFormatRows", function() {
                return i.d
            });
            var o = n(188);
            n.d(e, "tsvParse", function() {
                return o.a
            }), n.d(e, "tsvParseRows", function() {
                return o.b
            }), n.d(e, "tsvFormat", function() {
                return o.c
            }), n.d(e, "tsvFormatRows", function() {
                return o.d
            })
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return o
            }), n.d(e, "b", function() {
                return a
            }), n.d(e, "c", function() {
                return u
            }), n.d(e, "d", function() {
                return c
            });
            var r = n(34),
                i = n.i(r.a)("\t"),
                o = i.parse,
                a = i.parseRows,
                u = i.format,
                c = i.formatRows
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return i
            }), n.d(e, "b", function() {
                return o
            });
            var r, i, o, a = n(87);
            ! function(t) {
                r = n.i(a.a)(t), i = r.format, o = r.formatPrefix
            }({
                decimal: ".",
                thousands: ",",
                grouping: [3],
                currency: ["$", ""]
            })
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                t: for (var n, r = (t = t.toPrecision(e)).length, i = 1, o = -1; i < r; ++i) switch (t[i]) {
                    case ".":
                        o = n = i;
                        break;
                    case "0":
                        0 === o && (o = i), n = i;
                        break;
                    case "e":
                        break t;
                    default:
                        o > 0 && (o = 0)
                }
                return o > 0 ? t.slice(0, o) + t.slice(n + 1) : t
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return function(n, r) {
                    for (var i = n.length, o = [], a = 0, u = t[0], c = 0; i > 0 && u > 0 && (c + u + 1 > r && (u = Math.max(1, r - c)), o.push(n.substring(i -= u, i + u)), !((c += u + 1) > r));) u = t[a = (a + 1) % t.length];
                    return o.reverse().join(e)
                }
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return function(e) {
                    return e.replace(/[0-9]/g, function(e) {
                        return t[+e]
                    })
                }
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(35);
            e.a = function(t, e) {
                var i = n.i(r.a)(t, e);
                if (!i) return t + "";
                var o = i[0],
                    a = i[1];
                return a < 0 ? "0." + new Array(-a).join("0") + o : o.length > a + 1 ? o.slice(0, a + 1) + "." + o.slice(a + 1) : o + new Array(a - o.length + 2).join("0")
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return t
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(19);
            e.a = function(t) {
                return Math.max(0, -n.i(r.a)(Math.abs(t)))
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(19);
            e.a = function(t, e) {
                return Math.max(0, 3 * Math.max(-8, Math.min(8, Math.floor(n.i(r.a)(e) / 3))) - n.i(r.a)(Math.abs(t)))
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(19);
            e.a = function(t, e) {
                return t = Math.abs(t), e = Math.abs(e) - t, Math.max(0, n.i(r.a)(e) - n.i(r.a)(t)) + 1
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return function e(r) {
                    function a(e, a) {
                        var u = t((e = n.i(i.a)(e)).h, (a = n.i(i.a)(a)).h),
                            c = n.i(o.a)(e.s, a.s),
                            f = n.i(o.a)(e.l, a.l),
                            s = n.i(o.a)(e.opacity, a.opacity);
                        return function(t) {
                            return e.h = u(t), e.s = c(t), e.l = f(Math.pow(t, r)), e.opacity = s(t), e + ""
                        }
                    }
                    return r = +r, a.gamma = e, a
                }(1)
            }
            n.d(e, "a", function() {
                return a
            });
            var i = n(9),
                o = n(16);
            e.b = r(o.b);
            var a = r(o.a)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return function(e, r) {
                    var a = t((e = n.i(i.b)(e)).h, (r = n.i(i.b)(r)).h),
                        u = n.i(o.a)(e.c, r.c),
                        c = n.i(o.a)(e.l, r.l),
                        f = n.i(o.a)(e.opacity, r.opacity);
                    return function(t) {
                        return e.h = a(t), e.c = u(t), e.l = c(t), e.opacity = f(t), e + ""
                    }
                }
            }
            n.d(e, "b", function() {
                return a
            });
            var i = n(9),
                o = n(16);
            e.a = r(o.b);
            var a = r(o.a)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return function(e, r) {
                    var a = t((e = n.i(i.d)(e)).h, (r = n.i(i.d)(r)).h),
                        u = n.i(o.a)(e.s, r.s),
                        c = n.i(o.a)(e.l, r.l),
                        f = n.i(o.a)(e.opacity, r.opacity);
                    return function(t) {
                        return e.h = a(t), e.s = u(t), e.l = c(t), e.opacity = f(t), e + ""
                    }
                }
            }
            n.d(e, "b", function() {
                return a
            });
            var i = n(9),
                o = n(16);
            e.a = r(o.b);
            var a = r(o.a)
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                var o = n.i(i.a)((t = n.i(r.c)(t)).l, (e = n.i(r.c)(e)).l),
                    a = n.i(i.a)(t.a, e.a),
                    u = n.i(i.a)(t.b, e.b),
                    c = n.i(i.a)(t.opacity, e.opacity);
                return function(e) {
                    return t.l = o(e), t.a = a(e), t.b = u(e), t.opacity = c(e), t + ""
                }
            };
            var r = n(9),
                i = n(16)
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                for (var n = new Array(e), r = 0; r < e; ++r) n[r] = t(r / (e - 1));
                return n
            }
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t, e) {
                return t = +t, e -= t,
                    function(n) {
                        return Math.round(t + e * n)
                    }
            }
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "a", function() {
                return i
            });
            var r = 180 / Math.PI,
                i = {
                    translateX: 0,
                    translateY: 0,
                    rotate: 0,
                    skewX: 0,
                    scaleX: 1,
                    scaleY: 1
                };
            e.b = function(t, e, n, i, o, a) {
                var u, c, f;
                return (u = Math.sqrt(t * t + e * e)) && (t /= u, e /= u), (f = t * n + e * i) && (n -= t * f, i -= e * f), (c = Math.sqrt(n * n + i * i)) && (n /= c, i /= c, f /= c), t * i < e * n && (t = -t, e = -e, f = -f, u = -u), {
                    translateX: o,
                    translateY: a,
                    rotate: Math.atan2(e, t) * r,
                    skewX: Math.atan(f) * r,
                    scaleX: u,
                    scaleY: c
                }
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t, e, r, o) {
                function a(t) {
                    return t.length ? t.pop() + " " : ""
                }
                return function(u, c) {
                    var f = [],
                        s = [];
                    return u = t(u), c = t(c),
                        function(t, o, a, u, c, f) {
                            if (t !== a || o !== u) {
                                var s = c.push("translate(", null, e, null, r);
                                f.push({
                                    i: s - 4,
                                    x: n.i(i.a)(t, a)
                                }, {
                                    i: s - 2,
                                    x: n.i(i.a)(o, u)
                                })
                            } else(a || u) && c.push("translate(" + a + e + u + r)
                        }(u.translateX, u.translateY, c.translateX, c.translateY, f, s),
                        function(t, e, r, u) {
                            t !== e ? (t - e > 180 ? e += 360 : e - t > 180 && (t += 360), u.push({
                                i: r.push(a(r) + "rotate(", null, o) - 2,
                                x: n.i(i.a)(t, e)
                            })) : e && r.push(a(r) + "rotate(" + e + o)
                        }(u.rotate, c.rotate, f, s),
                        function(t, e, r, u) {
                            t !== e ? u.push({
                                i: r.push(a(r) + "skewX(", null, o) - 2,
                                x: n.i(i.a)(t, e)
                            }) : e && r.push(a(r) + "skewX(" + e + o)
                        }(u.skewX, c.skewX, f, s),
                        function(t, e, r, o, u, c) {
                            if (t !== r || e !== o) {
                                var f = u.push(a(u) + "scale(", null, ",", null, ")");
                                c.push({
                                    i: f - 4,
                                    x: n.i(i.a)(t, r)
                                }, {
                                    i: f - 2,
                                    x: n.i(i.a)(e, o)
                                })
                            } else 1 === r && 1 === o || u.push(a(u) + "scale(" + r + "," + o + ")")
                        }(u.scaleX, u.scaleY, c.scaleX, c.scaleY, f, s), u = c = null,
                        function(t) {
                            for (var e, n = -1, r = s.length; ++n < r;) f[(e = s[n]).i] = e.x(t);
                            return f.join("")
                        }
                }
            }
            n.d(e, "a", function() {
                return a
            }), n.d(e, "b", function() {
                return u
            });
            var i = n(20),
                o = n(206),
                a = r(o.a, "px, ", "px)", "deg)"),
                u = r(o.b, ", ", ")", ")")
        },
        function(t, e, n) {
            "use strict";
            e.a = function(t) {
                return "none" === t ? u.a : (r || (r = document.createElement("DIV"), i = document.documentElement, o = document.defaultView), r.style.transform = t, t = o.getComputedStyle(i.appendChild(r), null).getPropertyValue("transform"), i.removeChild(r), t = t.slice(7, -1).split(","), n.i(u.b)(+t[0], +t[1], +t[2], +t[3], +t[4], +t[5]))
            }, e.b = function(t) {
                return null == t ? u.a : (a || (a = document.createElementNS("http://www.w3.org/2000/svg", "g")), a.setAttribute("transform", t), (t = a.transform.baseVal.consolidate()) ? (t = t.matrix, n.i(u.b)(t.a, t.b, t.c, t.d, t.e, t.f)) : u.a)
            };
            var r, i, o, a, u = n(204)
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return ((t = Math.exp(t)) + 1 / t) / 2
            }
            var i = Math.SQRT2;
            e.a = function(t, e) {
                var n, o, a = t[0],
                    u = t[1],
                    c = t[2],
                    f = e[0],
                    s = e[1],
                    l = e[2],
                    h = f - a,
                    p = s - u,
                    d = h * h + p * p;
                if (d < 1e-12) o = Math.log(l / c) / i, n = function(t) {
                    return [a + t * h, u + t * p, c * Math.exp(i * t * o)]
                };
                else {
                    var v = Math.sqrt(d),
                        y = (l * l - c * c + 4 * d) / (2 * c * 2 * v),
                        _ = (l * l - c * c - 4 * d) / (2 * l * 2 * v),
                        g = Math.log(Math.sqrt(y * y + 1) - y),
                        b = Math.log(Math.sqrt(_ * _ + 1) - _);
                    o = (b - g) / i, n = function(t) {
                        var e = t * o,
                            n = r(g),
                            f = c / (2 * v) * (n * function(t) {
                                return ((t = Math.exp(2 * t)) - 1) / (t + 1)
                            }(i * e + g) - function(t) {
                                return ((t = Math.exp(t)) - 1 / t) / 2
                            }(g));
                        return [a + f * h, u + f * p, c * n / r(i * e + g)]
                    }
                }
                return n.duration = 1e3 * o, n
            }
        },
        function(t, e, n) {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var r = n(209);
            n.d(e, "scaleBand", function() {
                return r.a
            }), n.d(e, "scalePoint", function() {
                return r.b
            });
            var i = n(215);
            n.d(e, "scaleIdentity", function() {
                return i.a
            });
            var o = n(18);
            n.d(e, "scaleLinear", function() {
                return o.a
            });
            var a = n(216);
            n.d(e, "scaleLog", function() {
                return a.a
            });
            var u = n(97);
            n.d(e, "scaleOrdinal", function() {
                return u.a
            }), n.d(e, "scaleImplicit", function() {
                return u.b
            });
            var c = n(217);
            n.d(e, "scalePow", function() {
                return c.a
            }), n.d(e, "scaleSqrt", function() {
                return c.b
            });
            var f = n(218);
            n.d(e, "scaleQuantile", function() {
                return f.a
            });
            var s = n(219);
            n.d(e, "scaleQuantize", function() {
                return s.a
            });
            var l = n(222);
            n.d(e, "scaleThreshold", function() {
                return l.a
            });
            var h = n(98);
            n.d(e, "scaleTime", function() {
                return h.a
            });
            var p = n(224);
            n.d(e, "scaleUtc", function() {
                return p.a
            });
            var d = n(210);
            n.d(e, "schemeCategory10", function() {
                return d.a
            });
            var v = n(212);
            n.d(e, "schemeCategory20b", function() {
                return v.a
            });
            var y = n(213);
            n.d(e, "schemeCategory20c", function() {
                return y.a
            });
            var _ = n(211);
            n.d(e, "schemeCategory20", function() {
                return _.a
            });
            var g = n(214);
            n.d(e, "interpolateCubehelixDefault", function() {
                return g.a
            });
            var b = n(220);
            n.d(e, "interpolateRainbow", function() {
                return b.a
            }), n.d(e, "interpolateWarm", function() {
                return b.b
            }), n.d(e, "interpolateCool", function() {
                return b.c
            });
            var m = n(225);
            n.d(e, "interpolateViridis", function() {
                return m.a
            }), n.d(e, "interpolateMagma", function() {
                return m.b
            }), n.d(e, "interpolateInferno", function() {
                return m.c
            }), n.d(e, "interpolatePlasma", function() {
                return m.d
            });
            var w = n(221);
            n.d(e, "scaleSequential", function() {
                return w.a
            })
        },
        function(t, e, n) {
            "use strict";

            function r() {
                function t() {
                    var t = c().length,
                        r = s[1] < s[0],
                        a = s[r - 0],
                        u = s[1 - r];
                    e = (u - a) / Math.max(1, t - h + 2 * p), l && (e = Math.floor(e)), a += (u - a - e * (t - h)) * d, i = e * (1 - h), l && (a = Math.round(a), i = Math.round(i));
                    var v = n.i(o.range)(t).map(function(t) {
                        return a + e * t
                    });
                    return f(r ? v.reverse() : v)
                }
                var e, i, u = n.i(a.a)().unknown(void 0),
                    c = u.domain,
                    f = u.range,
                    s = [0, 1],
                    l = !1,
                    h = 0,
                    p = 0,
                    d = .5;
                return delete u.unknown, u.domain = function(e) {
                    return arguments.length ? (c(e), t()) : c()
                }, u.range = function(e) {
                    return arguments.length ? (s = [+e[0], +e[1]], t()) : s.slice()
                }, u.rangeRound = function(e) {
                    return s = [+e[0], +e[1]], l = !0, t()
                }, u.bandwidth = function() {
                    return i
                }, u.step = function() {
                    return e
                }, u.round = function(e) {
                    return arguments.length ? (l = !!e, t()) : l
                }, u.padding = function(e) {
                    return arguments.length ? (h = p = Math.max(0, Math.min(1, e)), t()) : h
                }, u.paddingInner = function(e) {
                    return arguments.length ? (h = Math.max(0, Math.min(1, e)), t()) : h
                }, u.paddingOuter = function(e) {
                    return arguments.length ? (p = Math.max(0, Math.min(1, e)), t()) : p
                }, u.align = function(e) {
                    return arguments.length ? (d = Math.max(0, Math.min(1, e)), t()) : d
                }, u.copy = function() {
                    return r().domain(c()).range(s).round(l).paddingInner(h).paddingOuter(p).align(d)
                }, t()
            }

            function i(t) {
                var e = t.copy;
                return t.padding = t.paddingOuter, delete t.paddingInner, delete t.paddingOuter, t.copy = function() {
                    return i(e())
                }, t
            }
            e.a = r, e.b = function() {
                return i(r().paddingInner(1))
            };
            var o = n(3),
                a = n(97)
        },
        function(t, e, n) {
            "use strict";
            var r = n(17);
            e.a = n.i(r.a)("1f77b4ff7f0e2ca02cd627289467bd8c564be377c27f7f7fbcbd2217becf")
        },
        function(t, e, n) {
            "use strict";
            var r = n(17);
            e.a = n.i(r.a)("1f77b4aec7e8ff7f0effbb782ca02c98df8ad62728ff98969467bdc5b0d58c564bc49c94e377c2f7b6d27f7f7fc7c7c7bcbd22dbdb8d17becf9edae5")
        },
        function(t, e, n) {
            "use strict";
            var r = n(17);
            e.a = n.i(r.a)("393b795254a36b6ecf9c9ede6379398ca252b5cf6bcedb9c8c6d31bd9e39e7ba52e7cb94843c39ad494ad6616be7969c7b4173a55194ce6dbdde9ed6")
        },
        function(t, e, n) {
            "use strict";
            var r = n(17);
            e.a = n.i(r.a)("3182bd6baed69ecae1c6dbefe6550dfd8d3cfdae6bfdd0a231a35474c476a1d99bc7e9c0756bb19e9ac8bcbddcdadaeb636363969696bdbdbdd9d9d9")
        },
        function(t, e, n) {
            "use strict";
            var r = n(9),
                i = n(14);
            e.a = n.i(i.interpolateCubehelixLong)(n.i(r.a)(300, .5, 0), n.i(r.a)(-240, .5, 1))
        },
        function(t, e, n) {
            "use strict";

            function r() {
                function t(t) {
                    return +t
                }
                var e = [0, 1];
                return t.invert = t, t.domain = t.range = function(n) {
                    return arguments.length ? (e = i.a.call(n, a.a), t) : e.slice()
                }, t.copy = function() {
                    return r().domain(e)
                }, n.i(o.b)(t)
            }
            e.a = r;
            var i = n(11),
                o = n(18),
                a = n(96)
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return (e = Math.log(e / t)) ? function(n) {
                    return Math.log(n / t) / e
                } : n.i(h.a)(e)
            }

            function i(t, e) {
                return t < 0 ? function(n) {
                    return -Math.pow(-e, n) * Math.pow(-t, 1 - n)
                } : function(n) {
                    return Math.pow(e, n) * Math.pow(t, 1 - n)
                }
            }

            function o(t) {
                return isFinite(t) ? +("1e" + t) : t < 0 ? 0 : t
            }

            function a(t) {
                return 10 === t ? o : t === Math.E ? Math.exp : function(e) {
                    return Math.pow(t, e)
                }
            }

            function u(t) {
                return t === Math.E ? Math.log : 10 === t && Math.log10 || 2 === t && Math.log2 || (t = Math.log(t), function(e) {
                    return Math.log(e) / t
                })
            }

            function c(t) {
                return function(e) {
                    return -t(-e)
                }
            }

            function f() {
                function t() {
                    return v = u(h), y = a(h), o()[0] < 0 && (v = c(v), y = c(y)), e
                }
                var e = n.i(d.a)(r, i).domain([1, 10]),
                    o = e.domain,
                    h = 10,
                    v = u(10),
                    y = a(10);
                return e.base = function(e) {
                    return arguments.length ? (h = +e, t()) : h
                }, e.domain = function(e) {
                    return arguments.length ? (o(e), t()) : o()
                }, e.ticks = function(t) {
                    var e, r = o(),
                        i = r[0],
                        a = r[r.length - 1];
                    (e = a < i) && (l = i, i = a, a = l);
                    var u, c, f, l = v(i),
                        p = v(a),
                        d = null == t ? 10 : +t,
                        _ = [];
                    if (!(h % 1) && p - l < d) {
                        if (l = Math.round(l) - 1, p = Math.round(p) + 1, i > 0) {
                            for (; l < p; ++l)
                                for (c = 1, u = y(l); c < h; ++c)
                                    if (!((f = u * c) < i)) {
                                        if (f > a) break;
                                        _.push(f)
                                    }
                        } else
                            for (; l < p; ++l)
                                for (c = h - 1, u = y(l); c >= 1; --c)
                                    if (!((f = u * c) < i)) {
                                        if (f > a) break;
                                        _.push(f)
                                    }
                    } else _ = n.i(s.ticks)(l, p, Math.min(p - l, d)).map(y);
                    return e ? _.reverse() : _
                }, e.tickFormat = function(t, r) {
                    if (null == r && (r = 10 === h ? ".0e" : ","), "function" != typeof r && (r = n.i(l.f)(r)), t === 1 / 0) return r;
                    null == t && (t = 10);
                    var i = Math.max(1, h * t / e.ticks().length);
                    return function(t) {
                        var e = t / y(Math.round(v(t)));
                        return e * h < h - .5 && (e *= h), e <= i ? r(t) : ""
                    }
                }, e.nice = function() {
                    return o(n.i(p.a)(o(), {
                        floor: function(t) {
                            return y(Math.floor(v(t)))
                        },
                        ceil: function(t) {
                            return y(Math.ceil(v(t)))
                        }
                    }))
                }, e.copy = function() {
                    return n.i(d.c)(e, f().base(h))
                }, e
            }
            e.a = f;
            var s = n(3),
                l = n(83),
                h = n(38),
                p = n(95),
                d = n(21)
        },
        function(t, e, n) {
            "use strict";

            function r(t, e) {
                return t < 0 ? -Math.pow(-t, e) : Math.pow(t, e)
            }

            function i() {
                var t = 1,
                    e = n.i(u.a)(function(e, i) {
                        return (i = r(i, t) - (e = r(e, t))) ? function(n) {
                            return (r(n, t) - e) / i
                        } : n.i(o.a)(i)
                    }, function(e, n) {
                        return n = r(n, t) - (e = r(e, t)),
                            function(i) {
                                return r(e + n * i, 1 / t)
                            }
                    }),
                    c = e.domain;
                return e.exponent = function(e) {
                    return arguments.length ? (t = +e, c(c())) : t
                }, e.copy = function() {
                    return n.i(u.c)(e, i().exponent(t))
                }, n.i(a.b)(e)
            }
            e.a = i, e.b = function() {
                return i().exponent(.5)
            };
            var o = n(38),
                a = n(18),
                u = n(21)
        },
        function(t, e, n) {
            "use strict";

            function r() {
                function t() {
                    var t = 0,
                        r = Math.max(1, u.length);
                    for (c = new Array(r - 1); ++t < r;) c[t - 1] = n.i(i.quantile)(a, t / r);
                    return e
                }

                function e(t) {
                    if (!isNaN(t = +t)) return u[n.i(i.bisect)(c, t)]
                }
                var a = [],
                    u = [],
                    c = [];
                return e.invertExtent = function(t) {
                    var e = u.indexOf(t);
                    return e < 0 ? [NaN, NaN] : [e > 0 ? c[e - 1] : a[0], e < c.length ? c[e] : a[a.length - 1]]
                }, e.domain = function(e) {
                    if (!arguments.length) return a.slice();
                    a = [];
                    for (var n, r = 0, o = e.length; r < o; ++r) null == (n = e[r]) || isNaN(n = +n) || a.push(n);
                    return a.sort(i.ascending), t()
                }, e.range = function(e) {
                    return arguments.length ? (u = o.b.call(e), t()) : u.slice()
                }, e.quantiles = function() {
                    return c.slice()
                }, e.copy = function() {
                    return r().domain(a).range(u)
                }, e
            }
            e.a = r;
            var i = n(3),
                o = n(11)
        },
        function(t, e, n) {
            "use strict";

            function r() {
                function t(t) {
                    if (t <= t) return l[n.i(i.bisect)(s, t, 0, f)]
                }

                function e() {
                    var e = -1;
                    for (s = new Array(f); ++e < f;) s[e] = ((e + 1) * c - (e - f) * u) / (f + 1);
                    return t
                }
                var u = 0,
                    c = 1,
                    f = 1,
                    s = [.5],
                    l = [0, 1];
                return t.domain = function(t) {
                    return arguments.length ? (u = +t[0], c = +t[1], e()) : [u, c]
                }, t.range = function(t) {
                    return arguments.length ? (f = (l = o.b.call(t)).length - 1, e()) : l.slice()
                }, t.invertExtent = function(t) {
                    var e = l.indexOf(t);
                    return e < 0 ? [NaN, NaN] : e < 1 ? [u, s[0]] : e >= f ? [s[f - 1], c] : [s[e - 1], s[e]]
                }, t.copy = function() {
                    return r().domain([u, c]).range(l)
                }, n.i(a.b)(t)
            }
            e.a = r;
            var i = n(3),
                o = n(11),
                a = n(18)
        },
        function(t, e, n) {
            "use strict";
            n.d(e, "b", function() {
                return o
            }), n.d(e, "c", function() {
                return a
            });
            var r = n(9),
                i = n(14),
                o = n.i(i.interpolateCubehelixLong)(n.i(r.a)(-100, .75, .35), n.i(r.a)(80, 1.5, .8)),
                a = n.i(i.interpolateCubehelixLong)(n.i(r.a)(260, .75, .35), n.i(r.a)(80, 1.5, .8)),
                u = n.i(r.a)();
            e.a = function(t) {
                (t < 0 || t > 1) && (t -= Math.floor(t));
                var e = Math.abs(t - .5);
                return u.h = 360 * t - 100, u.s = 1.5 - 1.5 * e, u.l = .8 - .9 * e, u + ""
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                function e(e) {
                    var n = (e - o) / (a - o);
                    return t(u ? Math.max(0, Math.min(1, n)) : n)
                }
                var o = 0,
                    a = 1,
                    u = !1;
                return e.domain = function(t) {
                    return arguments.length ? (o = +t[0], a = +t[1], e) : [o, a]
                }, e.clamp = function(t) {
                    return arguments.length ? (u = !!t, e) : u
                }, e.interpolator = function(n) {
                    return arguments.length ? (t = n, e) : t
                }, e.copy = function() {
                    return r(t).domain([o, a]).clamp(u)
                }, n.i(i.b)(e)
            }
            e.a = r;
            var i = n(18)
        },
        function(t, e, n) {
            "use strict";

            function r() {
                function t(t) {
                    if (t <= t) return a[n.i(i.bisect)(e, t, 0, u)]
                }
                var e = [.5],
                    a = [0, 1],
                    u = 1;
                return t.domain = function(n) {
                    return arguments.length ? (e = o.b.call(n), u = Math.min(e.length, a.length - 1), t) : e.slice()
                }, t.range = function(n) {
                    return arguments.length ? (a = o.b.call(n), u = Math.min(e.length, a.length - 1), t) : a.slice()
                }, t.invertExtent = function(t) {
                    var n = a.indexOf(t);
                    return [e[n - 1], e[n]]
                }, t.copy = function() {
                    return r().domain(e).range(a)
                }, t
            }
            e.a = r;
            var i = n(3),
                o = n(11)
        },
        function(t, e, n) {
            "use strict";
            var r = n(3),
                i = n(83);
            e.a = function(t, e, o) {
                var a, u = t[0],
                    c = t[t.length - 1],
                    f = n.i(r.tickStep)(u, c, null == e ? 10 : e);
                switch ((o = n.i(i.a)(null == o ? ",f" : o)).type) {
                    case "s":
                        var s = Math.max(Math.abs(u), Math.abs(c));
                        return null != o.precision || isNaN(a = n.i(i.b)(f, s)) || (o.precision = a), n.i(i.c)(o, s);
                    case "":
                    case "e":
                    case "g":
                    case "p":
                    case "r":
                        null != o.precision || isNaN(a = n.i(i.d)(f, Math.max(Math.abs(u), Math.abs(c)))) || (o.precision = a - ("e" === o.type));
                        break;
                    case "f":
                    case "%":
                        null != o.precision || isNaN(a = n.i(i.e)(f)) || (o.precision = a - 2 * ("%" === o.type))
                }
                return n.i(i.f)(o)
            }
        },
        function(t, e, n) {
            "use strict";
            var r = n(98),
                i = n(99),
                o = n(40);
            e.a = function() {
                return n.i(r.b)(o.a, o.b, o.c, o.d, o.e, o.f, o.g, o.h, i.a).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)])
            }
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                var e = t.length;
                return function(n) {
                    return t[Math.max(0, Math.min(e - 1, Math.floor(n * e)))]
                }
            }
            n.d(e, "b", function() {
                return o
            }), n.d(e, "c", function() {
                return a
            }), n.d(e, "d", function() {
                return u
            });
            var i = n(17);
            e.a = r(n.i(i.a)("44015444025645045745055946075a46085c460a5d460b5e470d60470e6147106347116447136548146748166848176948186a481a6c481b6d481c6e481d6f481f70482071482173482374482475482576482677482878482979472a7a472c7a472d7b472e7c472f7d46307e46327e46337f463480453581453781453882443983443a83443b84433d84433e85423f854240864241864142874144874045884046883f47883f48893e49893e4a893e4c8a3d4d8a3d4e8a3c4f8a3c508b3b518b3b528b3a538b3a548c39558c39568c38588c38598c375a8c375b8d365c8d365d8d355e8d355f8d34608d34618d33628d33638d32648e32658e31668e31678e31688e30698e306a8e2f6b8e2f6c8e2e6d8e2e6e8e2e6f8e2d708e2d718e2c718e2c728e2c738e2b748e2b758e2a768e2a778e2a788e29798e297a8e297b8e287c8e287d8e277e8e277f8e27808e26818e26828e26828e25838e25848e25858e24868e24878e23888e23898e238a8d228b8d228c8d228d8d218e8d218f8d21908d21918c20928c20928c20938c1f948c1f958b1f968b1f978b1f988b1f998a1f9a8a1e9b8a1e9c891e9d891f9e891f9f881fa0881fa1881fa1871fa28720a38620a48621a58521a68522a78522a88423a98324aa8325ab8225ac8226ad8127ad8128ae8029af7f2ab07f2cb17e2db27d2eb37c2fb47c31b57b32b67a34b67935b77937b87838b9773aba763bbb753dbc743fbc7340bd7242be7144bf7046c06f48c16e4ac16d4cc26c4ec36b50c46a52c56954c56856c66758c7655ac8645cc8635ec96260ca6063cb5f65cb5e67cc5c69cd5b6ccd5a6ece5870cf5773d05675d05477d1537ad1517cd2507fd34e81d34d84d44b86d54989d5488bd6468ed64590d74393d74195d84098d83e9bd93c9dd93ba0da39a2da37a5db36a8db34aadc32addc30b0dd2fb2dd2db5de2bb8de29bade28bddf26c0df25c2df23c5e021c8e020cae11fcde11dd0e11cd2e21bd5e21ad8e219dae319dde318dfe318e2e418e5e419e7e419eae51aece51befe51cf1e51df4e61ef6e620f8e621fbe723fde725"));
            var o = r(n.i(i.a)("00000401000501010601010802010902020b02020d03030f03031204041405041606051806051a07061c08071e0907200a08220b09240c09260d0a290e0b2b100b2d110c2f120d31130d34140e36150e38160f3b180f3d19103f1a10421c10441d11471e114920114b21114e22115024125325125527125829115a2a115c2c115f2d11612f116331116533106734106936106b38106c390f6e3b0f703d0f713f0f72400f74420f75440f764510774710784910784a10794c117a4e117b4f127b51127c52137c54137d56147d57157e59157e5a167e5c167f5d177f5f187f601880621980641a80651a80671b80681c816a1c816b1d816d1d816e1e81701f81721f817320817521817621817822817922827b23827c23827e24828025828125818326818426818627818827818928818b29818c29818e2a81902a81912b81932b80942c80962c80982d80992d809b2e7f9c2e7f9e2f7fa02f7fa1307ea3307ea5317ea6317da8327daa337dab337cad347cae347bb0357bb2357bb3367ab5367ab73779b83779ba3878bc3978bd3977bf3a77c03a76c23b75c43c75c53c74c73d73c83e73ca3e72cc3f71cd4071cf4070d0416fd2426fd3436ed5446dd6456cd8456cd9466bdb476adc4869de4968df4a68e04c67e24d66e34e65e44f64e55064e75263e85362e95462ea5661eb5760ec5860ed5a5fee5b5eef5d5ef05f5ef1605df2625df2645cf3655cf4675cf4695cf56b5cf66c5cf66e5cf7705cf7725cf8745cf8765cf9785df9795df97b5dfa7d5efa7f5efa815ffb835ffb8560fb8761fc8961fc8a62fc8c63fc8e64fc9065fd9266fd9467fd9668fd9869fd9a6afd9b6bfe9d6cfe9f6dfea16efea36ffea571fea772fea973feaa74feac76feae77feb078feb27afeb47bfeb67cfeb77efeb97ffebb81febd82febf84fec185fec287fec488fec68afec88cfeca8dfecc8ffecd90fecf92fed194fed395fed597fed799fed89afdda9cfddc9efddea0fde0a1fde2a3fde3a5fde5a7fde7a9fde9aafdebacfcecaefceeb0fcf0b2fcf2b4fcf4b6fcf6b8fcf7b9fcf9bbfcfbbdfcfdbf")),
                a = r(n.i(i.a)("00000401000501010601010802010a02020c02020e03021004031204031405041706041907051b08051d09061f0a07220b07240c08260d08290e092b10092d110a30120a32140b34150b37160b39180c3c190c3e1b0c411c0c431e0c451f0c48210c4a230c4c240c4f260c51280b53290b552b0b572d0b592f0a5b310a5c320a5e340a5f3609613809623909633b09643d09653e0966400a67420a68440a68450a69470b6a490b6a4a0c6b4c0c6b4d0d6c4f0d6c510e6c520e6d540f6d550f6d57106e59106e5a116e5c126e5d126e5f136e61136e62146e64156e65156e67166e69166e6a176e6c186e6d186e6f196e71196e721a6e741a6e751b6e771c6d781c6d7a1d6d7c1d6d7d1e6d7f1e6c801f6c82206c84206b85216b87216b88226a8a226a8c23698d23698f24699025689225689326679526679727669827669a28659b29649d29649f2a63a02a63a22b62a32c61a52c60a62d60a82e5fa92e5eab2f5ead305dae305cb0315bb1325ab3325ab43359b63458b73557b93556ba3655bc3754bd3853bf3952c03a51c13a50c33b4fc43c4ec63d4dc73e4cc83f4bca404acb4149cc4248ce4347cf4446d04545d24644d34743d44842d54a41d74b3fd84c3ed94d3dda4e3cdb503bdd513ade5238df5337e05536e15635e25734e35933e45a31e55c30e65d2fe75e2ee8602de9612bea632aeb6429eb6628ec6726ed6925ee6a24ef6c23ef6e21f06f20f1711ff1731df2741cf3761bf37819f47918f57b17f57d15f67e14f68013f78212f78410f8850ff8870ef8890cf98b0bf98c0af98e09fa9008fa9207fa9407fb9606fb9706fb9906fb9b06fb9d07fc9f07fca108fca309fca50afca60cfca80dfcaa0ffcac11fcae12fcb014fcb216fcb418fbb61afbb81dfbba1ffbbc21fbbe23fac026fac228fac42afac62df9c72ff9c932f9cb35f8cd37f8cf3af7d13df7d340f6d543f6d746f5d949f5db4cf4dd4ff4df53f4e156f3e35af3e55df2e661f2e865f2ea69f1ec6df1ed71f1ef75f1f179f2f27df2f482f3f586f3f68af4f88ef5f992f6fa96f8fb9af9fc9dfafda1fcffa4")),
                u = r(n.i(i.a)("0d088710078813078916078a19068c1b068d1d068e20068f2206902406912605912805922a05932c05942e05952f059631059733059735049837049938049a3a049a3c049b3e049c3f049c41049d43039e44039e46039f48039f4903a04b03a14c02a14e02a25002a25102a35302a35502a45601a45801a45901a55b01a55c01a65e01a66001a66100a76300a76400a76600a76700a86900a86a00a86c00a86e00a86f00a87100a87201a87401a87501a87701a87801a87a02a87b02a87d03a87e03a88004a88104a78305a78405a78606a68707a68808a68a09a58b0aa58d0ba58e0ca48f0da4910ea3920fa39410a29511a19613a19814a099159f9a169f9c179e9d189d9e199da01a9ca11b9ba21d9aa31e9aa51f99a62098a72197a82296aa2395ab2494ac2694ad2793ae2892b02991b12a90b22b8fb32c8eb42e8db52f8cb6308bb7318ab83289ba3388bb3488bc3587bd3786be3885bf3984c03a83c13b82c23c81c33d80c43e7fc5407ec6417dc7427cc8437bc9447aca457acb4679cc4778cc4977cd4a76ce4b75cf4c74d04d73d14e72d24f71d35171d45270d5536fd5546ed6556dd7566cd8576bd9586ada5a6ada5b69db5c68dc5d67dd5e66de5f65de6164df6263e06363e16462e26561e26660e3685fe4695ee56a5de56b5de66c5ce76e5be76f5ae87059e97158e97257ea7457eb7556eb7655ec7754ed7953ed7a52ee7b51ef7c51ef7e50f07f4ff0804ef1814df1834cf2844bf3854bf3874af48849f48948f58b47f58c46f68d45f68f44f79044f79143f79342f89441f89540f9973ff9983ef99a3efa9b3dfa9c3cfa9e3bfb9f3afba139fba238fca338fca537fca636fca835fca934fdab33fdac33fdae32fdaf31fdb130fdb22ffdb42ffdb52efeb72dfeb82cfeba2cfebb2bfebd2afebe2afec029fdc229fdc328fdc527fdc627fdc827fdca26fdcb26fccd25fcce25fcd025fcd225fbd324fbd524fbd724fad824fada24f9dc24f9dd25f8df25f8e125f7e225f7e425f6e626f6e826f5e926f5eb27f4ed27f3ee27f3f027f2f227f1f426f1f525f0f724f0f921"))
        },
        function(t, e, n) {
            "use strict";
            var r = n(100),
                i = n(39); + new Date("2000-01-01T00:00:00.000Z") || n.i(i.b)(r.a)
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setDate(t.getDate() + e)
                }, function(t, e) {
                    return (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * i.d) / i.b
                }, function(t) {
                    return t.getDate() - 1
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    var e = t.getTimezoneOffset() * i.d % i.c;
                    e < 0 && (e += i.c), t.setTime(Math.floor((+t - e) / i.c) * i.c + e)
                }, function(t, e) {
                    t.setTime(+t + e * i.c)
                }, function(t, e) {
                    return (e - t) / i.c
                }, function(t) {
                    return t.getHours()
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n.i(r.a)(function() {}, function(t, e) {
                    t.setTime(+t + e)
                }, function(t, e) {
                    return e - t
                });
            i.every = function(t) {
                return t = Math.floor(t), isFinite(t) && t > 0 ? t > 1 ? n.i(r.a)(function(e) {
                    e.setTime(Math.floor(e / t) * t)
                }, function(e, n) {
                    e.setTime(+e + n * t)
                }, function(e, n) {
                    return (n - e) / t
                }) : i : null
            }, e.a = i;
            i.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setTime(Math.floor(t / i.d) * i.d)
                }, function(t, e) {
                    t.setTime(+t + e * i.d)
                }, function(t, e) {
                    return (e - t) / i.d
                }, function(t) {
                    return t.getMinutes()
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n.i(r.a)(function(t) {
                    t.setDate(1), t.setHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setMonth(t.getMonth() + e)
                }, function(t, e) {
                    return e.getMonth() - t.getMonth() + 12 * (e.getFullYear() - t.getFullYear())
                }, function(t) {
                    return t.getMonth()
                });
            e.a = i;
            i.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setTime(Math.floor(t / i.e) * i.e)
                }, function(t, e) {
                    t.setTime(+t + e * i.e)
                }, function(t, e) {
                    return (e - t) / i.e
                }, function(t) {
                    return t.getUTCSeconds()
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setUTCHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setUTCDate(t.getUTCDate() + e)
                }, function(t, e) {
                    return (e - t) / i.b
                }, function(t) {
                    return t.getUTCDate() - 1
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setUTCMinutes(0, 0, 0)
                }, function(t, e) {
                    t.setTime(+t + e * i.c)
                }, function(t, e) {
                    return (e - t) / i.c
                }, function(t) {
                    return t.getUTCHours()
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n(7),
                o = n.i(r.a)(function(t) {
                    t.setUTCSeconds(0, 0)
                }, function(t, e) {
                    t.setTime(+t + e * i.d)
                }, function(t, e) {
                    return (e - t) / i.d
                }, function(t) {
                    return t.getUTCMinutes()
                });
            e.a = o;
            o.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n.i(r.a)(function(t) {
                    t.setUTCDate(1), t.setUTCHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setUTCMonth(t.getUTCMonth() + e)
                }, function(t, e) {
                    return e.getUTCMonth() - t.getUTCMonth() + 12 * (e.getUTCFullYear() - t.getUTCFullYear())
                }, function(t) {
                    return t.getUTCMonth()
                });
            e.a = i;
            i.range
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return n.i(i.a)(function(e) {
                    e.setUTCDate(e.getUTCDate() - (e.getUTCDay() + 7 - t) % 7), e.setUTCHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setUTCDate(t.getUTCDate() + 7 * e)
                }, function(t, e) {
                    return (e - t) / o.a
                })
            }
            n.d(e, "a", function() {
                return a
            }), n.d(e, "b", function() {
                return u
            }), n.d(e, "c", function() {
                return s
            });
            var i = n(2),
                o = n(7),
                a = r(0),
                u = r(1),
                c = r(2),
                f = r(3),
                s = r(4),
                l = r(5),
                h = r(6);
            a.range, u.range, c.range, f.range, s.range, l.range, h.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n.i(r.a)(function(t) {
                    t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setUTCFullYear(t.getUTCFullYear() + e)
                }, function(t, e) {
                    return e.getUTCFullYear() - t.getUTCFullYear()
                }, function(t) {
                    return t.getUTCFullYear()
                });
            i.every = function(t) {
                return isFinite(t = Math.floor(t)) && t > 0 ? n.i(r.a)(function(e) {
                    e.setUTCFullYear(Math.floor(e.getUTCFullYear() / t) * t), e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0)
                }, function(e, n) {
                    e.setUTCFullYear(e.getUTCFullYear() + n * t)
                }) : null
            }, e.a = i;
            i.range
        },
        function(t, e, n) {
            "use strict";

            function r(t) {
                return n.i(i.a)(function(e) {
                    e.setDate(e.getDate() - (e.getDay() + 7 - t) % 7), e.setHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setDate(t.getDate() + 7 * e)
                }, function(t, e) {
                    return (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * o.d) / o.a
                })
            }
            n.d(e, "a", function() {
                return a
            }), n.d(e, "b", function() {
                return u
            }), n.d(e, "c", function() {
                return s
            });
            var i = n(2),
                o = n(7),
                a = r(0),
                u = r(1),
                c = r(2),
                f = r(3),
                s = r(4),
                l = r(5),
                h = r(6);
            a.range, u.range, c.range, f.range, s.range, l.range, h.range
        },
        function(t, e, n) {
            "use strict";
            var r = n(2),
                i = n.i(r.a)(function(t) {
                    t.setMonth(0, 1), t.setHours(0, 0, 0, 0)
                }, function(t, e) {
                    t.setFullYear(t.getFullYear() + e)
                }, function(t, e) {
                    return e.getFullYear() - t.getFullYear()
                }, function(t) {
                    return t.getFullYear()
                });
            i.every = function(t) {
                return isFinite(t = Math.floor(t)) && t > 0 ? n.i(r.a)(function(e) {
                    e.setFullYear(Math.floor(e.getFullYear() / t) * t), e.setMonth(0, 1), e.setHours(0, 0, 0, 0)
                }, function(e, n) {
                    e.setFullYear(e.getFullYear() + n * t)
                }) : null
            }, e.a = i;
            i.range
        },
        function(t, e, n) {
            ! function(e, n) {
                t.exports = n()
            }(0, function() {
                var t = function(t, e) {
                    function n(e, n) {
                        var r = e > n ? e : n;
                        return t.pow(10, 17 - ~~(t.log(r > 0 ? r : -r) * t.LOG10E))
                    }

                    function r(t) {
                        return "[object Function]" === h.call(t)
                    }

                    function o(t) {
                        return "number" == typeof t && t == t
                    }

                    function a() {
                        return new a._init(arguments)
                    }

                    function u() {
                        return 0
                    }

                    function c() {
                        return 1
                    }

                    function f(t, e) {
                        return t === e ? 1 : 0
                    }
                    var s = Array.prototype.concat,
                        l = Array.prototype.slice,
                        h = Object.prototype.toString,
                        p = Array.isArray || function(t) {
                            return "[object Array]" === h.call(t)
                        };
                    a.fn = a.prototype, (a._init = function(t) {
                        if (p(t[0]))
                            if (p(t[0][0])) {
                                r(t[1]) && (t[0] = a.map(t[0], t[1]));
                                for (var e = 0; e < t[0].length; e++) this[e] = t[0][e];
                                this.length = t[0].length
                            } else this[0] = r(t[1]) ? a.map(t[0], t[1]) : t[0], this.length = 1;
                        else if (o(t[0])) this[0] = a.seq.apply(null, t), this.length = 1;
                        else {
                            if (t[0] instanceof a) return a(t[0].toArray());
                            this[0] = [], this.length = 1
                        }
                        return this
                    }).prototype = a.prototype, a._init.constructor = a, a.utils = {
                        calcRdx: n,
                        isArray: p,
                        isFunction: r,
                        isNumber: o,
                        toVector: function(t) {
                            return s.apply([], t)
                        }
                    }, a.extend = function(t) {
                        var e;
                        if (1 === arguments.length) {
                            for (e in t) a[e] = t[e];
                            return this
                        }
                        for (var n = 1; n < arguments.length; n++)
                            for (e in arguments[n]) t[e] = arguments[n][e];
                        return t
                    }, a.rows = function(t) {
                        return t.length || 1
                    }, a.cols = function(t) {
                        return t[0].length || 1
                    }, a.dimensions = function(t) {
                        return {
                            rows: a.rows(t),
                            cols: a.cols(t)
                        }
                    }, a.row = function(t, e) {
                        return p(e) ? e.map(function(e) {
                            return a.row(t, e)
                        }) : t[e]
                    }, a.rowa = function(t, e) {
                        return a.row(t, e)
                    }, a.col = function(t, e) {
                        if (p(e)) {
                            var n = a.arange(t.length).map(function(t) {
                                return new Array(e.length)
                            });
                            return e.forEach(function(e, r) {
                                a.arange(t.length).forEach(function(i) {
                                    n[i][r] = t[i][e]
                                })
                            }), n
                        }
                        for (var r = new Array(t.length), i = 0; i < t.length; i++) r[i] = [t[i][e]];
                        return r
                    }, a.cola = function(t, e) {
                        return a.col(t, e).map(function(t) {
                            return t[0]
                        })
                    }, a.diag = function(t) {
                        for (var e = a.rows(t), n = new Array(e), r = 0; r < e; r++) n[r] = [t[r][r]];
                        return n
                    }, a.antidiag = function(t) {
                        for (var e = a.rows(t) - 1, n = new Array(e), r = 0; e >= 0; e--, r++) n[r] = [t[r][e]];
                        return n
                    }, a.transpose = function(t) {
                        var e, n, r, i, o = [];
                        p(t[0]) || (t = [t]), n = t.length, r = t[0].length;
                        for (var a = 0; a < r; a++) {
                            for (e = new Array(n), i = 0; i < n; i++) e[i] = t[i][a];
                            o.push(e)
                        }
                        return 1 === o.length ? o[0] : o
                    }, a.map = function(t, e, n) {
                        var r, i, o, a, u;
                        for (p(t[0]) || (t = [t]), i = t.length, o = t[0].length, a = n ? t : new Array(i), r = 0; r < i; r++)
                            for (a[r] || (a[r] = new Array(o)), u = 0; u < o; u++) a[r][u] = e(t[r][u], r, u);
                        return 1 === a.length ? a[0] : a
                    }, a.cumreduce = function(t, e, n) {
                        var r, i, o, a, u;
                        for (p(t[0]) || (t = [t]), i = t.length, o = t[0].length, a = n ? t : new Array(i), r = 0; r < i; r++)
                            for (a[r] || (a[r] = new Array(o)), o > 0 && (a[r][0] = t[r][0]), u = 1; u < o; u++) a[r][u] = e(a[r][u - 1], t[r][u]);
                        return 1 === a.length ? a[0] : a
                    }, a.alter = function(t, e) {
                        return a.map(t, e, !0)
                    }, a.create = function(t, e, n) {
                        var i, o = new Array(t);
                        r(e) && (n = e, e = t);
                        for (var a = 0; a < t; a++)
                            for (o[a] = new Array(e), i = 0; i < e; i++) o[a][i] = n(a, i);
                        return o
                    }, a.zeros = function(t, e) {
                        return o(e) || (e = t), a.create(t, e, u)
                    }, a.ones = function(t, e) {
                        return o(e) || (e = t), a.create(t, e, c)
                    }, a.rand = function(e, n) {
                        return o(n) || (n = e), a.create(e, n, t.random)
                    }, a.identity = function(t, e) {
                        return o(e) || (e = t), a.create(t, e, f)
                    }, a.symmetric = function(t) {
                        var e, n, r = t.length;
                        if (t.length !== t[0].length) return !1;
                        for (e = 0; e < r; e++)
                            for (n = 0; n < r; n++)
                                if (t[n][e] !== t[e][n]) return !1;
                        return !0
                    }, a.clear = function(t) {
                        return a.alter(t, u)
                    }, a.seq = function(t, e, i, o) {
                        r(o) || (o = !1);
                        var a, u = [],
                            c = n(t, e),
                            f = (e * c - t * c) / ((i - 1) * c),
                            s = t;
                        for (a = 0; s <= e && a < i; a++, s = (t * c + f * c * a) / c) u.push(o ? o(s, a) : s);
                        return u
                    }, a.arange = function(t, n, r) {
                        var o = [];
                        if (r = r || 1, n === e && (n = t, t = 0), t === n || 0 === r) return [];
                        if (t < n && r < 0) return [];
                        if (t > n && r > 0) return [];
                        if (r > 0)
                            for (i = t; i < n; i += r) o.push(i);
                        else
                            for (i = t; i > n; i += r) o.push(i);
                        return o
                    }, a.slice = function() {
                        function t(t, n, r, i) {
                            var o, u = [],
                                c = t.length;
                            if (n === e && r === e && i === e) return a.copy(t);
                            if (n = n || 0, r = r || t.length, n = n >= 0 ? n : c + n, r = r >= 0 ? r : c + r, i = i || 1, n === r || 0 === i) return [];
                            if (n < r && i < 0) return [];
                            if (n > r && i > 0) return [];
                            if (i > 0)
                                for (o = n; o < r; o += i) u.push(t[o]);
                            else
                                for (o = n; o > r; o += i) u.push(t[o]);
                            return u
                        }
                        return function(e, n) {
                            if (n = n || {}, o(n.row)) return o(n.col) ? e[n.row][n.col] : t(a.rowa(e, n.row), (i = n.col || {}).start, i.end, i.step);
                            if (o(n.col)) return t(a.cola(e, n.col), (r = n.row || {}).start, r.end, r.step);
                            var r = n.row || {},
                                i = n.col || {};
                            return t(e, r.start, r.end, r.step).map(function(e) {
                                return t(e, i.start, i.end, i.step)
                            })
                        }
                    }(), a.sliceAssign = function(n, r, i) {
                        if (o(r.row)) {
                            if (o(r.col)) return n[r.row][r.col] = i;
                            r.col = r.col || {}, r.col.start = r.col.start || 0, r.col.end = r.col.end || n[0].length, r.col.step = r.col.step || 1;
                            var u = a.arange(r.col.start, t.min(n.length, r.col.end), r.col.step),
                                c = r.row;
                            return u.forEach(function(t, e) {
                                n[c][t] = i[e]
                            }), n
                        }
                        if (o(r.col)) {
                            r.row = r.row || {}, r.row.start = r.row.start || 0, r.row.end = r.row.end || n.length, r.row.step = r.row.step || 1;
                            var f = a.arange(r.row.start, t.min(n[0].length, r.row.end), r.row.step),
                                s = r.col;
                            return f.forEach(function(t, e) {
                                n[t][s] = i[e]
                            }), n
                        }
                        i[0].length === e && (i = [i]), r.row.start = r.row.start || 0, r.row.end = r.row.end || n.length, r.row.step = r.row.step || 1, r.col.start = r.col.start || 0, r.col.end = r.col.end || n[0].length, r.col.step = r.col.step || 1;
                        f = a.arange(r.row.start, t.min(n.length, r.row.end), r.row.step), u = a.arange(r.col.start, t.min(n[0].length, r.col.end), r.col.step);
                        return f.forEach(function(t, e) {
                            u.forEach(function(r, o) {
                                n[t][r] = i[e][o]
                            })
                        }), n
                    }, a.diagonal = function(t) {
                        var e = a.zeros(t.length, t.length);
                        return t.forEach(function(t, n) {
                            e[n][n] = t
                        }), e
                    }, a.copy = function(t) {
                        return t.map(function(t) {
                            return o(t) ? t : t.map(function(t) {
                                return t
                            })
                        })
                    };
                    var d = a.prototype;
                    return d.length = 0, d.push = Array.prototype.push, d.sort = Array.prototype.sort, d.splice = Array.prototype.splice, d.slice = Array.prototype.slice, d.toArray = function() {
                            return this.length > 1 ? l.call(this) : l.call(this)[0]
                        }, d.map = function(t, e) {
                            return a(a.map(this, t, e))
                        }, d.cumreduce = function(t, e) {
                            return a(a.cumreduce(this, t, e))
                        }, d.alter = function(t) {
                            return a.alter(this, t), this
                        },
                        function(t) {
                            for (var e = 0; e < t.length; e++)! function(t) {
                                d[t] = function(e) {
                                    var n, r = this;
                                    return e ? (setTimeout(function() {
                                        e.call(r, d[t].call(r))
                                    }), this) : (n = a[t](this), p(n) ? a(n) : n)
                                }
                            }(t[e])
                        }("transpose clear symmetric rows cols dimensions diag antidiag".split(" ")),
                        function(t) {
                            for (var e = 0; e < t.length; e++)! function(t) {
                                d[t] = function(e, n) {
                                    var r = this;
                                    return n ? (setTimeout(function() {
                                        n.call(r, d[t].call(r, e))
                                    }), this) : a(a[t](this, e))
                                }
                            }(t[e])
                        }("row col".split(" ")),
                        function(t) {
                            for (var e = 0; e < t.length; e++)! function(t) {
                                d[t] = new Function("return jStat(jStat." + t + ".apply(null, arguments));")
                            }(t[e])
                        }("create zeros ones rand identity".split(" ")), a
                }(Math);
                return function(t, e) {
                        function n(t, e) {
                            return t - e
                        }

                        function r(t, n, r) {
                            return e.max(n, e.min(t, r))
                        }
                        var i = t.utils.isFunction;
                        t.sum = function(t) {
                            for (var e = 0, n = t.length; --n >= 0;) e += t[n];
                            return e
                        }, t.sumsqrd = function(t) {
                            for (var e = 0, n = t.length; --n >= 0;) e += t[n] * t[n];
                            return e
                        }, t.sumsqerr = function(e) {
                            for (var n, r = t.mean(e), i = 0, o = e.length; --o >= 0;) i += (n = e[o] - r) * n;
                            return i
                        }, t.sumrow = function(t) {
                            for (var e = 0, n = t.length; --n >= 0;) e += t[n];
                            return e
                        }, t.product = function(t) {
                            for (var e = 1, n = t.length; --n >= 0;) e *= t[n];
                            return e
                        }, t.min = function(t) {
                            for (var e = t[0], n = 0; ++n < t.length;) t[n] < e && (e = t[n]);
                            return e
                        }, t.max = function(t) {
                            for (var e = t[0], n = 0; ++n < t.length;) t[n] > e && (e = t[n]);
                            return e
                        }, t.unique = function(t) {
                            for (var e = {}, n = [], r = 0; r < t.length; r++) e[t[r]] || (e[t[r]] = !0, n.push(t[r]));
                            return n
                        }, t.mean = function(e) {
                            return t.sum(e) / e.length
                        }, t.meansqerr = function(e) {
                            return t.sumsqerr(e) / e.length
                        }, t.geomean = function(n) {
                            return e.pow(t.product(n), 1 / n.length)
                        }, t.median = function(t) {
                            var e = t.length,
                                r = t.slice().sort(n);
                            return 1 & e ? r[e / 2 | 0] : (r[e / 2 - 1] + r[e / 2]) / 2
                        }, t.cumsum = function(e) {
                            return t.cumreduce(e, function(t, e) {
                                return t + e
                            })
                        }, t.cumprod = function(e) {
                            return t.cumreduce(e, function(t, e) {
                                return t * e
                            })
                        }, t.diff = function(t) {
                            for (var e = [], n = t.length, r = 1; r < n; r++) e.push(t[r] - t[r - 1]);
                            return e
                        }, t.rank = function(t) {
                            for (var e = t.length, r = t.slice().sort(n), i = new Array(e), o = 0; o < e; o++) {
                                var a = r.indexOf(t[o]),
                                    u = r.lastIndexOf(t[o]);
                                if (a === u) var c = a;
                                else c = (a + u) / 2;
                                i[o] = c + 1
                            }
                            return i
                        }, t.mode = function(t) {
                            for (var e = t.length, r = t.slice().sort(n), i = 1, o = 0, a = 0, u = [], c = 0; c < e; c++) r[c] === r[c + 1] ? i++ : (i > o ? (u = [r[c]], o = i, a = 0) : i === o && (u.push(r[c]), a++), i = 1);
                            return 0 === a ? u[0] : u
                        }, t.range = function(e) {
                            return t.max(e) - t.min(e)
                        }, t.variance = function(e, n) {
                            return t.sumsqerr(e) / (e.length - (n ? 1 : 0))
                        }, t.pooledvariance = function(e) {
                            return e.reduce(function(e, n) {
                                return e + t.sumsqerr(n)
                            }, 0) / (e.reduce(function(t, e) {
                                return t + e.length
                            }, 0) - e.length)
                        }, t.deviation = function(e) {
                            for (var n = t.mean(e), r = e.length, i = new Array(r), o = 0; o < r; o++) i[o] = e[o] - n;
                            return i
                        }, t.stdev = function(n, r) {
                            return e.sqrt(t.variance(n, r))
                        }, t.pooledstdev = function(n) {
                            return e.sqrt(t.pooledvariance(n))
                        }, t.meandev = function(n) {
                            for (var r = t.mean(n), i = [], o = n.length - 1; o >= 0; o--) i.push(e.abs(n[o] - r));
                            return t.mean(i)
                        }, t.meddev = function(n) {
                            for (var r = t.median(n), i = [], o = n.length - 1; o >= 0; o--) i.push(e.abs(n[o] - r));
                            return t.median(i)
                        }, t.coeffvar = function(e) {
                            return t.stdev(e) / t.mean(e)
                        }, t.quartiles = function(t) {
                            var r = t.length,
                                i = t.slice().sort(n);
                            return [i[e.round(r / 4) - 1], i[e.round(r / 2) - 1], i[e.round(3 * r / 4) - 1]]
                        }, t.quantiles = function(t, i, o, a) {
                            var u, c, f, s, l = t.slice().sort(n),
                                h = [i.length],
                                p = t.length;
                            void 0 === o && (o = 3 / 8), void 0 === a && (a = 3 / 8);
                            for (var d = 0; d < i.length; d++) s = r((c = p * (u = i[d]) + (o + u * (1 - o - a))) - (f = e.floor(r(c, 1, p - 1))), 0, 1), h[d] = (1 - s) * l[f - 1] + s * l[f];
                            return h
                        }, t.percentile = function(t, e) {
                            var r = t.slice().sort(n),
                                i = e * (r.length - 1),
                                o = parseInt(i),
                                a = i - o;
                            return o + 1 < r.length ? r[o] * (1 - a) + r[o + 1] * a : r[o]
                        }, t.percentileOfScore = function(t, e, n) {
                            var r, i = 0,
                                o = t.length,
                                a = !1;
                            "strict" === n && (a = !0);
                            for (var u = 0; u < o; u++) r = t[u], (a && r < e || !a && r <= e) && i++;
                            return i / o
                        }, t.histogram = function(n, r) {
                            for (var i = t.min(n), o = r || 4, a = (t.max(n) - i) / o, u = n.length, c = (r = [], 0); c < o; c++) r[c] = 0;
                            for (c = 0; c < u; c++) r[e.min(e.floor((n[c] - i) / a), o - 1)] += 1;
                            return r
                        }, t.covariance = function(e, n) {
                            for (var r = t.mean(e), i = t.mean(n), o = e.length, a = new Array(o), u = 0; u < o; u++) a[u] = (e[u] - r) * (n[u] - i);
                            return t.sum(a) / (o - 1)
                        }, t.corrcoeff = function(e, n) {
                            return t.covariance(e, n) / t.stdev(e, 1) / t.stdev(n, 1)
                        }, t.spearmancoeff = function(e, n) {
                            return e = t.rank(e), n = t.rank(n), t.corrcoeff(e, n)
                        }, t.stanMoment = function(n, r) {
                            for (var i = t.mean(n), o = t.stdev(n), a = n.length, u = 0, c = 0; c < a; c++) u += e.pow((n[c] - i) / o, r);
                            return u / n.length
                        }, t.skewness = function(e) {
                            return t.stanMoment(e, 3)
                        }, t.kurtosis = function(e) {
                            return t.stanMoment(e, 4) - 3
                        };
                        var o = t.prototype;
                        ! function(e) {
                            for (var n = 0; n < e.length; n++)! function(e) {
                                o[e] = function(n, r) {
                                    var a = [],
                                        u = 0,
                                        c = this;
                                    if (i(n) && (r = n, n = !1), r) return setTimeout(function() {
                                        r.call(c, o[e].call(c, n))
                                    }), this;
                                    if (this.length > 1) {
                                        for (c = !0 === n ? this : this.transpose(); u < c.length; u++) a[u] = t[e](c[u]);
                                        return a
                                    }
                                    return t[e](this[0], n)
                                }
                            }(e[n])
                        }("cumsum cumprod".split(" ")),
                        function(e) {
                            for (var n = 0; n < e.length; n++)! function(e) {
                                o[e] = function(n, r) {
                                    var a = [],
                                        u = 0,
                                        c = this;
                                    if (i(n) && (r = n, n = !1), r) return setTimeout(function() {
                                        r.call(c, o[e].call(c, n))
                                    }), this;
                                    if (this.length > 1) {
                                        for ("sumrow" !== e && (c = !0 === n ? this : this.transpose()); u < c.length; u++) a[u] = t[e](c[u]);
                                        return !0 === n ? t[e](t.utils.toVector(a)) : a
                                    }
                                    return t[e](this[0], n)
                                }
                            }(e[n])
                        }("sum sumsqrd sumsqerr sumrow product min max unique mean meansqerr geomean median diff rank mode range variance deviation stdev meandev meddev coeffvar quartiles histogram skewness kurtosis".split(" ")),
                        function(e) {
                            for (var n = 0; n < e.length; n++)! function(e) {
                                o[e] = function() {
                                    var n = [],
                                        r = 0,
                                        a = this,
                                        u = Array.prototype.slice.call(arguments);
                                    if (i(u[u.length - 1])) {
                                        var c = u[u.length - 1],
                                            f = u.slice(0, u.length - 1);
                                        return setTimeout(function() {
                                            c.call(a, o[e].apply(a, f))
                                        }), this
                                    }
                                    c = void 0;
                                    var s = function(n) {
                                        return t[e].apply(a, [n].concat(u))
                                    };
                                    if (this.length > 1) {
                                        for (a = a.transpose(); r < a.length; r++) n[r] = s(a[r]);
                                        return n
                                    }
                                    return s(this[0])
                                }
                            }(e[n])
                        }("quantiles percentileOfScore".split(" "))
                    }(t, Math),
                    function(t, e) {
                        t.gammaln = function(t) {
                                var n, r, i, o = 0,
                                    a = [76.18009172947146, -86.50532032941678, 24.01409824083091, -1.231739572450155, .001208650973866179, -5395239384953e-18],
                                    u = 1.000000000190015;
                                for (i = (r = n = t) + 5.5, i -= (n + .5) * e.log(i); o < 6; o++) u += a[o] / ++r;
                                return e.log(2.5066282746310007 * u / n) - i
                            }, t.gammafn = function(t) {
                                var n, r, i, o = [-1.716185138865495, 24.76565080557592, -379.80425647094563, 629.3311553128184, 866.9662027904133, -31451.272968848367, -36144.413418691176, 66456.14382024054],
                                    a = [-30.8402300119739, 315.35062697960416, -1015.1563674902192, -3107.771671572311, 22538.11842098015, 4755.846277527881, -134659.9598649693, -115132.2596755535],
                                    u = !1,
                                    c = 0,
                                    f = 0,
                                    s = 0,
                                    l = t;
                                if (l <= 0) {
                                    if (!(i = l % 1 + 3.6e-16)) return 1 / 0;
                                    u = (1 & l ? -1 : 1) * e.PI / e.sin(e.PI * i), l = 1 - l
                                }
                                r = l, n = l < 1 ? l++ : (l -= c = (0 | l) - 1) - 1;
                                for (var h = 0; h < 8; ++h) s = (s + o[h]) * n, f = f * n + a[h];
                                if (i = s / f + 1, r < l) i /= r;
                                else if (r > l)
                                    for (h = 0; h < c; ++h) i *= l, l++;
                                return u && (i = u / i), i
                            }, t.gammap = function(e, n) {
                                return t.lowRegGamma(e, n) * t.gammafn(e)
                            }, t.lowRegGamma = function(n, r) {
                                var i, o = t.gammaln(n),
                                    a = n,
                                    u = 1 / n,
                                    c = u,
                                    f = r + 1 - n,
                                    s = 1 / 1e-30,
                                    l = 1 / f,
                                    h = l,
                                    p = 1,
                                    d = -~(8.5 * e.log(n >= 1 ? n : 1 / n) + .4 * n + 17);
                                if (r < 0 || n <= 0) return NaN;
                                if (r < n + 1) {
                                    for (; p <= d; p++) u += c *= r / ++a;
                                    return u * e.exp(-r + n * e.log(r) - o)
                                }
                                for (; p <= d; p++) h *= (l = 1 / (l = (i = -p * (p - n)) * l + (f += 2))) * (s = f + i / s);
                                return 1 - h * e.exp(-r + n * e.log(r) - o)
                            }, t.factorialln = function(e) {
                                return e < 0 ? NaN : t.gammaln(e + 1)
                            }, t.factorial = function(e) {
                                return e < 0 ? NaN : t.gammafn(e + 1)
                            }, t.combination = function(n, r) {
                                return n > 170 || r > 170 ? e.exp(t.combinationln(n, r)) : t.factorial(n) / t.factorial(r) / t.factorial(n - r)
                            }, t.combinationln = function(e, n) {
                                return t.factorialln(e) - t.factorialln(n) - t.factorialln(e - n)
                            }, t.permutation = function(e, n) {
                                return t.factorial(e) / t.factorial(e - n)
                            }, t.betafn = function(n, r) {
                                if (!(n <= 0 || r <= 0)) return n + r > 170 ? e.exp(t.betaln(n, r)) : t.gammafn(n) * t.gammafn(r) / t.gammafn(n + r)
                            }, t.betaln = function(e, n) {
                                return t.gammaln(e) + t.gammaln(n) - t.gammaln(e + n)
                            }, t.betacf = function(t, n, r) {
                                var i, o, a, u, c = 1,
                                    f = n + r,
                                    s = n + 1,
                                    l = n - 1,
                                    h = 1,
                                    p = 1 - f * t / s;
                                for (e.abs(p) < 1e-30 && (p = 1e-30), u = p = 1 / p; c <= 100 && (i = 2 * c, o = c * (r - c) * t / ((l + i) * (n + i)), p = 1 + o * p, e.abs(p) < 1e-30 && (p = 1e-30), h = 1 + o / h, e.abs(h) < 1e-30 && (h = 1e-30), p = 1 / p, u *= p * h, o = -(n + c) * (f + c) * t / ((n + i) * (s + i)), p = 1 + o * p, e.abs(p) < 1e-30 && (p = 1e-30), h = 1 + o / h, e.abs(h) < 1e-30 && (h = 1e-30), p = 1 / p, a = p * h, u *= a, !(e.abs(a - 1) < 3e-7)); c++);
                                return u
                            }, t.gammapinv = function(n, r) {
                                var i, o, a, u, c, f, s, l = 0,
                                    h = r - 1,
                                    p = t.gammaln(r);
                                if (n >= 1) return e.max(100, r + 100 * e.sqrt(r));
                                if (n <= 0) return 0;
                                for (r > 1 ? (f = e.log(h), s = e.exp(h * (f - 1) - p), c = n < .5 ? n : 1 - n, i = (2.30753 + .27061 * (a = e.sqrt(-2 * e.log(c)))) / (1 + a * (.99229 + .04481 * a)) - a, n < .5 && (i = -i), i = e.max(.001, r * e.pow(1 - 1 / (9 * r) - i / (3 * e.sqrt(r)), 3))) : i = n < (a = 1 - r * (.253 + .12 * r)) ? e.pow(n / a, 1 / r) : 1 - e.log(1 - (n - a) / (1 - a)); l < 12; l++) {
                                    if (i <= 0) return 0;
                                    if (o = t.lowRegGamma(r, i) - n, a = r > 1 ? s * e.exp(-(i - h) + h * (e.log(i) - f)) : e.exp(-i + h * e.log(i) - p), u = o / a, (i -= a = u / (1 - .5 * e.min(1, u * ((r - 1) / i - 1)))) <= 0 && (i = .5 * (i + a)), e.abs(a) < 1e-8 * i) break
                                }
                                return i
                            }, t.erf = function(t) {
                                var n, r, i, o, a = [-1.3026537197817094, .6419697923564902, .019476473204185836, -.00956151478680863, -.000946595344482036, .000366839497852761, 42523324806907e-18, -20278578112534e-18, -1624290004647e-18, 130365583558e-17, 1.5626441722e-8, -8.5238095915e-8, 6.529054439e-9, 5.059343495e-9, -9.91364156e-10, -2.27365122e-10, 9.6467911e-11, 2.394038e-12, -6.886027e-12, 8.94487e-13, 3.13092e-13, -1.12708e-13, 3.81e-16, 7.106e-15, -1.523e-15, -9.4e-17, 1.21e-16, -2.8e-17],
                                    u = a.length - 1,
                                    c = !1,
                                    f = 0,
                                    s = 0;
                                for (t < 0 && (t = -t, c = !0), r = 4 * (n = 2 / (2 + t)) - 2; u > 0; u--) i = f, f = r * f - s + a[u], s = i;
                                return o = n * e.exp(-t * t + .5 * (a[0] + r * f) - s), c ? o - 1 : 1 - o
                            }, t.erfc = function(e) {
                                return 1 - t.erf(e)
                            }, t.erfcinv = function(n) {
                                var r, i, o, a, u = 0;
                                if (n >= 2) return -100;
                                if (n <= 0) return 100;
                                for (a = n < 1 ? n : 2 - n, r = -.70711 * ((2.30753 + .27061 * (o = e.sqrt(-2 * e.log(a / 2)))) / (1 + o * (.99229 + .04481 * o)) - o); u < 2; u++) r += (i = t.erfc(r) - a) / (1.1283791670955126 * e.exp(-r * r) - r * i);
                                return n < 1 ? r : -r
                            }, t.ibetainv = function(n, r, i) {
                                var o, a, u, c, f, s, l, h, p, d, v, y = r - 1,
                                    _ = i - 1,
                                    g = 0;
                                if (n <= 0) return 0;
                                if (n >= 1) return 1;
                                for (r >= 1 && i >= 1 ? (u = n < .5 ? n : 1 - n, l = (2.30753 + .27061 * (c = e.sqrt(-2 * e.log(u)))) / (1 + c * (.99229 + .04481 * c)) - c, n < .5 && (l = -l), h = (l * l - 3) / 6, p = 2 / (1 / (2 * r - 1) + 1 / (2 * i - 1)), d = l * e.sqrt(h + p) / p - (1 / (2 * i - 1) - 1 / (2 * r - 1)) * (h + 5 / 6 - 2 / (3 * p)), l = r / (r + i * e.exp(2 * d))) : (o = e.log(r / (r + i)), a = e.log(i / (r + i)), l = n < (c = e.exp(r * o) / r) / (d = c + (f = e.exp(i * a) / i)) ? e.pow(r * d * n, 1 / r) : 1 - e.pow(i * d * (1 - n), 1 / i)), v = -t.gammaln(r) - t.gammaln(i) + t.gammaln(r + i); g < 10; g++) {
                                    if (0 === l || 1 === l) return l;
                                    if (s = t.ibeta(l, r, i) - n, c = e.exp(y * e.log(l) + _ * e.log(1 - l) + v), f = s / c, (l -= c = f / (1 - .5 * e.min(1, f * (y / l - _ / (1 - l))))) <= 0 && (l = .5 * (l + c)), l >= 1 && (l = .5 * (l + c + 1)), e.abs(c) < 1e-8 * l && g > 0) break
                                }
                                return l
                            }, t.ibeta = function(n, r, i) {
                                var o = 0 === n || 1 === n ? 0 : e.exp(t.gammaln(r + i) - t.gammaln(r) - t.gammaln(i) + r * e.log(n) + i * e.log(1 - n));
                                return !(n < 0 || n > 1) && (n < (r + 1) / (r + i + 2) ? o * t.betacf(n, r, i) / r : 1 - o * t.betacf(1 - n, i, r) / i)
                            }, t.randn = function(n, r) {
                                var i, o, a, u, c;
                                if (r || (r = n), n) return t.create(n, r, function() {
                                    return t.randn()
                                });
                                do {
                                    i = e.random(), o = 1.7156 * (e.random() - .5), c = (a = i - .449871) * a + (u = e.abs(o) + .386595) * (.196 * u - .25472 * a)
                                } while (c > .27597 && (c > .27846 || o * o > -4 * e.log(i) * i * i));
                                return o / i
                            }, t.randg = function(n, r, i) {
                                var o, a, u, c, f, s, l = n;
                                if (i || (i = r), n || (n = 1), r) return (s = t.zeros(r, i)).alter(function() {
                                    return t.randg(n)
                                }), s;
                                n < 1 && (n += 1), o = n - 1 / 3, a = 1 / e.sqrt(9 * o);
                                do {
                                    do {
                                        c = 1 + a * (f = t.randn())
                                    } while (c <= 0);
                                    c *= c * c, u = e.random()
                                } while (u > 1 - .331 * e.pow(f, 4) && e.log(u) > .5 * f * f + o * (1 - c + e.log(c)));
                                if (n == l) return o * c;
                                do {
                                    u = e.random()
                                } while (0 === u);
                                return e.pow(u, 1 / l) * o * c
                            },
                            function(e) {
                                for (var n = 0; n < e.length; n++)! function(e) {
                                    t.fn[e] = function() {
                                        return t(t.map(this, function(n) {
                                            return t[e](n)
                                        }))
                                    }
                                }(e[n])
                            }("gammaln gammafn factorial factorialln".split(" ")),
                            function(e) {
                                for (var n = 0; n < e.length; n++)! function(e) {
                                    t.fn[e] = function() {
                                        return t(t[e].apply(null, arguments))
                                    }
                                }(e[n])
                            }("randn".split(" "))
                    }(t, Math),
                    function(t, e) {
                        function n(n, r, i) {
                            var o = [.9815606342467192, .9041172563704749, .7699026741943047, .5873179542866175, .3678314989981802, .1252334085114689],
                                a = [.04717533638651183, .10693932599531843, .16007832854334622, .20316742672306592, .2334925365383548, .24914704581340277],
                                u = .5 * n;
                            if (u >= 8) return 1;
                            var c = 2 * t.normal.cdf(u, 0, 1, 1, 0) - 1;
                            c = c >= e.exp(-50 / i) ? e.pow(c, i) : 0;
                            for (var f, s = u, l = (8 - u) / (f = n > 3 ? 2 : 3), h = s + l, p = 0, d = i - 1, v = 1; v <= f; v++) {
                                for (var y = 0, _ = .5 * (h + s), g = .5 * (h - s), b = 1; b <= 12; b++) {
                                    var m, w = _ + g * (6 < b ? o[(m = 12 - b + 1) - 1] : -o[(m = b) - 1]),
                                        O = w * w;
                                    if (O > 60) break;
                                    var x = .5 * (2 * t.normal.cdf(w, 0, 1, 1, 0)) - .5 * (2 * t.normal.cdf(w, n, 1, 1, 0));
                                    x >= e.exp(-30 / d) && (y += x = a[m - 1] * e.exp(-.5 * O) * e.pow(x, d))
                                }
                                p += y *= 2 * g * i / e.sqrt(2 * e.PI), s = h, h += l
                            }
                            return (c += p) <= e.exp(-30 / r) ? 0 : (c = e.pow(c, r)) >= 1 ? 1 : c
                        }! function(e) {
                            for (var n = 0; n < e.length; n++)! function(e) {
                                t[e] = function(t, e, n) {
                                        return this instanceof arguments.callee ? (this._a = t, this._b = e, this._c = n, this) : new arguments.callee(t, e, n)
                                    }, t.fn[e] = function(n, r, i) {
                                        var o = t[e](n, r, i);
                                        return o.data = this, o
                                    }, t[e].prototype.sample = function(n) {
                                        var r = this._a,
                                            i = this._b,
                                            o = this._c;
                                        return n ? t.alter(n, function() {
                                            return t[e].sample(r, i, o)
                                        }) : t[e].sample(r, i, o)
                                    },
                                    function(n) {
                                        for (var r = 0; r < n.length; r++)! function(n) {
                                            t[e].prototype[n] = function(r) {
                                                var i = this._a,
                                                    o = this._b,
                                                    a = this._c;
                                                return r || 0 === r || (r = this.data), "number" != typeof r ? t.fn.map.call(r, function(r) {
                                                    return t[e][n](r, i, o, a)
                                                }) : t[e][n](r, i, o, a)
                                            }
                                        }(n[r])
                                    }("pdf cdf inv".split(" ")),
                                    function(n) {
                                        for (var r = 0; r < n.length; r++)! function(n) {
                                            t[e].prototype[n] = function() {
                                                return t[e][n](this._a, this._b, this._c)
                                            }
                                        }(n[r])
                                    }("mean median mode variance".split(" "))
                            }(e[n])
                        }("beta centralF cauchy chisquare exponential gamma invgamma kumaraswamy laplace lognormal noncentralt normal pareto studentt weibull uniform binomial negbin hypgeom poisson triangular tukey arcsine".split(" ")), t.extend(t.beta, {
                            pdf: function(n, r, i) {
                                return n > 1 || n < 0 ? 0 : 1 == r && 1 == i ? 1 : r < 512 && i < 512 ? e.pow(n, r - 1) * e.pow(1 - n, i - 1) / t.betafn(r, i) : e.exp((r - 1) * e.log(n) + (i - 1) * e.log(1 - n) - t.betaln(r, i))
                            },
                            cdf: function(e, n, r) {
                                return e > 1 || e < 0 ? 1 * (e > 1) : t.ibeta(e, n, r)
                            },
                            inv: function(e, n, r) {
                                return t.ibetainv(e, n, r)
                            },
                            mean: function(t, e) {
                                return t / (t + e)
                            },
                            median: function(e, n) {
                                return t.ibetainv(.5, e, n)
                            },
                            mode: function(t, e) {
                                return (t - 1) / (t + e - 2)
                            },
                            sample: function(e, n) {
                                var r = t.randg(e);
                                return r / (r + t.randg(n))
                            },
                            variance: function(t, n) {
                                return t * n / (e.pow(t + n, 2) * (t + n + 1))
                            }
                        }), t.extend(t.centralF, {
                            pdf: function(n, r, i) {
                                var o, a;
                                return n < 0 ? 0 : r <= 2 ? 0 === n && r < 2 ? 1 / 0 : 0 === n && 2 === r ? 1 : 1 / t.betafn(r / 2, i / 2) * e.pow(r / i, r / 2) * e.pow(n, r / 2 - 1) * e.pow(1 + r / i * n, -(r + i) / 2) : (o = r * n / (i + n * r), a = i / (i + n * r), r * a / 2 * t.binomial.pdf((r - 2) / 2, (r + i - 2) / 2, o))
                            },
                            cdf: function(e, n, r) {
                                return e < 0 ? 0 : t.ibeta(n * e / (n * e + r), n / 2, r / 2)
                            },
                            inv: function(e, n, r) {
                                return r / (n * (1 / t.ibetainv(e, n / 2, r / 2) - 1))
                            },
                            mean: function(t, e) {
                                return e > 2 ? e / (e - 2) : void 0
                            },
                            mode: function(t, e) {
                                return t > 2 ? e * (t - 2) / (t * (e + 2)) : void 0
                            },
                            sample: function(e, n) {
                                return 2 * t.randg(e / 2) / e / (2 * t.randg(n / 2) / n)
                            },
                            variance: function(t, e) {
                                if (!(e <= 4)) return 2 * e * e * (t + e - 2) / (t * (e - 2) * (e - 2) * (e - 4))
                            }
                        }), t.extend(t.cauchy, {
                            pdf: function(t, n, r) {
                                return r < 0 ? 0 : r / (e.pow(t - n, 2) + e.pow(r, 2)) / e.PI
                            },
                            cdf: function(t, n, r) {
                                return e.atan((t - n) / r) / e.PI + .5
                            },
                            inv: function(t, n, r) {
                                return n + r * e.tan(e.PI * (t - .5))
                            },
                            median: function(t, e) {
                                return t
                            },
                            mode: function(t, e) {
                                return t
                            },
                            sample: function(n, r) {
                                return t.randn() * e.sqrt(1 / (2 * t.randg(.5))) * r + n
                            }
                        }), t.extend(t.chisquare, {
                            pdf: function(n, r) {
                                return n < 0 ? 0 : 0 === n && 2 === r ? .5 : e.exp((r / 2 - 1) * e.log(n) - n / 2 - r / 2 * e.log(2) - t.gammaln(r / 2))
                            },
                            cdf: function(e, n) {
                                return e < 0 ? 0 : t.lowRegGamma(n / 2, e / 2)
                            },
                            inv: function(e, n) {
                                return 2 * t.gammapinv(e, .5 * n)
                            },
                            mean: function(t) {
                                return t
                            },
                            median: function(t) {
                                return t * e.pow(1 - 2 / (9 * t), 3)
                            },
                            mode: function(t) {
                                return t - 2 > 0 ? t - 2 : 0
                            },
                            sample: function(e) {
                                return 2 * t.randg(e / 2)
                            },
                            variance: function(t) {
                                return 2 * t
                            }
                        }), t.extend(t.exponential, {
                            pdf: function(t, n) {
                                return t < 0 ? 0 : n * e.exp(-n * t)
                            },
                            cdf: function(t, n) {
                                return t < 0 ? 0 : 1 - e.exp(-n * t)
                            },
                            inv: function(t, n) {
                                return -e.log(1 - t) / n
                            },
                            mean: function(t) {
                                return 1 / t
                            },
                            median: function(t) {
                                return 1 / t * e.log(2)
                            },
                            mode: function(t) {
                                return 0
                            },
                            sample: function(t) {
                                return -1 / t * e.log(e.random())
                            },
                            variance: function(t) {
                                return e.pow(t, -2)
                            }
                        }), t.extend(t.gamma, {
                            pdf: function(n, r, i) {
                                return n < 0 ? 0 : 0 === n && 1 === r ? 1 / i : e.exp((r - 1) * e.log(n) - n / i - t.gammaln(r) - r * e.log(i))
                            },
                            cdf: function(e, n, r) {
                                return e < 0 ? 0 : t.lowRegGamma(n, e / r)
                            },
                            inv: function(e, n, r) {
                                return t.gammapinv(e, n) * r
                            },
                            mean: function(t, e) {
                                return t * e
                            },
                            mode: function(t, e) {
                                if (t > 1) return (t - 1) * e
                            },
                            sample: function(e, n) {
                                return t.randg(e) * n
                            },
                            variance: function(t, e) {
                                return t * e * e
                            }
                        }), t.extend(t.invgamma, {
                            pdf: function(n, r, i) {
                                return n <= 0 ? 0 : e.exp(-(r + 1) * e.log(n) - i / n - t.gammaln(r) + r * e.log(i))
                            },
                            cdf: function(e, n, r) {
                                return e <= 0 ? 0 : 1 - t.lowRegGamma(n, r / e)
                            },
                            inv: function(e, n, r) {
                                return r / t.gammapinv(1 - e, n)
                            },
                            mean: function(t, e) {
                                return t > 1 ? e / (t - 1) : void 0
                            },
                            mode: function(t, e) {
                                return e / (t + 1)
                            },
                            sample: function(e, n) {
                                return n / t.randg(e)
                            },
                            variance: function(t, e) {
                                if (!(t <= 2)) return e * e / ((t - 1) * (t - 1) * (t - 2))
                            }
                        }), t.extend(t.kumaraswamy, {
                            pdf: function(t, n, r) {
                                return 0 === t && 1 === n ? r : 1 === t && 1 === r ? n : e.exp(e.log(n) + e.log(r) + (n - 1) * e.log(t) + (r - 1) * e.log(1 - e.pow(t, n)))
                            },
                            cdf: function(t, n, r) {
                                return t < 0 ? 0 : t > 1 ? 1 : 1 - e.pow(1 - e.pow(t, n), r)
                            },
                            inv: function(t, n, r) {
                                return e.pow(1 - e.pow(1 - t, 1 / r), 1 / n)
                            },
                            mean: function(e, n) {
                                return n * t.gammafn(1 + 1 / e) * t.gammafn(n) / t.gammafn(1 + 1 / e + n)
                            },
                            median: function(t, n) {
                                return e.pow(1 - e.pow(2, -1 / n), 1 / t)
                            },
                            mode: function(t, n) {
                                if (t >= 1 && n >= 1 && 1 !== t && 1 !== n) return e.pow((t - 1) / (t * n - 1), 1 / t)
                            },
                            variance: function(t, e) {
                                throw new Error("variance not yet implemented")
                            }
                        }), t.extend(t.lognormal, {
                            pdf: function(t, n, r) {
                                return t <= 0 ? 0 : e.exp(-e.log(t) - .5 * e.log(2 * e.PI) - e.log(r) - e.pow(e.log(t) - n, 2) / (2 * r * r))
                            },
                            cdf: function(n, r, i) {
                                return n < 0 ? 0 : .5 + .5 * t.erf((e.log(n) - r) / e.sqrt(2 * i * i))
                            },
                            inv: function(n, r, i) {
                                return e.exp(-1.4142135623730951 * i * t.erfcinv(2 * n) + r)
                            },
                            mean: function(t, n) {
                                return e.exp(t + n * n / 2)
                            },
                            median: function(t, n) {
                                return e.exp(t)
                            },
                            mode: function(t, n) {
                                return e.exp(t - n * n)
                            },
                            sample: function(n, r) {
                                return e.exp(t.randn() * r + n)
                            },
                            variance: function(t, n) {
                                return (e.exp(n * n) - 1) * e.exp(2 * t + n * n)
                            }
                        }), t.extend(t.noncentralt, {
                            pdf: function(n, r, i) {
                                return e.abs(i) < 1e-14 ? t.studentt.pdf(n, r) : e.abs(n) < 1e-14 ? e.exp(t.gammaln((r + 1) / 2) - i * i / 2 - .5 * e.log(e.PI * r) - t.gammaln(r / 2)) : r / n * (t.noncentralt.cdf(n * e.sqrt(1 + 2 / r), r + 2, i) - t.noncentralt.cdf(n, r, i))
                            },
                            cdf: function(n, r, i) {
                                if (e.abs(i) < 1e-14) return t.studentt.cdf(n, r);
                                var o = !1;
                                n < 0 && (o = !0, i = -i);
                                for (var a = t.normal.cdf(-i, 0, 1), u = 1e-14 + 1, c = u, f = n * n / (n * n + r), s = 0, l = e.exp(-i * i / 2), h = e.exp(-i * i / 2 - .5 * e.log(2) - t.gammaln(1.5)) * i; s < 200 || c > 1e-14 || u > 1e-14;) c = u, s > 0 && (l *= i * i / (2 * s), h *= i * i / (2 * (s + .5))), a += .5 * (u = l * t.beta.cdf(f, s + .5, r / 2) + h * t.beta.cdf(f, s + 1, r / 2)), s++;
                                return o ? 1 - a : a
                            }
                        }), t.extend(t.normal, {
                            pdf: function(t, n, r) {
                                return e.exp(-.5 * e.log(2 * e.PI) - e.log(r) - e.pow(t - n, 2) / (2 * r * r))
                            },
                            cdf: function(n, r, i) {
                                return .5 * (1 + t.erf((n - r) / e.sqrt(2 * i * i)))
                            },
                            inv: function(e, n, r) {
                                return -1.4142135623730951 * r * t.erfcinv(2 * e) + n
                            },
                            mean: function(t, e) {
                                return t
                            },
                            median: function(t, e) {
                                return t
                            },
                            mode: function(t, e) {
                                return t
                            },
                            sample: function(e, n) {
                                return t.randn() * n + e
                            },
                            variance: function(t, e) {
                                return e * e
                            }
                        }), t.extend(t.pareto, {
                            pdf: function(t, n, r) {
                                return t < n ? 0 : r * e.pow(n, r) / e.pow(t, r + 1)
                            },
                            cdf: function(t, n, r) {
                                return t < n ? 0 : 1 - e.pow(n / t, r)
                            },
                            inv: function(t, n, r) {
                                return n / e.pow(1 - t, 1 / r)
                            },
                            mean: function(t, n) {
                                if (!(n <= 1)) return n * e.pow(t, n) / (n - 1)
                            },
                            median: function(t, n) {
                                return t * (n * e.SQRT2)
                            },
                            mode: function(t, e) {
                                return t
                            },
                            variance: function(t, n) {
                                if (!(n <= 2)) return t * t * n / (e.pow(n - 1, 2) * (n - 2))
                            }
                        }), t.extend(t.studentt, {
                            pdf: function(n, r) {
                                return r = r > 1e100 ? 1e100 : r, 1 / (e.sqrt(r) * t.betafn(.5, r / 2)) * e.pow(1 + n * n / r, -(r + 1) / 2)
                            },
                            cdf: function(n, r) {
                                var i = r / 2;
                                return t.ibeta((n + e.sqrt(n * n + r)) / (2 * e.sqrt(n * n + r)), i, i)
                            },
                            inv: function(n, r) {
                                var i = t.ibetainv(2 * e.min(n, 1 - n), .5 * r, .5);
                                return i = e.sqrt(r * (1 - i) / i), n > .5 ? i : -i
                            },
                            mean: function(t) {
                                return t > 1 ? 0 : void 0
                            },
                            median: function(t) {
                                return 0
                            },
                            mode: function(t) {
                                return 0
                            },
                            sample: function(n) {
                                return t.randn() * e.sqrt(n / (2 * t.randg(n / 2)))
                            },
                            variance: function(t) {
                                return t > 2 ? t / (t - 2) : t > 1 ? 1 / 0 : void 0
                            }
                        }), t.extend(t.weibull, {
                            pdf: function(t, n, r) {
                                return t < 0 || n < 0 || r < 0 ? 0 : r / n * e.pow(t / n, r - 1) * e.exp(-e.pow(t / n, r))
                            },
                            cdf: function(t, n, r) {
                                return t < 0 ? 0 : 1 - e.exp(-e.pow(t / n, r))
                            },
                            inv: function(t, n, r) {
                                return n * e.pow(-e.log(1 - t), 1 / r)
                            },
                            mean: function(e, n) {
                                return e * t.gammafn(1 + 1 / n)
                            },
                            median: function(t, n) {
                                return t * e.pow(e.log(2), 1 / n)
                            },
                            mode: function(t, n) {
                                return n <= 1 ? 0 : t * e.pow((n - 1) / n, 1 / n)
                            },
                            sample: function(t, n) {
                                return t * e.pow(-e.log(e.random()), 1 / n)
                            },
                            variance: function(n, r) {
                                return n * n * t.gammafn(1 + 2 / r) - e.pow(t.weibull.mean(n, r), 2)
                            }
                        }), t.extend(t.uniform, {
                            pdf: function(t, e, n) {
                                return t < e || t > n ? 0 : 1 / (n - e)
                            },
                            cdf: function(t, e, n) {
                                return t < e ? 0 : t < n ? (t - e) / (n - e) : 1
                            },
                            inv: function(t, e, n) {
                                return e + t * (n - e)
                            },
                            mean: function(t, e) {
                                return .5 * (t + e)
                            },
                            median: function(e, n) {
                                return t.mean(e, n)
                            },
                            mode: function(t, e) {
                                throw new Error("mode is not yet implemented")
                            },
                            sample: function(t, n) {
                                return t / 2 + n / 2 + (n / 2 - t / 2) * (2 * e.random() - 1)
                            },
                            variance: function(t, n) {
                                return e.pow(n - t, 2) / 12
                            }
                        }), t.extend(t.binomial, {
                            pdf: function(n, r, i) {
                                return 0 === i || 1 === i ? r * i === n ? 1 : 0 : t.combination(r, n) * e.pow(i, n) * e.pow(1 - i, r - n)
                            },
                            cdf: function(e, n, r) {
                                var i = [],
                                    o = 0;
                                if (e < 0) return 0;
                                if (e < n) {
                                    for (; o <= e; o++) i[o] = t.binomial.pdf(o, n, r);
                                    return t.sum(i)
                                }
                                return 1
                            }
                        }), t.extend(t.negbin, {
                            pdf: function(n, r, i) {
                                return n === n >>> 0 && (n < 0 ? 0 : t.combination(n + r - 1, r - 1) * e.pow(1 - i, n) * e.pow(i, r))
                            },
                            cdf: function(e, n, r) {
                                var i = 0,
                                    o = 0;
                                if (e < 0) return 0;
                                for (; o <= e; o++) i += t.negbin.pdf(o, n, r);
                                return i
                            }
                        }), t.extend(t.hypgeom, {
                            pdf: function(n, r, i, o) {
                                if (n != n | 0) return !1;
                                if (n < 0 || n < i - (r - o)) return 0;
                                if (n > o || n > i) return 0;
                                if (2 * i > r) return 2 * o > r ? t.hypgeom.pdf(r - i - o + n, r, r - i, r - o) : t.hypgeom.pdf(o - n, r, r - i, o);
                                if (2 * o > r) return t.hypgeom.pdf(i - n, r, i, r - o);
                                if (i < o) return t.hypgeom.pdf(n, r, o, i);
                                for (var a = 1, u = 0, c = 0; c < n; c++) {
                                    for (; a > 1 && u < o;) a *= 1 - i / (r - u), u++;
                                    a *= (o - c) * (i - c) / ((c + 1) * (r - i - o + c + 1))
                                }
                                for (; u < o; u++) a *= 1 - i / (r - u);
                                return e.min(1, e.max(0, a))
                            },
                            cdf: function(n, r, i, o) {
                                if (n < 0 || n < i - (r - o)) return 0;
                                if (n >= o || n >= i) return 1;
                                if (2 * i > r) return 2 * o > r ? t.hypgeom.cdf(r - i - o + n, r, r - i, r - o) : 1 - t.hypgeom.cdf(o - n - 1, r, r - i, o);
                                if (2 * o > r) return 1 - t.hypgeom.cdf(i - n - 1, r, i, r - o);
                                if (i < o) return t.hypgeom.cdf(n, r, o, i);
                                for (var a = 1, u = 1, c = 0, f = 0; f < n; f++) {
                                    for (; a > 1 && c < o;) {
                                        var s = 1 - i / (r - c);
                                        u *= s, a *= s, c++
                                    }
                                    a += u *= (o - f) * (i - f) / ((f + 1) * (r - i - o + f + 1))
                                }
                                for (; c < o; c++) a *= 1 - i / (r - c);
                                return e.min(1, e.max(0, a))
                            }
                        }), t.extend(t.poisson, {
                            pdf: function(n, r) {
                                return r < 0 || n % 1 != 0 || n < 0 ? 0 : e.pow(r, n) * e.exp(-r) / t.factorial(n)
                            },
                            cdf: function(e, n) {
                                var r = [],
                                    i = 0;
                                if (e < 0) return 0;
                                for (; i <= e; i++) r.push(t.poisson.pdf(i, n));
                                return t.sum(r)
                            },
                            mean: function(t) {
                                return t
                            },
                            variance: function(t) {
                                return t
                            },
                            sample: function(t) {
                                var n = 1,
                                    r = 0,
                                    i = e.exp(-t);
                                do {
                                    r++, n *= e.random()
                                } while (n > i);
                                return r - 1
                            }
                        }), t.extend(t.triangular, {
                            pdf: function(t, e, n, r) {
                                return n <= e || r < e || r > n ? NaN : t < e || t > n ? 0 : t < r ? 2 * (t - e) / ((n - e) * (r - e)) : t === r ? 2 / (n - e) : 2 * (n - t) / ((n - e) * (n - r))
                            },
                            cdf: function(t, n, r, i) {
                                return r <= n || i < n || i > r ? NaN : t <= n ? 0 : t >= r ? 1 : t <= i ? e.pow(t - n, 2) / ((r - n) * (i - n)) : 1 - e.pow(r - t, 2) / ((r - n) * (r - i))
                            },
                            inv: function(t, n, r, i) {
                                return r <= n || i < n || i > r ? NaN : t <= (i - n) / (r - n) ? n + (r - n) * e.sqrt(t * ((i - n) / (r - n))) : n + (r - n) * (1 - e.sqrt((1 - t) * (1 - (i - n) / (r - n))))
                            },
                            mean: function(t, e, n) {
                                return (t + e + n) / 3
                            },
                            median: function(t, n, r) {
                                return r <= (t + n) / 2 ? n - e.sqrt((n - t) * (n - r)) / e.sqrt(2) : r > (t + n) / 2 ? t + e.sqrt((n - t) * (r - t)) / e.sqrt(2) : void 0
                            },
                            mode: function(t, e, n) {
                                return n
                            },
                            sample: function(t, n, r) {
                                var i = e.random();
                                return i < (r - t) / (n - t) ? t + e.sqrt(i * (n - t) * (r - t)) : n - e.sqrt((1 - i) * (n - t) * (n - r))
                            },
                            variance: function(t, e, n) {
                                return (t * t + e * e + n * n - t * e - t * n - e * n) / 18
                            }
                        }), t.extend(t.arcsine, {
                            pdf: function(t, n, r) {
                                return r <= n ? NaN : t <= n || t >= r ? 0 : 2 / e.PI * e.pow(e.pow(r - n, 2) - e.pow(2 * t - n - r, 2), -.5)
                            },
                            cdf: function(t, n, r) {
                                return t < n ? 0 : t < r ? 2 / e.PI * e.asin(e.sqrt((t - n) / (r - n))) : 1
                            },
                            inv: function(t, n, r) {
                                return n + (.5 - .5 * e.cos(e.PI * t)) * (r - n)
                            },
                            mean: function(t, e) {
                                return e <= t ? NaN : (t + e) / 2
                            },
                            median: function(t, e) {
                                return e <= t ? NaN : (t + e) / 2
                            },
                            mode: function(t, e) {
                                throw new Error("mode is not yet implemented")
                            },
                            sample: function(n, r) {
                                return (n + r) / 2 + (r - n) / 2 * e.sin(2 * e.PI * t.uniform.sample(0, 1))
                            },
                            variance: function(t, n) {
                                return n <= t ? NaN : e.pow(n - t, 2) / 8
                            }
                        }), t.extend(t.laplace, {
                            pdf: function(t, n, r) {
                                return r <= 0 ? 0 : e.exp(-e.abs(t - n) / r) / (2 * r)
                            },
                            cdf: function(t, n, r) {
                                return r <= 0 ? 0 : t < n ? .5 * e.exp((t - n) / r) : 1 - .5 * e.exp(-(t - n) / r)
                            },
                            mean: function(t, e) {
                                return t
                            },
                            median: function(t, e) {
                                return t
                            },
                            mode: function(t, e) {
                                return t
                            },
                            variance: function(t, e) {
                                return 2 * e * e
                            },
                            sample: function(t, n) {
                                var r = e.random() - .5;
                                return t - n * function(t) {
                                    return t / e.abs(t)
                                }(r) * e.log(1 - 2 * e.abs(r))
                            }
                        }), t.extend(t.tukey, {
                            cdf: function(r, i, o) {
                                var a = i,
                                    u = [.9894009349916499, .9445750230732326, .8656312023878318, .755404408355003, .6178762444026438, .45801677765722737, .2816035507792589, .09501250983763744],
                                    c = [.027152459411754096, .062253523938647894, .09515851168249279, .12462897125553388, .14959598881657674, .16915651939500254, .18260341504492358, .1894506104550685];
                                if (r <= 0) return 0;
                                if (o < 2 || a < 2) return NaN;
                                if (!Number.isFinite(r)) return 1;
                                if (o > 25e3) return n(r, 1, a);
                                var f, s = .5 * o,
                                    l = s * e.log(o) - o * e.log(2) - t.gammaln(s),
                                    h = s - 1,
                                    p = .25 * o;
                                f = o <= 100 ? 1 : o <= 800 ? .5 : o <= 5e3 ? .25 : .125, l += e.log(f);
                                for (var d = 0, v = 1; v <= 50; v++) {
                                    for (var y = 0, _ = (2 * v - 1) * f, g = 1; g <= 16; g++) {
                                        var b, m;
                                        8 < g ? (b = g - 8 - 1, m = l + h * e.log(_ + u[b] * f) - (u[b] * f + _) * p) : (b = g - 1, m = l + h * e.log(_ - u[b] * f) + (u[b] * f - _) * p);
                                        if (m >= -30) {
                                            y += n(8 < g ? r * e.sqrt(.5 * (u[b] * f + _)) : r * e.sqrt(.5 * (-u[b] * f + _)), 1, a) * c[b] * e.exp(m)
                                        }
                                    }
                                    if (v * f >= 1 && y <= 1e-14) break;
                                    d += y
                                }
                                if (y > 1e-14) throw new Error("tukey.cdf failed to converge");
                                return d > 1 && (d = 1), d
                            },
                            inv: function(n, r, i) {
                                var o = r;
                                if (i < 2 || o < 2) return NaN;
                                if (n < 0 || n > 1) return NaN;
                                if (0 === n) return 0;
                                if (1 === n) return 1 / 0;
                                var a, u = function(t, n, r) {
                                        var i = .5 - .5 * t,
                                            o = e.sqrt(e.log(1 / (i * i))),
                                            a = o + ((((-453642210148e-16 * o - .204231210125) * o - .342242088547) * o - 1) * o + .322232421088) / ((((.0038560700634 * o + .10353775285) * o + .531103462366) * o + .588581570495) * o + .099348462606);
                                        r < 120 && (a += (a * a * a + a) / r / 4);
                                        var u = .8832 - .2368 * a;
                                        return r < 120 && (u += -1.214 / r + 1.208 * a / r), a * (u * e.log(n - 1) + 1.4142)
                                    }(n, o, i),
                                    c = t.tukey.cdf(u, r, i) - n;
                                a = c > 0 ? e.max(0, u - 1) : u + 1;
                                for (var f, s = t.tukey.cdf(a, r, i) - n, l = 1; l < 50; l++) {
                                    f = a - s * (a - u) / (s - c), c = s, u = a, f < 0 && (f = 0, s = -n), s = t.tukey.cdf(f, r, i) - n, a = f;
                                    if (e.abs(a - u) < 1e-4) return f
                                }
                                throw new Error("tukey.inv failed to converge")
                            }
                        })
                    }(t, Math),
                    function(t, e) {
                        function n(e) {
                            return a(e) || e instanceof t
                        }
                        var o = Array.prototype.push,
                            a = t.utils.isArray;
                        t.extend({
                                add: function(e, r) {
                                    return n(r) ? (n(r[0]) || (r = [r]), t.map(e, function(t, e, n) {
                                        return t + r[e][n]
                                    })) : t.map(e, function(t) {
                                        return t + r
                                    })
                                },
                                subtract: function(e, r) {
                                    return n(r) ? (n(r[0]) || (r = [r]), t.map(e, function(t, e, n) {
                                        return t - r[e][n] || 0
                                    })) : t.map(e, function(t) {
                                        return t - r
                                    })
                                },
                                divide: function(e, r) {
                                    return n(r) ? (n(r[0]) || (r = [r]), t.multiply(e, t.inv(r))) : t.map(e, function(t) {
                                        return t / r
                                    })
                                },
                                multiply: function(e, r) {
                                    var i, o, a, u, c, f, s, l;
                                    if (void 0 === e.length && void 0 === r.length) return e * r;
                                    if (c = e.length, f = e[0].length, s = t.zeros(c, a = n(r) ? r[0].length : f), l = 0, n(r)) {
                                        for (; l < a; l++)
                                            for (i = 0; i < c; i++) {
                                                for (u = 0, o = 0; o < f; o++) u += e[i][o] * r[o][l];
                                                s[i][l] = u
                                            }
                                        return 1 === c && 1 === l ? s[0][0] : s
                                    }
                                    return t.map(e, function(t) {
                                        return t * r
                                    })
                                },
                                outer: function(e, n) {
                                    return t.multiply(e.map(function(t) {
                                        return [t]
                                    }), [n])
                                },
                                dot: function(e, r) {
                                    n(e[0]) || (e = [e]), n(r[0]) || (r = [r]);
                                    for (var i, o, a = 1 === e[0].length && 1 !== e.length ? t.transpose(e) : e, u = 1 === r[0].length && 1 !== r.length ? t.transpose(r) : r, c = [], f = 0, s = a.length, l = a[0].length; f < s; f++) {
                                        for (c[f] = [], i = 0, o = 0; o < l; o++) i += a[f][o] * u[f][o];
                                        c[f] = i
                                    }
                                    return 1 === c.length ? c[0] : c
                                },
                                pow: function(n, r) {
                                    return t.map(n, function(t) {
                                        return e.pow(t, r)
                                    })
                                },
                                exp: function(n) {
                                    return t.map(n, function(t) {
                                        return e.exp(t)
                                    })
                                },
                                log: function(n) {
                                    return t.map(n, function(t) {
                                        return e.log(t)
                                    })
                                },
                                abs: function(n) {
                                    return t.map(n, function(t) {
                                        return e.abs(t)
                                    })
                                },
                                norm: function(t, r) {
                                    var i = 0,
                                        o = 0;
                                    for (isNaN(r) && (r = 2), n(t[0]) && (t = t[0]); o < t.length; o++) i += e.pow(e.abs(t[o]), r);
                                    return e.pow(i, 1 / r)
                                },
                                angle: function(n, r) {
                                    return e.acos(t.dot(n, r) / (t.norm(n) * t.norm(r)))
                                },
                                aug: function(t, e) {
                                    for (var n = [], r = 0; r < t.length; r++) n.push(t[r].slice());
                                    for (r = 0; r < n.length; r++) o.apply(n[r], e[r]);
                                    return n
                                },
                                inv: function(e) {
                                    for (var n, r = e.length, i = e[0].length, o = t.identity(r, i), a = t.gauss_jordan(e, o), u = [], c = 0; c < r; c++)
                                        for (u[c] = [], n = i; n < a[0].length; n++) u[c][n - i] = a[c][n];
                                    return u
                                },
                                det: function(t) {
                                    var e, n = t.length,
                                        r = 2 * n,
                                        i = new Array(r),
                                        o = n - 1,
                                        a = r - 1,
                                        u = o - n + 1,
                                        c = a,
                                        f = 0,
                                        s = 0;
                                    if (2 === n) return t[0][0] * t[1][1] - t[0][1] * t[1][0];
                                    for (; f < r; f++) i[f] = 1;
                                    for (f = 0; f < n; f++) {
                                        for (e = 0; e < n; e++) i[u < 0 ? u + n : u] *= t[f][e], i[c < n ? c + n : c] *= t[f][e], u++, c--;
                                        u = --o - n + 1, c = --a
                                    }
                                    for (f = 0; f < n; f++) s += i[f];
                                    for (; f < r; f++) s -= i[f];
                                    return s
                                },
                                gauss_elimination: function(n, r) {
                                    var i, o, a, u, c = 0,
                                        f = 0,
                                        s = n.length,
                                        l = n[0].length,
                                        h = 1,
                                        p = 0,
                                        d = [];
                                    i = (n = t.aug(n, r))[0].length;
                                    for (c = 0; c < s; c++) {
                                        for (o = n[c][c], f = c, u = c + 1; u < l; u++) o < e.abs(n[u][c]) && (o = n[u][c], f = u);
                                        if (f != c)
                                            for (u = 0; u < i; u++) a = n[c][u], n[c][u] = n[f][u], n[f][u] = a;
                                        for (f = c + 1; f < s; f++)
                                            for (h = n[f][c] / n[c][c], u = c; u < i; u++) n[f][u] = n[f][u] - h * n[c][u]
                                    }
                                    for (c = s - 1; c >= 0; c--) {
                                        for (p = 0, f = c + 1; f <= s - 1; f++) p += d[f] * n[c][f];
                                        d[c] = (n[c][i - 1] - p) / n[c][c]
                                    }
                                    return d
                                },
                                gauss_jordan: function(n, r) {
                                    for (var i = t.aug(n, r), o = i.length, a = i[0].length, u = 0, c = 0; c < o; c++) {
                                        for (var f = c, s = c + 1; s < o; s++) e.abs(i[s][c]) > e.abs(i[f][c]) && (f = s);
                                        var l = i[c];
                                        i[c] = i[f], i[f] = l;
                                        for (s = c + 1; s < o; s++) {
                                            u = i[s][c] / i[c][c];
                                            for (var h = c; h < a; h++) i[s][h] -= i[c][h] * u
                                        }
                                    }
                                    for (c = o - 1; c >= 0; c--) {
                                        u = i[c][c];
                                        for (s = 0; s < c; s++)
                                            for (h = a - 1; h > c - 1; h--) i[s][h] -= i[c][h] * i[s][c] / u;
                                        i[c][c] /= u;
                                        for (h = o; h < a; h++) i[c][h] /= u
                                    }
                                    return i
                                },
                                triaUpSolve: function(e, n) {
                                    var r, i = e[0].length,
                                        o = t.zeros(1, i)[0],
                                        a = !1;
                                    return void 0 != n[0].length && (n = n.map(function(t) {
                                        return t[0]
                                    }), a = !0), t.arange(i - 1, -1, -1).forEach(function(a) {
                                        r = t.arange(a + 1, i).map(function(t) {
                                            return o[t] * e[a][t]
                                        }), o[a] = (n[a] - t.sum(r)) / e[a][a]
                                    }), a ? o.map(function(t) {
                                        return [t]
                                    }) : o
                                },
                                triaLowSolve: function(e, n) {
                                    var r, i = e[0].length,
                                        o = t.zeros(1, i)[0],
                                        a = !1;
                                    return void 0 != n[0].length && (n = n.map(function(t) {
                                        return t[0]
                                    }), a = !0), t.arange(i).forEach(function(i) {
                                        r = t.arange(i).map(function(t) {
                                            return e[i][t] * o[t]
                                        }), o[i] = (n[i] - t.sum(r)) / e[i][i]
                                    }), a ? o.map(function(t) {
                                        return [t]
                                    }) : o
                                },
                                lu: function(e) {
                                    var n, r = e.length,
                                        o = t.identity(r),
                                        a = t.zeros(e.length, e[0].length);
                                    return t.arange(r).forEach(function(t) {
                                        a[0][t] = e[0][t]
                                    }), t.arange(1, r).forEach(function(u) {
                                        t.arange(u).forEach(function(r) {
                                            n = t.arange(r).map(function(t) {
                                                return o[u][t] * a[t][r]
                                            }), o[u][r] = (e[u][r] - t.sum(n)) / a[r][r]
                                        }), t.arange(u, r).forEach(function(r) {
                                            n = t.arange(u).map(function(t) {
                                                return o[u][t] * a[t][r]
                                            }), a[u][r] = e[i][r] - t.sum(n)
                                        })
                                    }), [o, a]
                                },
                                cholesky: function(n) {
                                    var r, i = n.length,
                                        o = t.zeros(n.length, n[0].length);
                                    return t.arange(i).forEach(function(a) {
                                        r = t.arange(a).map(function(t) {
                                            return e.pow(o[a][t], 2)
                                        }), o[a][a] = e.sqrt(n[a][a] - t.sum(r)), t.arange(a + 1, i).forEach(function(e) {
                                            r = t.arange(a).map(function(t) {
                                                return o[a][t] * o[e][t]
                                            }), o[e][a] = (n[a][e] - t.sum(r)) / o[a][a]
                                        })
                                    }), o
                                },
                                gauss_jacobi: function(n, r, i, o) {
                                    for (var a, u, c, f, s = 0, l = 0, h = n.length, p = [], d = [], v = []; s < h; s++)
                                        for (p[s] = [], d[s] = [], v[s] = [], l = 0; l < h; l++) s > l ? (p[s][l] = n[s][l], d[s][l] = v[s][l] = 0) : s < l ? (d[s][l] = n[s][l], p[s][l] = v[s][l] = 0) : (v[s][l] = n[s][l], p[s][l] = d[s][l] = 0);
                                    for (c = t.multiply(t.multiply(t.inv(v), t.add(p, d)), -1), u = t.multiply(t.inv(v), r), a = i, f = t.add(t.multiply(c, i), u), s = 2; e.abs(t.norm(t.subtract(f, a))) > o;) a = f, f = t.add(t.multiply(c, a), u), s++;
                                    return f
                                },
                                gauss_seidel: function(n, r, i, o) {
                                    for (var a, u, c, f, s, l = 0, h = n.length, p = [], d = [], v = []; l < h; l++)
                                        for (p[l] = [], d[l] = [], v[l] = [], a = 0; a < h; a++) l > a ? (p[l][a] = n[l][a], d[l][a] = v[l][a] = 0) : l < a ? (d[l][a] = n[l][a], p[l][a] = v[l][a] = 0) : (v[l][a] = n[l][a], p[l][a] = d[l][a] = 0);
                                    for (f = t.multiply(t.multiply(t.inv(t.add(v, p)), d), -1), c = t.multiply(t.inv(t.add(v, p)), r), u = i, s = t.add(t.multiply(f, i), c), l = 2; e.abs(t.norm(t.subtract(s, u))) > o;) u = s, s = t.add(t.multiply(f, u), c), l += 1;
                                    return s
                                },
                                SOR: function(n, r, i, o, a) {
                                    for (var u, c, f, s, l, h = 0, p = n.length, d = [], v = [], y = []; h < p; h++)
                                        for (d[h] = [], v[h] = [], y[h] = [], u = 0; u < p; u++) h > u ? (d[h][u] = n[h][u], v[h][u] = y[h][u] = 0) : h < u ? (v[h][u] = n[h][u], d[h][u] = y[h][u] = 0) : (y[h][u] = n[h][u], d[h][u] = v[h][u] = 0);
                                    for (s = t.multiply(t.inv(t.add(y, t.multiply(d, a))), t.subtract(t.multiply(y, 1 - a), t.multiply(v, a))), f = t.multiply(t.multiply(t.inv(t.add(y, t.multiply(d, a))), r), a), c = i, l = t.add(t.multiply(s, i), f), h = 2; e.abs(t.norm(t.subtract(l, c))) > o;) c = l, l = t.add(t.multiply(s, c), f), h++;
                                    return l
                                },
                                householder: function(n) {
                                    for (var r, i, o, a, u = n.length, c = n[0].length, f = 0, s = [], l = []; f < u - 1; f++) {
                                        for (r = 0, a = f + 1; a < c; a++) r += n[a][f] * n[a][f];
                                        for (r = (n[f + 1][f] > 0 ? -1 : 1) * e.sqrt(r), i = e.sqrt((r * r - n[f + 1][f] * r) / 2), (s = t.zeros(u, 1))[f + 1][0] = (n[f + 1][f] - r) / (2 * i), o = f + 2; o < u; o++) s[o][0] = n[o][f] / (2 * i);
                                        l = t.subtract(t.identity(u, c), t.multiply(t.multiply(s, t.transpose(s)), 2)), n = t.multiply(l, t.multiply(n, l))
                                    }
                                    return n
                                },
                                QR: function() {
                                    var n = t.sum,
                                        i = t.arange;
                                    return function(o) {
                                        var a = o.length,
                                            u = o[0].length;
                                        o = t.copy(o), r = t.zeros(u, u);
                                        var c, f, s;
                                        for (f = 0; f < u; f++) {
                                            for (r[f][f] = e.sqrt(n(i(a).map(function(t) {
                                                return o[t][f] * o[t][f]
                                            }))), c = 0; c < a; c++) o[c][f] = o[c][f] / r[f][f];
                                            for (s = f + 1; s < u; s++)
                                                for (r[f][s] = n(i(a).map(function(t) {
                                                    return o[t][f] * o[t][s]
                                                })), c = 0; c < a; c++) o[c][s] = o[c][s] - o[c][f] * r[f][s]
                                        }
                                        return [o, r]
                                    }
                                }(),
                                lstsq: function(e, n) {
                                    return function(e, n) {
                                        var r = !1;
                                        void 0 === n[0].length && (n = n.map(function(t) {
                                            return [t]
                                        }), r = !0);
                                        var i = t.QR(e),
                                            o = i[0],
                                            a = i[1],
                                            u = e[0].length,
                                            c = t.slice(o, {
                                                col: {
                                                    end: u
                                                }
                                            }),
                                            f = function(e) {
                                                var n = (e = t.copy(e)).length,
                                                    r = t.identity(n);
                                                return t.arange(n - 1, -1, -1).forEach(function(n) {
                                                    t.sliceAssign(r, {
                                                        row: n
                                                    }, t.divide(t.slice(r, {
                                                        row: n
                                                    }), e[n][n])), t.sliceAssign(e, {
                                                        row: n
                                                    }, t.divide(t.slice(e, {
                                                        row: n
                                                    }), e[n][n])), t.arange(n).forEach(function(i) {
                                                        var o = t.multiply(e[i][n], -1),
                                                            a = t.slice(e, {
                                                                row: i
                                                            }),
                                                            u = t.multiply(t.slice(e, {
                                                                row: n
                                                            }), o);
                                                        t.sliceAssign(e, {
                                                            row: i
                                                        }, t.add(a, u));
                                                        var c = t.slice(r, {
                                                                row: i
                                                            }),
                                                            f = t.multiply(t.slice(r, {
                                                                row: n
                                                            }), o);
                                                        t.sliceAssign(r, {
                                                            row: i
                                                        }, t.add(c, f))
                                                    })
                                                }), r
                                            }(t.slice(a, {
                                                row: {
                                                    end: u
                                                }
                                            })),
                                            s = t.transpose(c);
                                        void 0 === s[0].length && (s = [s]);
                                        var l = t.multiply(t.multiply(f, s), n);
                                        return void 0 === l.length && (l = [
                                            [l]
                                        ]), r ? l.map(function(t) {
                                            return t[0]
                                        }) : l
                                    }
                                }(),
                                jacobi: function(n) {
                                    for (var r, i, o, a, u, c, f = 1, s = n.length, l = t.identity(s, s), h = []; 1 === f;) {
                                        0, a = n[0][1], i = 0, o = 1;
                                        for (var p = 0; p < s; p++)
                                            for (r = 0; r < s; r++) p != r && a < e.abs(n[p][r]) && (a = e.abs(n[p][r]), i = p, o = r);
                                        u = n[i][i] === n[o][o] ? n[i][o] > 0 ? e.PI / 4 : -e.PI / 4 : e.atan(2 * n[i][o] / (n[i][i] - n[o][o])) / 2, (c = t.identity(s, s))[i][i] = e.cos(u), c[i][o] = -e.sin(u), c[o][i] = e.sin(u), c[o][o] = e.cos(u), l = t.multiply(l, c), n = t.multiply(t.multiply(t.inv(c), n), c), f = 0;
                                        for (p = 1; p < s; p++)
                                            for (r = 1; r < s; r++) p != r && e.abs(n[p][r]) > .001 && (f = 1)
                                    }
                                    for (p = 0; p < s; p++) h.push(n[p][p]);
                                    return [l, h]
                                },
                                rungekutta: function(t, e, n, r, i, o) {
                                    var a, u, c;
                                    if (2 === o)
                                        for (; r <= n;) i = i + ((a = e * t(r, i)) + (u = e * t(r + e, i + a))) / 2, r += e;
                                    if (4 === o)
                                        for (; r <= n;) i = i + ((a = e * t(r, i)) + 2 * (u = e * t(r + e / 2, i + a / 2)) + 2 * (c = e * t(r + e / 2, i + u / 2)) + e * t(r + e, i + c)) / 6, r += e;
                                    return i
                                },
                                romberg: function(t, n, r, i) {
                                    for (var o, a, u, c, f, s = 0, l = (r - n) / 2, h = [], p = [], d = []; s < i / 2;) {
                                        for (f = t(n), u = n, c = 0; u <= r; u += l, c++) h[c] = u;
                                        for (o = h.length, u = 1; u < o - 1; u++) f += (u % 2 != 0 ? 4 : 2) * t(h[u]);
                                        f = l / 3 * (f + t(r)), d[s] = f, l /= 2, s++
                                    }
                                    for (a = d.length, o = 1; 1 !== a;) {
                                        for (u = 0; u < a - 1; u++) p[u] = (e.pow(4, o) * d[u + 1] - d[u]) / (e.pow(4, o) - 1);
                                        a = p.length, d = p, p = [], o++
                                    }
                                    return d
                                },
                                richardson: function(t, n, r, i) {
                                    function o(t, e) {
                                        for (var n, r = 0, i = t.length; r < i; r++) t[r] === e && (n = r);
                                        return n
                                    }
                                    t.length;
                                    for (var a, u, c, f, s, l = e.abs(r - t[o(t, r) + 1]), h = 0, p = [], d = []; i >= l;) a = o(t, r + i), u = o(t, r), p[h] = (n[a] - 2 * n[u] + n[2 * u - a]) / (i * i), i /= 2, h++;
                                    for (f = p.length, c = 1; 1 != f;) {
                                        for (s = 0; s < f - 1; s++) d[s] = (e.pow(4, c) * p[s + 1] - p[s]) / (e.pow(4, c) - 1);
                                        f = d.length, p = d, d = [], c++
                                    }
                                    return p
                                },
                                simpson: function(t, e, n, r) {
                                    for (var i, o = (n - e) / r, a = t(e), u = [], c = e, f = 0, s = 1; c <= n; c += o, f++) u[f] = c;
                                    for (i = u.length; s < i - 1; s++) a += (s % 2 != 0 ? 4 : 2) * t(u[s]);
                                    return o / 3 * (a + t(n))
                                },
                                hermite: function(t, e, n, r) {
                                    for (var i, o = t.length, a = 0, u = 0, c = [], f = [], s = [], l = []; u < o; u++) {
                                        for (c[u] = 1, i = 0; i < o; i++) u != i && (c[u] *= (r - t[i]) / (t[u] - t[i]));
                                        for (f[u] = 0, i = 0; i < o; i++) u != i && (f[u] += 1 / (t[u] - t[i]));
                                        s[u] = (1 - 2 * (r - t[u]) * f[u]) * (c[u] * c[u]), l[u] = (r - t[u]) * (c[u] * c[u]), a += s[u] * e[u] + l[u] * n[u]
                                    }
                                    return a
                                },
                                lagrange: function(t, e, n) {
                                    for (var r, i, o = 0, a = 0, u = t.length; a < u; a++) {
                                        for (i = e[a], r = 0; r < u; r++) a != r && (i *= (n - t[r]) / (t[a] - t[r]));
                                        o += i
                                    }
                                    return o
                                },
                                cubic_spline: function(e, n, r) {
                                    for (var i, o = e.length, a = 0, u = [], c = [], f = [], s = [], l = [], h = [], p = []; a < o - 1; a++) l[a] = e[a + 1] - e[a];
                                    f[0] = 0;
                                    for (a = 1; a < o - 1; a++) f[a] = 3 / l[a] * (n[a + 1] - n[a]) - 3 / l[a - 1] * (n[a] - n[a - 1]);
                                    for (a = 1; a < o - 1; a++) u[a] = [], c[a] = [], u[a][a - 1] = l[a - 1], u[a][a] = 2 * (l[a - 1] + l[a]), u[a][a + 1] = l[a], c[a][0] = f[a];
                                    for (s = t.multiply(t.inv(u), c), i = 0; i < o - 1; i++) h[i] = (n[i + 1] - n[i]) / l[i] - l[i] * (s[i + 1][0] + 2 * s[i][0]) / 3, p[i] = (s[i + 1][0] - s[i][0]) / (3 * l[i]);
                                    for (i = 0; i < o && !(e[i] > r); i++);
                                    return i -= 1, n[i] + (r - e[i]) * h[i] + t.sq(r - e[i]) * s[i] + (r - e[i]) * t.sq(r - e[i]) * p[i]
                                },
                                gauss_quadrature: function() {
                                    throw new Error("gauss_quadrature not yet implemented")
                                },
                                PCA: function(e) {
                                    var n, r, i = e.length,
                                        o = e[0].length,
                                        a = 0,
                                        u = [],
                                        c = [],
                                        f = [],
                                        s = [],
                                        l = [],
                                        h = [],
                                        p = [],
                                        d = [],
                                        v = [],
                                        y = [];
                                    for (a = 0; a < i; a++) u[a] = t.sum(e[a]) / o;
                                    for (a = 0; a < o; a++)
                                        for (p[a] = [], n = 0; n < i; n++) p[a][n] = e[n][a] - u[n];
                                    p = t.transpose(p);
                                    for (a = 0; a < i; a++)
                                        for (d[a] = [], n = 0; n < i; n++) d[a][n] = t.dot([p[a]], [p[n]]) / (o - 1);
                                    v = (f = t.jacobi(d))[0], c = f[1], y = t.transpose(v);
                                    for (a = 0; a < c.length; a++)
                                        for (n = a; n < c.length; n++) c[a] < c[n] && (r = c[a], c[a] = c[n], c[n] = r, s = y[a], y[a] = y[n], y[n] = s);
                                    h = t.transpose(p);
                                    for (a = 0; a < i; a++)
                                        for (l[a] = [], n = 0; n < h.length; n++) l[a][n] = t.dot([y[a]], [h[n]]);
                                    return [e, c, y, l]
                                }
                            }),
                            function(e) {
                                for (var n = 0; n < e.length; n++)! function(e) {
                                    t.fn[e] = function(n, r) {
                                        var i = this;
                                        return r ? (setTimeout(function() {
                                            r.call(i, t.fn[e].call(i, n))
                                        }, 15), this) : "number" == typeof t[e](this, n) ? t[e](this, n) : t(t[e](this, n))
                                    }
                                }(e[n])
                            }("add divide multiply subtract dot pow exp log abs norm angle".split(" "))
                    }(t, Math),
                    function(t, e) {
                        function n(t, n, r, i) {
                            if (t > 1 || r > 1 || t <= 0 || r <= 0) throw new Error("Proportions should be greater than 0 and less than 1");
                            var o = (t * n + r * i) / (n + i);
                            return (t - r) / e.sqrt(o * (1 - o) * (1 / n + 1 / i))
                        }
                        var r = [].slice,
                            i = t.utils.isNumber,
                            o = t.utils.isArray;
                        t.extend({
                            zscore: function() {
                                var e = r.call(arguments);
                                return i(e[1]) ? (e[0] - e[1]) / e[2] : (e[0] - t.mean(e[1])) / t.stdev(e[1], e[2])
                            },
                            ztest: function() {
                                var n, i = r.call(arguments);
                                return o(i[1]) ? (n = t.zscore(i[0], i[1], i[3]), 1 === i[2] ? t.normal.cdf(-e.abs(n), 0, 1) : 2 * t.normal.cdf(-e.abs(n), 0, 1)) : i.length > 2 ? (n = t.zscore(i[0], i[1], i[2]), 1 === i[3] ? t.normal.cdf(-e.abs(n), 0, 1) : 2 * t.normal.cdf(-e.abs(n), 0, 1)) : (n = i[0], 1 === i[1] ? t.normal.cdf(-e.abs(n), 0, 1) : 2 * t.normal.cdf(-e.abs(n), 0, 1))
                            }
                        }), t.extend(t.fn, {
                            zscore: function(t, e) {
                                return (t - this.mean()) / this.stdev(e)
                            },
                            ztest: function(n, r, i) {
                                var o = e.abs(this.zscore(n, i));
                                return 1 === r ? t.normal.cdf(-o, 0, 1) : 2 * t.normal.cdf(-o, 0, 1)
                            }
                        }), t.extend({
                            tscore: function() {
                                var n = r.call(arguments);
                                return 4 === n.length ? (n[0] - n[1]) / (n[2] / e.sqrt(n[3])) : (n[0] - t.mean(n[1])) / (t.stdev(n[1], !0) / e.sqrt(n[1].length))
                            },
                            ttest: function() {
                                var n, o = r.call(arguments);
                                return 5 === o.length ? (n = e.abs(t.tscore(o[0], o[1], o[2], o[3])), 1 === o[4] ? t.studentt.cdf(-n, o[3] - 1) : 2 * t.studentt.cdf(-n, o[3] - 1)) : i(o[1]) ? (n = e.abs(o[0]), 1 == o[2] ? t.studentt.cdf(-n, o[1] - 1) : 2 * t.studentt.cdf(-n, o[1] - 1)) : (n = e.abs(t.tscore(o[0], o[1])), 1 == o[2] ? t.studentt.cdf(-n, o[1].length - 1) : 2 * t.studentt.cdf(-n, o[1].length - 1))
                            }
                        }), t.extend(t.fn, {
                            tscore: function(t) {
                                return (t - this.mean()) / (this.stdev(!0) / e.sqrt(this.cols()))
                            },
                            ttest: function(n, r) {
                                return 1 === r ? 1 - t.studentt.cdf(e.abs(this.tscore(n)), this.cols() - 1) : 2 * t.studentt.cdf(-e.abs(this.tscore(n)), this.cols() - 1)
                            }
                        }), t.extend({
                            anovafscore: function() {
                                var n, i, o, a, u, c, f, s = r.call(arguments);
                                if (1 === s.length) {
                                    u = new Array(s[0].length);
                                    for (var l = 0; l < s[0].length; l++) u[l] = s[0][l];
                                    s = u
                                }
                                if (2 === s.length) return t.variance(s[0]) / t.variance(s[1]);
                                i = new Array;
                                for (l = 0; l < s.length; l++) i = i.concat(s[l]);
                                o = t.mean(i), n = 0;
                                for (l = 0; l < s.length; l++) n += s[l].length * e.pow(t.mean(s[l]) - o, 2);
                                n /= s.length - 1, c = 0;
                                for (l = 0; l < s.length; l++)
                                    for (a = t.mean(s[l]), f = 0; f < s[l].length; f++) c += e.pow(s[l][f] - a, 2);
                                return c /= i.length - s.length, n / c
                            },
                            anovaftest: function() {
                                var e, n, o, a = r.call(arguments);
                                if (i(a[0])) return 1 - t.centralF.cdf(a[0], a[1], a[2]);
                                anovafscore = t.anovafscore(a), e = a.length - 1, o = 0;
                                for (var u = 0; u < a.length; u++) o += a[u].length;
                                return n = o - e - 1, 1 - t.centralF.cdf(anovafscore, e, n)
                            },
                            ftest: function(e, n, r) {
                                return 1 - t.centralF.cdf(e, n, r)
                            }
                        }), t.extend(t.fn, {
                            anovafscore: function() {
                                return t.anovafscore(this.toArray())
                            },
                            anovaftes: function() {
                                for (var e = 0, n = 0; n < this.length; n++) e += this[n].length;
                                return t.ftest(this.anovafscore(), this.length - 1, e - this.length)
                            }
                        }), t.extend({
                            qscore: function() {
                                var n, o, a, u, c, f = r.call(arguments);
                                return i(f[0]) ? (n = f[0], o = f[1], a = f[2], u = f[3], c = f[4]) : (n = t.mean(f[0]), o = t.mean(f[1]), a = f[0].length, u = f[1].length, c = f[2]), e.abs(n - o) / (c * e.sqrt((1 / a + 1 / u) / 2))
                            },
                            qtest: function() {
                                var e, n = r.call(arguments);
                                3 === n.length ? (e = n[0], n = n.slice(1)) : 7 === n.length ? (e = t.qscore(n[0], n[1], n[2], n[3], n[4]), n = n.slice(5)) : (e = t.qscore(n[0], n[1], n[2]), n = n.slice(3));
                                var i = n[0],
                                    o = n[1];
                                return 1 - t.tukey.cdf(e, o, i - o)
                            },
                            tukeyhsd: function(e) {
                                for (var n = t.pooledstdev(e), r = e.map(function(e) {
                                    return t.mean(e)
                                }), i = e.reduce(function(t, e) {
                                    return t + e.length
                                }, 0), o = [], a = 0; a < e.length; ++a)
                                    for (var u = a + 1; u < e.length; ++u) {
                                        var c = t.qtest(r[a], r[u], e[a].length, e[u].length, n, i, e.length);
                                        o.push([
                                            [a, u], c
                                        ])
                                    }
                                return o
                            }
                        }), t.extend({
                            normalci: function() {
                                var n, i = r.call(arguments),
                                    o = new Array(2);
                                return n = 4 === i.length ? e.abs(t.normal.inv(i[1] / 2, 0, 1) * i[2] / e.sqrt(i[3])) : e.abs(t.normal.inv(i[1] / 2, 0, 1) * t.stdev(i[2]) / e.sqrt(i[2].length)), o[0] = i[0] - n, o[1] = i[0] + n, o
                            },
                            tci: function() {
                                var n, i = r.call(arguments),
                                    o = new Array(2);
                                return n = 4 === i.length ? e.abs(t.studentt.inv(i[1] / 2, i[3] - 1) * i[2] / e.sqrt(i[3])) : e.abs(t.studentt.inv(i[1] / 2, i[2].length - 1) * t.stdev(i[2], !0) / e.sqrt(i[2].length)), o[0] = i[0] - n, o[1] = i[0] + n, o
                            },
                            significant: function(t, e) {
                                return t < e
                            }
                        }), t.extend(t.fn, {
                            normalci: function(e, n) {
                                return t.normalci(e, n, this.toArray())
                            },
                            tci: function(e, n) {
                                return t.tci(e, n, this.toArray())
                            }
                        }), t.extend(t.fn, {
                            oneSidedDifferenceOfProportions: function(e, r, i, o) {
                                var a = n(e, r, i, o);
                                return t.ztest(a, 1)
                            },
                            twoSidedDifferenceOfProportions: function(e, r, i, o) {
                                var a = n(e, r, i, o);
                                return t.ztest(a, 2)
                            }
                        })
                    }(t, Math), t.models = function() {
                        function e(t, e) {
                            return n(t, e)
                        }

                        function e(e) {
                            var r = e[0].length;
                            return t.arange(r).map(function(i) {
                                var o = t.arange(r).filter(function(t) {
                                    return t !== i
                                });
                                return n(t.col(e, i).map(function(t) {
                                    return t[0]
                                }), t.col(e, o))
                            })
                        }

                        function n(e, n) {
                            var r = e.length,
                                i = n[0].length - 1,
                                o = r - i - 1,
                                a = t.lstsq(n, e),
                                u = t.multiply(n, a.map(function(t) {
                                    return [t]
                                })).map(function(t) {
                                    return t[0]
                                }),
                                c = t.subtract(e, u),
                                f = t.mean(e),
                                s = t.sum(u.map(function(t) {
                                    return Math.pow(t - f, 2)
                                })),
                                l = t.sum(e.map(function(t, e) {
                                    return Math.pow(t - u[e], 2)
                                })),
                                h = s + l;
                            return {
                                exog: n,
                                endog: e,
                                nobs: r,
                                df_model: i,
                                df_resid: o,
                                coef: a,
                                predict: u,
                                resid: c,
                                ybar: f,
                                SST: h,
                                SSE: s,
                                SSR: l,
                                R2: s / h
                            }
                        }
                        return {
                            ols: function(r, i) {
                                var o = n(r, i),
                                    a = function(n) {
                                        var r = e(n.exog),
                                            i = Math.sqrt(n.SSR / n.df_resid),
                                            o = r.map(function(t) {
                                                var e = t.SST,
                                                    n = t.R2;
                                                return i / Math.sqrt(e * (1 - n))
                                            }),
                                            a = n.coef.map(function(t, e) {
                                                return (t - 0) / o[e]
                                            }),
                                            u = a.map(function(e) {
                                                var r = t.studentt.cdf(e, n.df_resid);
                                                return 2 * (r > .5 ? 1 - r : r)
                                            }),
                                            c = t.studentt.inv(.975, n.df_resid),
                                            f = n.coef.map(function(t, e) {
                                                var n = c * o[e];
                                                return [t - n, t + n]
                                            });
                                        return {
                                            se: o,
                                            t: a,
                                            p: u,
                                            sigmaHat: i,
                                            interval95: f
                                        }
                                    }(o),
                                    u = function(e) {
                                        var n = e.R2 / e.df_model / ((1 - e.R2) / e.df_resid);
                                        return {
                                            F_statistic: n,
                                            pvalue: 1 - function(e, n, r) {
                                                return t.beta.cdf(e / (r / n + e), n / 2, r / 2)
                                            }(n, e.df_model, e.df_resid)
                                        }
                                    }(o),
                                    c = 1 - (1 - o.R2) * ((o.nobs - 1) / o.df_resid);
                                return o.t = a, o.f = u, o.adjust_R2 = c, o
                            }
                        }
                    }(), t.jStat = t, t
            })
        },
        function(t, e) {
            var n;
            n = function() {
                return this
            }();
            try {
                n = n || Function("return this")() || (0, eval)("this")
            } catch (t) {
                "object" == typeof window && (n = window)
            }
            t.exports = n
        },
        function(t, e) {
            t.exports = function(t) {
                return t.webpackPolyfill || (t.deprecate = function() {}, t.paths = [], t.children || (t.children = []), Object.defineProperty(t, "loaded", {
                    enumerable: !0,
                    get: function() {
                        return t.l
                    }
                }), Object.defineProperty(t, "id", {
                    enumerable: !0,
                    get: function() {
                        return t.i
                    }
                }), t.webpackPolyfill = 1), t
            }
        },
        function(t, e, n) {
            t.exports = n(103)
        }
    ])
});