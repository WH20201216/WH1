var flow_11={
    '紫薇阁总站': {
        'aboard_flow': 4,
        'out_flow': 49,
        'sum_flow': 53,
        'lng': 114.038452,
        'lat': 22.558771
    },
    '景田北': {
        'aboard_flow': 60,
        'out_flow': 64,
        'sum_flow': 124,
        'lng': 114.040375,
        'lat': 22.556623
    },
    '监控中心': {
        'aboard_flow': 94,
        'out_flow': 125,
        'sum_flow': 219,
        'lng': 114.042084,
        'lat': 22.555065
    },
    '景新花园②': {
        'aboard_flow': 73,
        'out_flow': 50,
        'sum_flow': 123,
        'lng': 114.046501,
        'lat': 22.553616
    },
    '北大医院②': {
        'aboard_flow': 135,
        'out_flow': 52,
        'sum_flow': 187,
        'lng': 114.050568,
        'lat': 22.555355
    },
    '莲花北村①': {
        'aboard_flow': 95,
        'out_flow': 42,
        'sum_flow': 137,
        'lng': 114.055931,
        'lat': 22.559536
    },
    '彩田村①': {
        'aboard_flow': 46,
        'out_flow': 129,
        'sum_flow': 175,
        'lng': 114.060242,
        'lat': 22.559628
    },
    '公交大厦': {
        'aboard_flow': 76,
        'out_flow': 35,
        'sum_flow': 111,
        'lng': 114.063889,
        'lat': 22.558781
    },
    '莲花一村': {
        'aboard_flow': 73,
        'out_flow': 68,
        'sum_flow': 141,
        'lng': 114.07074,
        'lat': 22.555252
    },
    '笔架山公园': {
        'aboard_flow': 88,
        'out_flow': 69,
        'sum_flow': 157,
        'lng': 114.077065,
        'lat': 22.555368
    },
    '市二医院①': {
        'aboard_flow': 82,
        'out_flow': 90,
        'sum_flow': 172,
        'lng': 114.0811787,
        'lat': 22.55547
    },
    '体育馆①': {
        'aboard_flow': 110,
        'out_flow': 78,
        'sum_flow': 188,
        'lng': 114.093491,
        'lat': 22.555624
    },
    '笋岗八卦路口②': {
        'aboard_flow': 58,
        'out_flow': 50,
        'sum_flow': 108,
        'lng': 114.098488,
        'lat': 22.555706
    },
    '园岭新村': {
        'aboard_flow': 93,
        'out_flow': 128,
        'sum_flow': 221,
        'lng': 114.101784,
        'lat': 22.555765
    },
    '桂园中学': {
        'aboard_flow': 92,
        'out_flow': 62,
        'sum_flow': 154,
        'lng': 114.112679,
        'lat': 22.555929
    },
    '笋岗桥': {
        'aboard_flow': 36,
        'out_flow': 35,
        'sum_flow': 71,
        'lng': 114.117287,
        'lat': 22.556002
    },
    '深圳中学': {
        'aboard_flow': 20,
        'out_flow': 5,
        'sum_flow': 25,
        'lng': 114.120674,
        'lat': 22.553846
    },
    '晒布路': {
        'aboard_flow': 21,
        'out_flow': 1,
        'sum_flow': 22,
        'lng': 114.121056,
        'lat': 22.550022
    },
    '金城大厦②': {
        'aboard_flow': 23,
        'out_flow': 34,
        'sum_flow': 57,
        'lng': 114.122368,
        'lat': 22.542696
    },
    '阳光酒店': {
        'aboard_flow': 4,
        'out_flow': 13,
        'sum_flow': 17,
        'lng': 114.122383,
        'lat': 22.540625
    },
    '金光华广场': {
        'aboard_flow': 51,
        'out_flow': 28,
        'sum_flow': 79,
        'lng': 114.119781,
        'lat': 22.539961
    },
    '国贸': {
        'aboard_flow': 58,
        'out_flow': 217,
        'sum_flow': 275,
        'lng': 114.11869,
        'lat': 22.540609
    }
};