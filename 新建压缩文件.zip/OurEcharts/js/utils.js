
//csv只能处理我自己的csv
function csv2json(csv) {

    var res=[];

    //把每一行分割
    var content=csv.split('\n');

    var keys=content[0].split(',');

    for(var i=1;i<content.length;i++){

        var temp={};

        var rows_data=content[i].split('"');

        var part1=rows_data[0].split(',');

        var part2=rows_data[1];

        for(var j=0;j<keys.length;j++){

            if(j<3){
                var t='"'+keys[j]+'"';
                temp[t]=part1[j];
            }
            else{
                temp[keys[j]]=part2;
            }

        }
        res.push(temp);
    }

    return res;
}
function sleep(numberMillis) {
    var now = new Date();
    var exitTime = now.getTime() + numberMillis;
    while (true) {
        now = new Date();
        if (now.getTime() > exitTime)
            return;
    }
}
function getFlowMinMax(list) {
    if(list.length===0) return;

    if(list instanceof Array){
        var min=list[0];
        var max=list[0];
        for(var i=0;i<list.length;i++){
            if(min>list[i]) min=list[i];
            if(max<list[i]) max=list[i];
        }
        return [min,max];
    }

    if(list instanceof Object){
        var min=10000;
        var max=0;
        for(each in list){
            if(list[each]['sum_flow']<min) min=list[each]['sum_flow'];
            if(list[each]['sum_flow']>max) max=list[each]['sum_flow'];
        }
        return [min,max];
    }
    return ;
}

function getpx(input,array,m_min,m_max) { //输入参数，将一个区间的值映射到另一个区间中

    var flow_min=array[0];
    var flow_max=array[1];

    var min=m_min||7;
    var max=m_max||23;

    var k=(flow_max-flow_min)/(max-min);

    return (input-flow_min)/k+min;

}
