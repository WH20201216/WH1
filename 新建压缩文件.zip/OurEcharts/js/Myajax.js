function Myajax(option) {
    // url,obj,timeout,success,error,method
    //对象转化为字符串
    var str=obj2str(option.data);

    var xmlhttp;

    var timer;//设置超时结束传输时间

    if (window.XMLHttpRequest)
    {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else
    {// code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    /*解决IE缓存
    *
    * new Date().getTime()
    *encodeURIComponent("阿瑟东");//中文编码为url编码
    * */
    //发送请求
    if(option.type.toUpperCase()==="POST"){
        xmlhttp.open("POST",option.url,true);

        //必须在open和send之间
        xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");

        //类似在url里传参数，POST方法在http请求头中设置
        xmlhttp.send(str);
    }
    else if(option.type.toUpperCase()==="GET"){

        xmlhttp.open("GET",option.url+"?"+str,true);

        xmlhttp.send();
    }

    //获得响应
    xmlhttp.onreadystatechange=function() {

        if (xmlhttp.readyState===4) {

            clearInterval(timer);//接收请求后清除定时器

            //请求成功回调
            if((xmlhttp.status>=200&&xmlhttp.status<300)||xmlhttp.status===304){
                option.success(xmlhttp);
            }

            //请求失败回调
            else{
                option.error(xmlhttp);
            }
        }
    };

    //根据超时时间，中断请求
    if(option.timeout){
        timer=setInterval(function () {
            xmlhttp.abort();//中断请求
            clearInterval(timer);//清空计时器
        },option.timeout)
    }
}

function obj2str(data) {
    //url中不许出现中文，如果出现了需要转码
    data.t=new Date().getTime();
    var res=[];
    for(var key in data){
        //encodeURIComponent("阿瑟东")
        res.push(encodeURIComponent(key)+"="+encodeURIComponent(data[key]));
    }
    //以lat=132&lng=1321的字符串返回
    return res.join("&");
}