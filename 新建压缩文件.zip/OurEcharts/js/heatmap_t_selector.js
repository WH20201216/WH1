var TimeSelector={
    "timeSelector":[" <div class=\"input-card\" style='width:18rem; display: none'>\n" +
    "    <div class=\"input-item\">\n" +
    "      <span class=\"input-item-text\">开始时间:</span><input id=\"start_time\" type=\"time\" value=\"00:00\"/>\n" +
    "    </div>\n" +
    "    <div class=\"input-item\">\n" +
    "      <span class=\"input-item-text\">结束时间:</span><input id=\"end_time\" type=\"time\" value=\"23:59\"/>\n" +
    "    </div>\n" +
    "    <input id=\"heatMap_search\" type=\"button\" class=\"btn\" value=\"查询\" />\n" +
    "  </div>"],
    "appendTo":function (fatherNode) {
        /*$("#start_time").attr("value",start_time);
        $("#end_time").attr("value",end_time);*/
        $(fatherNode).append(this.timeSelector);
    },
    "show":function () {
        $(".input-card").css("display","flex");
    },
    "hide":function () {
        $(".input-card").css("display","none");
    },
    "remove":function (fatherNode) {
        $(fatherNode).append(this.timeSelector);
    },
};
