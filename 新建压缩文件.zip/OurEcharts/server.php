<?php

header("Content-Type:text/html;charset=utf-8");

echo "<h1>这是个后台页面</h1>";

try{
	$servername = "localhost";

	$port=3306;

	$username = "root";

	$password = "Ling0.0";

	$dbname="bus";

	$sql="select card_id,routes from trip where abroad_site='木棉湾地铁站①' and alight_site='红树湾南站'";
	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname, $port);

	$conn->set_charset('utf8');

    //执行sql语句
//    execute_sql($conn,$sql);

    //测试前台表单发送的数据,并写入mysql
//    get_FormWrite2Mysql($conn);

    //给前端发送数据
    send_jsonFromMysql($conn);

	// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	}

	$conn->close();
}
catch(Exception $e)
{
	echo '异常信息: ' .$e->getMessage();
}

//传入链接对象和sql,执行
function execute_sql($m_con,$m_sql){

    $conn=$m_con;

    $sql=$m_sql;

    $result=$conn->query($sql);

    print_result($result);
}

//打印结果
function print_result($m_result){
    	$result=$m_result;
    	echo "<table border='1'>
    	<tr>
    		<th>卡号</th>
    		<th>路径</th>
    	</tr>";
    	while($row = mysqli_fetch_array($result))
    	{
    		echo "<tr>";
    		echo "<td>" . $row['card_id'] . "</td>";
    		echo "<td>" . $row['routes'] . "</td>";
    		echo "</tr>";
    	}
    	echo "</table>";
}

//从前台接收数据并写入数据库中,通过$_POST方式
function get_FormWrite2Mysql($m_conn){

    $val1=$_POST['id'];

    $val2=$_POST['name'];

    $conn=$m_conn;

    try{

        $sql="INSERT INTO phptest VALUES('".$val1."','".$val2."')";

        $conn->query($sql);

    }

    catch(Exception $e)
    {
    	echo 'sql错误: ' .$e->getMessage();
    }

}

//给前台发送解析成json格式的数据
function send_jsonFromMysql($m_conn){

    $conn=$m_conn;

    $sql="select * from phptest";

    $result=$conn->query($sql);

    while($row = $result->fetch_assoc())
    {
        $array[]=$row;
    }

    //进行json编码
    $json=json_encode($array,JSON_UNESCAPED_UNICODE);

    //测试，打印json数据
//    echo $json;

    return $json;
}
?>
