﻿<!doctype html>
<html lang="en">
<head>
<title>路网分析系统</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<!-- VENDOR CSS -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/loading.css">
  <!------------------------------------------js---------------------->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/all_sites.js"></script>
<script src="js/11flow.js"></script>
<script src="js/total_flow.js"></script>
<script src="js/utils.js"></script>
<script src="js/klorofil-common.js" ></script>
<script src="js/echarts.js"></script>
<script src="js/heatmap_t_selector.js"></script>
<script src="js/loading.js"></script>
</head>

<body>
<!--<script type="text/javascript" src="https://webapi.amap.com/loca?v=1.2.0&key=ea010f7aefc7209dd1f54688cdfc23e4"></script>-->
<script src="js/loca.js"></script>
<script type="text/javascript" src='//webapi.amap.com/maps?v=1.4.14&key=ea010f7aefc7209dd1f54688cdfc23e4'></script>
<!-- UI组件库 1.0 -->
<script src="//webapi.amap.com/ui/1.0/main.js?v=1.0.11"></script>
<!--加载动画-->
<div id="loading">
   	 <div></div>
	 <div></div>
	 <span></span>
</div>
<!-- WRAPPER -->
<div id="wrapper">
  <!-- NAVBAR -->
  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="brand"> <a href="index.html"></a><span>交通路网分析系统</span></div>

    <div class="container-fluid">
      <div class="navbar-btn" style="padding: 0; padding-top: 10px;">
        <button type="button" class="btn-toggle-fullwidth  btn-toggle-mx"><img src="img/left.png" height="40px" alt=""></button>
      </div>
    </div>
  </nav>
  <!-- END NAVBAR --> 
  <!--_________________________________________________________________________________________--> 
  <!-- LEFT SIDEBAR -->
  <div id="sidebar-nav" class="sidebar">
    <div class="sidebar-scroll">
      <nav>
        <ul class="nav">
          <!-------------------------------区域浏览--------------------------->
          <li>
            <a href="javascript:" class="nav-togg"><span>区域浏览</span></a>
            <div>
              <ul>
                <li><a id="block_browser" href="javascript:"><span>分区浏览</span></a></li>
              </ul>
            </div>
          </li>
          <!---------------------------------轨迹显示----------------------分割线-->
          <li>
            <a href="javascript:" class="nav-togg"><span>轨迹显示</span></a>
            <div>
              <ul>
                <li><a id="trip_line" href="javascript:"><span>出行轨迹显示</span></a></li>
                <li><a id="line_flow" href="javascript:"><span>日公交线路站点流量示例</span></a></li>
              </ul>
            </div>
          </li>
          <!----------------------------热力图显示---------------------------分割线-->
          <li>
            <a href="javascript:" class="nav-togg"><span>热力图显示</span></a>
            <div>
              <ul>
                <li><a id="heat_change" href="javascript:"><span>热力变化</span></a></li>
                <li><a id="heat_sat" href="javascript:"><span>热力统计</span></a></li>
              </ul>
            </div>
          </li>
          <!----------------------------站点浏览---------------------------分割线-->
		  <li>
			<a href="javascript:" class="nav-togg"> <span>站点浏览</span> </a>
            <div>
              <ul>
                  <li><a a id="site_cluster" href="javascript:"><span>区域聚合</span></a></li>

                  <li><a id="site_browser" href="javascript:"><span>站点日流量统计</span></a></li>
                  <li><a id="area_distribute" href="javascript:"><span>分区分布</span></a></li>

              </ul>
            </div>
          </li>
          <!----------------------------样式更改---------------------------分割线-->
          <li>
            <a href="javascript:" class="nav-togg"> <span>地图样式更改</span> </a>
            <div>
              <ul>
                <li><a MyStyle="normal" href="javascript:" onclick="getStyle(this)"><span>标准</span></a></li> <!--normal-->
                <!--<li><a MyStyle="macaron" href="javascript:" onclick="getStyle(this)"><span>马卡龙</span></a></li>  &lt;!&ndash;macaron&ndash;&gt;-->
                <li><a MyStyle="grey" href="javascript:" onclick="getStyle(this)"><span>雅士灰</span></a></li>   <!--grey-->
                <li><a MyStyle="light" href="javascript:" onclick="getStyle(this)"><span>月光银</span></a></li>  <!--light-->
                <li><a MyStyle="whitesmoke" href="javascript:" onclick="getStyle(this)"><span>远山黛</span></a></li> <!--"amap://styles/whitesmoke"-->
                <li><a MyStyle="dark" href="javascript:" onclick="getStyle(this)"><span>幻影黑</span></a></li>  <!--dark-->
                <li><a MyStyle="fresh" href="javascript:" onclick="getStyle(this)"><span>草色青</span></a></li> <!--fresh-->
                <!--<li><a MyStyle="darkblue" href="javascript:" onclick="getStyle(this)"><span>极夜蓝</span></a></li>  &lt;!&ndash;darkblue&ndash;&gt;-->
              </ul>
            </div>
          </li>
          <!-------------------------------------------------------分割线-->
        </ul>
      </nav>
    </div>
  </div>

  <div class="main">

    <div id="container" class="main-content" style="height: 100%; width: 100%"></div>

  </div>

</div>



<script>

</script>
<!--<script src="js/main.js"></script>-->
<script>
    //创建地图
    var map = new AMap.Map('container', {
        mapStyle: 'amap://styles/dark',
        zoom: 11,
        zooms: [4,15],//设置地图级别范围
        // viewMode:'3D',  //会爆炸4
        center: [114.188586,22.646354],//[114.05096,22.541009]
        features: ['bg', 'road']  //定义显示样式
    });
    //可视化容器//在已有的地图上创建可视化Loca实例
    var locaMap = new Loca(map,{
      viewMode:'2D'
    });

    //站点图层(loca图层添加)、普通热力(插件方式添加)、蜂窝热力(loca图层添加)
    var site_layer,heatmap,hexagonHeatmap,hot_line;

    //覆盖物图层 站点聚合、线路展示
    var markers=[],circleMarkers=[];

    //UI组件
    var pathSimplifierIns,districtExplorer,pointSimplifierIns;  //巡航器
    var navg1;

    //点聚合类
    var cluster;
    //根据站点添加标记(站点聚合功能)
    addMarkBysite({
      points:sites
    });
    var count = markers.length;//count 为标记的长度

    window.onload=function () {
        setTimeout(function () {
            main();
        },500);
        TimeSelector.appendTo(".main");
        listen_ClickEve();
    };

    function main() {

        /*------------------给全局变量赋值-----------------------*/
        //在已有图层上创建Loca图层,传入 AMap.Map 实例
        site_layer = Loca.visualLayer({
            container: locaMap,
            type: 'point',
            shape: 'circle'
        });

        //统计一天的数据,就先把数据加载好
        hexagonHeatmap = Loca.visualLayer({
            eventSupport: true,
            container: locaMap,
            type: 'heatmap',
            shape: 'hexagon'  // 蜂窝六边形
        });
        load_hexagonHeatmapData();
        /*-------------------热点线路数据-----------------*/
        hot_line=Loca.visualLayer({
            eventSupport: true,
            container: locaMap,
            fitView: true,
            type: 'line',
            shape: 'line'
        });
        load_hotLineData();
        /*--------------加载热力图-----------------*/
        map.plugin(["AMap.Heatmap"], function () {
            //初始化heatmap对象
            heatmap = new AMap.Heatmap(map, {
                radius: 40, //给定半径
                opacity: [0, 0.9],
                gradient:{
                    0.2: 'blue',
                    0.4: 'rgb(117,211,248)',
                    0.6: 'rgb(0, 255, 0)',
                    0.8: '#ffea00',
                    1.0: 'red'
                }
            });
            heatmap.setDataSet({
                data: total_flow,
                max: 35,
                min: 20
            });
            heatmap.hide();
        });
        /*------------------给全局变量赋值-----------------------*/

        /*--------------点聚合控件-----------------*/
        map.plugin(["AMap.MarkerClusterer"],function () {

            cluster = new AMap.MarkerClusterer(map,null,{
              styles:[{
                size:new AMap.Size(32,32),
                offset:new AMap.Pixel(-16,-30)
              }],
              gridSize: 60,
              renderClusterMarker: function (context) {
                var factor = Math.pow(context.count / count, 1 / 18);
                var div = document.createElement('div');
                var Hue = 180 - factor * 180;
                var bgColor = 'hsla(' + Hue + ',100%,50%,0.7)';
                var fontColor = 'hsla(' + Hue + ',100%,20%,1)';
                var borderColor = 'hsla(' + Hue + ',100%,40%,1)';
                var shadowColor = 'hsla(' + Hue + ',100%,50%,1)';
                div.style.backgroundColor = bgColor;
                var size = Math.round(30 + Math.pow(context.count / count, 1 / 5) * 20);
                div.style.width = div.style.height = size + 'px';
                div.style.border = 'solid 1px ' + borderColor;
                div.style.borderRadius = size / 2 + 'px';
                div.style.boxShadow = '0 0 1px ' + shadowColor;
                div.innerHTML = context.count;
                div.style.lineHeight = size + 'px';
                div.style.color = fontColor;
                div.style.fontSize = '14px';
                div.style.textAlign = 'center';
                context.marker.setOffset(new AMap.Pixel(-size / 2, -size / 2));
                context.marker.setContent(div);
              }
            });

        });

        /*-----------------------------加载路线轨迹，分区点显示等控件----------------------*/
        AMapUI.load(['ui/misc/PathSimplifier','ui/misc/PointSimplifier', 'lib/$'], function(PathSimplifier,PointSimplifier, $) {

            if (!PathSimplifier.supportCanvas) {
                alert('当前环境不支持 Canvas！');
                return;
            }
            initPathPage(PathSimplifier);
            initMassPoint(PointSimplifier);
        });
        
        /*-----------------------------加载分区探索，地图控件等UI组件----------------------*/
        AMapUI.loadUI(['geo/DistrictExplorer','control/BasicControl'], function(DistrictExplorer,BasicControl) {

            //创建一个实例
            districtExplorer = new DistrictExplorer({
                eventSupport: true, //打开事件支持
                map: map //关联的地图实例
            });


            //监听feature的hover事件
            districtExplorer.on('featureMouseout featureMouseover', function(e, feature) {
                toggleHoverFeature(feature, e.type === 'featureMouseover',
                    e.originalEvent ? e.originalEvent.lnglat : null);
            });


            //鼠标悬浮改变样式函数
            function toggleHoverFeature(feature, isHover, position){

                if (!feature) {
                    return;
                }

                var props = feature.properties;


                //更新相关多边形的样式
                var polys = districtExplorer.findFeaturePolygonsByAdcode(props.adcode);
                for (var i = 0, len = polys.length; i < len; i++) {

                    polys[i].setOptions({
                        fillOpacity: isHover ? 0.5 : 0.2
                    });
                }
            }
            /*----------------------------加载地图控件--------------------------------*/
            //缩放控件
            map.addControl(new BasicControl.Zoom({
                theme:'dark',
                position: 'lt', //left top，左上角
                showZoomNum: true //显示zoom值
            }));

            var layerCtrl = new BasicControl.LayerSwitcher({
                position: 'rt',  //左上角
                theme: 'dark',
                //自定义覆盖图层
                overlayLayers: [
                    {
                        id: 'roadNet',
                        name: '路网图',
                        layer: new AMap.TileLayer.RoadNet()
                    },{
                        id:'buildings',
                        name:'建筑图层',
                        layer:new AMap.Buildings({
                            'zooms':[16,18],
                            'zIndex':10,
                            'heightFactor':2//2倍于默认高度，3D下有效
                        })
                    }]
            });
            map.addControl(layerCtrl);

            //实时交通控件
            map.addControl(new BasicControl.Traffic({
                position: 'lb',//left bottom, 左下角
                open:false,
                theme:'dark'
            }));

        });

    }

    function initMassPoint(PointSimplifier){
        var colors = [
            "#3366cc", "#dc3912", "#ff9900", "#109618", "#990099", "#0099c6", "#dd4477", "#66aa00",
            "#b82e2e", "#316395", "#994499", "#22aa99", "#aaaa11", "#6633cc", "#e67300", "#8b0707",
        ];

        pointSimplifierIns = new PointSimplifier({
            map: map, //所属的地图实例

            getPosition: function(item) {

                if (!item) {
                    return null;
                }

                // var LngLat=parts[3]+","+parts[4];

                //返回经纬度
                return [item['lng'],item['lat']];
            },
            getHoverTitle: function(dataItem,idx) {

                return  '站点名：'+dataItem["site"]+'  所在区名：'+dataItem["adname"];
            },
            autoSetFitView:false,
            //使用GroupStyleRender
            renderConstructor: PointSimplifier.Render.Canvas.GroupStyleRender,

            renderOptions: {
                //点的样式
                pointStyle: {
                    width: 6,
                    height: 6
                },

                //鼠标hover时的title信息
                hoverTitleStyle: {
                    position: 'top'
                },

                // drawQuadTree:true,

                //组号
                getGroupId: function(item, idx) {
                    //按名字分组
                    var name =item["adname"];

                    var id;

                    switch (name) {
                        case '宝安区':
                            id=1;break;
                        case '罗湖区':
                            id=2;break;
                        case '福田区':
                            id=3;break;
                        case '南山区':
                            id=4;break;
                        case '龙岗区':
                            id=5;break;
                        case '盐田区':
                            id=6;break;
                        case '龙华区':
                            id=7;break;
                        case '坪山区':
                            id=8;break;
                        case '光明区':
                            id=9;break;
                        default:
                            id=10;break;
                    }

                    //按纬度区间分组
                    return parseInt(id);
                },

                //分组渲染
                groupStyleOptions: function(gid) {

                    return {
                        pointStyle: {
                            fillStyle: colors[gid % colors.length]
                        }
                    };
                }
            }
        });

        $.get('data/sites1.0.json', function(json) {

            pointSimplifierIns.setData(json);

            //$('#loadingTip').remove();
        });

        pointSimplifierIns.on('pointClick pointMouseover pointMouseout', function(e, record) {
            //console.log(e.type, record);
        });

        pointSimplifierIns.hide();
    }

    function initPathPage(PathSimplifier) {

        var demo_path=[],demo_lineName;

        $.ajax({
          url:'data/11.json',
          type:'get',
          success:function (data) {

            var path1=data.path;

            demo_lineName=data.name;

            for(var i=0;i<path1.length;i++){
              demo_path.push([path1[i].lng,path1[i].lat]);
            }

          },
          error:function(msg){
            alert("出错啦");
          }
        });

        var defaultRenderOptions = {
            pathNavigatorStyle: {
                initRotateDegree: 0,
                width: 16,
                height: 16,
                autoRotate: true,
                lineJoin: 'round',
                content: 'defaultPathNavigator',
                fillStyle: '#087EC4',
                strokeStyle: '#116394', //'#eeeeee',
                lineWidth: 2,
                pathLinePassedStyle: {
                    lineWidth: 4,
                    strokeStyle: 'rgba(8, 126, 196, 1)',
                    borderWidth: 1,
                    borderStyle: '#eeeeee',
                    dirArrowStyle: {
                        stepSpace: 15,
                        strokeStyle: '#ff6b92'
                    }
                }
            }
        };

      pathSimplifierIns = new PathSimplifier({
            zIndex: 9999,

            autoSetFitView:false,

            map: map, //所属的地图实例

            getPath: function(pathData, pathIndex) {

                return pathData.path;
            },
            getHoverTitle: function(pathData, pathIndex, pointIndex) {

                if (pointIndex >= 0) {
                    //point
                    return "线路名称："+pathData.name + '，采样点索引号：' + pointIndex + '/' + pathData.path.length;
                }

                return "线路名称："+pathData.name;
            },
            //构建路径时，顺带将巡航器一起渲染了
            renderOptions: defaultRenderOptions
        });

        window.pathSimplifierIns = pathSimplifierIns;

        //数据加载不了那么块，需要设置一段时间后加载数据
        setTimeout(function () {
          pathSimplifierIns.setData([{
            name: demo_lineName,
            path: demo_path
          }]);
          navg1 = pathSimplifierIns.createPathNavigator(0, {
            loop: true,
            speed: 4000,
          });
          pathSimplifierIns.hide();
        },500);

        //initRoutesContainer(d);

        function onload() {
          pathSimplifierIns.renderLater();
        }
    }

    function initPage(dtexplorer,ad) {

        var districtExplorer=dtexplorer;

        var adcode = ad; //各个区域的区划编码

        districtExplorer.loadAreaNode(adcode, function(error, areaNode) {

            if (error) {
                console.error(error);
                return;
            }

            //绘制载入的区划节点
            renderAreaNode(districtExplorer, areaNode);
        });
    }

    function renderAreaNode(districtExplorer, areaNode) {

        //清除已有的绘制内容
        districtExplorer.clearFeaturePolygons();

        //just some colors
        var colors = ["#3366cc", "#dc3912", "#ff9900", "#109618", "#990099", "#0099c6", "#dd4477", "#66aa00","#8b0707","#994499"];

        //绘制子级区划
        districtExplorer.renderSubFeatures(areaNode, function(feature, i) {

            var fillColor = colors[i % colors.length];
            var strokeColor = colors[colors.length - 1 - i % colors.length];

            return {
                cursor: 'default',
                bubble: true,
                strokeColor: strokeColor, //线颜色
                strokeOpacity: 1, //线透明度
                strokeWeight: 1, //线宽
                fillColor: fillColor, //填充色
                fillOpacity: 0.2, //填充透明度
            };
        });

        //绘制父级区划，仅用黑色描边
        districtExplorer.renderParentFeature(areaNode, {
            cursor: 'default',
            bubble: true,
            strokeColor: 'white', //线颜色
            fillColor: null,
            strokeWeight: 1.5, //线宽
        });

        //更新地图视野以适合区划面
        map.setFitView(districtExplorer.getAllFeaturePolygons());
    }

    function getStyle(obj) {
        var style = "amap://styles/"+obj.getAttribute('Mystyle');
        map.setMapStyle(style);
    }

    function init_siteLayer(obj) {

        var layer=obj.layer;

        $.get('data/flow_total.json',function (xhr) {

            //设置加载的数据
            layer.setData(xhr, {
                type: 'json',
                lnglat: function (obj) {
                    return [obj.value.lng,obj.value.lat]
                }
            });

            setTimeout(function () {

                layer.setOptions({
                    style: {
                        radius: {
                            key: 'sum_flow',       // 映射字段
                            scale: 'linear',  // 比例尺
                            value: [2, 40], // 输出范围
                            input: [0, 130000]    // 输入范围
                        },
                        color:  '#247cd6',
                        borderWidth: 1,
                        borderColor: '#eee',
                        opacity:0.7
                    }
                });

                // 渲染
                layer.render();
                // layer.setFitView();
                // clearInterval(timer);
            },600);

        });
    }

    function load_hotLineData() {

        $.get('data/line500.json',function (res) {

            hot_line.setData(res, {
                lnglat: function (obj) {
                    var data=obj.value;
                    return [[data.ab_lng,data.ab_lat],[data.al_lng,data.al_lat]];
                },
                type:'json'
            });

            hot_line.setOptions({
                style: {
                    curveness: 0.3,
                    opacity: 0.8,
                    color: '#5695F6'
                }
            });

        });
    }

    function load_hexagonHeatmapData() {
        //加载数据
        $.ajax({
            type: "post",
            url: "data/flow_total.json",
            dataType: 'json',

            error: function (msg) {
                alert("加载失败")
            },
            success:function (data) {
                hexagonHeatmap.setData(data, {
                    lnglat: function (obj) {
                        var data=obj.value;
                        // var parts=data.lnglat.split(',');
                        // return [parseFloat(parts[0]),parseFloat(parts[1])]
                        return [data.lng,data.lat];
                    },
                    value: "sum_flow",
                });

                hexagonHeatmap.setOptions({
                    unit: 'meter',
                    style: {
                        color: ['#ecda9a', '#efc47e', '#f3ad6a', '#f7945d', '#f97b57', '#f66356', '#ee4d5a'],
                        radius: 800,
                        opacity: 0.85,
                        gap: 300
                    },
                    adcode:"440000",
                });
            }
        });
    }

    function addMarkBysite(obj) {
        var points=obj.points;
        for(var i=0;i<points.length;i++){
            markers.push(new AMap.Marker({
                position: [sites[i]['lng'],sites[i]['lat']],
                content: '<div style="background-color: hsla(180, 100%, 50%, 0.7); height: 24px; width: 24px; border: 1px solid hsl(180, 100%, 40%); border-radius: 12px; box-shadow: hsl(180, 100%, 50%) 0px 0px 1px;"></div>',
                offset: new AMap.Pixel(-15, -15)
            }));
        }
    }

    //加载线路流量统计的圆形图层
    function load_CircleMarker() {

        var minmax=getFlowMinMax(flow_11);

        for(site in flow_11){

            var center=[flow_11[site]['lng'],flow_11[site]['lat']];

            var fillcolor;

            if(flow_11[site]['aboard_flow']<flow_11[site]['out_flow'])
                fillcolor='black';
            else
                fillcolor='grey';

            var circleMarker=new AMap.CircleMarker({
                center: center,
                radius: getpx(flow_11[site]['sum_flow'],minmax),//3D视图下，CircleMarker半径不要超过64px
                strokeColor: 'white',
                strokeWeight: 2,
                strokeOpacity: 0.5,
                fillOpacity: 0.7,
                fillColor:fillcolor,
                zIndex: 10,
                bubble: true,
                cursor: 'pointer',
                clickable: true,
                extData:{
                    'site_name':site,
                    'aboard_flow':flow_11[site]['aboard_flow'],
                    'out_flow':flow_11[site]['out_flow'],
                    'sum_flow':flow_11[site]['sum_flow'],
                }
            });

            circleMarkers.push(circleMarker);


        }
        map.add(circleMarkers);
        circleMarkers.forEach(function (each,index) {

            var data=each.getExtData();

            var content = '<div id="site_show" style="width:300px;height:200px"></div>';

            var tempinfoW = new AMap.InfoWindow({
                // isCustom: true,  //使用自定义窗体
                // content: content.join("<br>"),  //传入 dom 对象，或者 html 字符串
                content: content,  //传入 dom 对象，或者 html 字符串
                offset: new AMap.Pixel(0, -20)
            });

            each.on('click',function (e) {

                tempinfoW.open(map,each.getCenter());
                //index为其id
                load_siteInfo(data,index);
                //myChart.dispose()
            });

        });

    }

    function load_siteInfo(m_data,index) {

        var temp=m_data;

        var data=[{value:temp['aboard_flow'], name:'上车人数'},
            {value:temp['out_flow'], name:'下车人数'}];

        setTimeout(function () {
            var myChart = echarts.init(document.getElementById('site_show'));
            var option = {
                title:{
                    textStyle:{
                        fontSize:20
                    },
                    x:'center',
                    text:"站点名:"+temp['site_name']+"站"
                },
                tooltip : {
                    trigger: 'item',
                    formatter: "{a} <br/>{b} : {c} ({d}%)"
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    bottom: 'bottom',
                    data: ['上车人数','下车人数']
                },
                series : [
                    {
                        name: temp['site_name'],
                        type: 'pie',
                        radius : '60%',
                        center: ['50%', '50%'],
                        data:data,
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(0, 0, 0, 0.5)'
                            }
                        }
                    }
                ]
            };
            myChart.setOption(option);
        },100);
    }

    function listen_ClickEve() {
        /*-----------------------------点击菜单事件---------------------------------------*/
        /*---------------线路流量分析---------- */
        $("#line_flow").click(function (){
            //根据是否有active类来添加或删除”
            $("#line_flow").toggleClass("active");
            if($("#line_flow").hasClass("active")){
                pathSimplifierIns.setFitView(-1);
                navg1.start();

                pathSimplifierIns.show();
                  /*-----------------加载circleMarker----------*/
                load_CircleMarker();
            }
            else{
                navg1.stop();
                pathSimplifierIns.hide();
                map.remove(circleMarkers);
                map.clearInfoWindow();
            }
        });
        /*-----------分区分布------------*/

        $("#area_distribute").click(function (){
          //根据是否有active类来添加或删除”
          $("#area_distribute").toggleClass("active");
          if($("#area_distribute").hasClass("active")){
            pointSimplifierIns.show();
          }
          else{
            pointSimplifierIns.hide();
          }
        });

        /*-------站点浏览----------*/
        $("#block_browser").click(function (){
            //根据是否有active类来添加或删除”
            $("#block_browser").toggleClass("active");
            if($("#block_browser").hasClass("active")){
                initPage(districtExplorer,440300);
            }
            else{
                //清除已有的绘制内容
                districtExplorer.clearFeaturePolygons();
            }
        });
        /*---------------出行轨迹----------*/
        $("#trip_line").click(function (){
            //根据是否有active类来添加或删除”
            $("#trip_line").toggleClass("active");
            if($("#trip_line").hasClass("active")){
                hot_line.addTo(locaMap);
                hot_line.render();
            }
            else{
                //清除已有的绘制内容
                hot_line.remove();
            }
        });
        //站点浏览
        $("#site_browser").click(function (){
            //根据是否有active类来添加或删除”
            $("#site_browser").toggleClass("active");
            if($("#site_browser").hasClass("active")){
                init_siteLayer({
                    layer:site_layer
                });
                site_layer.addTo(locaMap);
            }
            else{
                //清除已有的绘制内容
                site_layer.remove();
            }
        });
        /*---------------热力统计---------- */
        $("#heat_sat").click(function (){
            //根据是否有active类来添加或删除”
            $("#heat_sat").toggleClass("active");
            if($("#heat_sat").hasClass("active")){
                hexagonHeatmap.addTo(locaMap);
                hexagonHeatmap.render();
            }
            else{
                //清除已有的绘制内容
                hexagonHeatmap.remove();
            }
        });
        /*---------------热力变化---------- */
        $("#heat_change").click(function (){
            //根据是否有active类来添加或删除”
            $("#heat_change").toggleClass("active");
            if($("#heat_change").hasClass("active")){
                heatmap.show();
                TimeSelector.show()
            }
            else{
                //清除已有的绘制内容
                heatmap.hide();
                TimeSelector.hide();
            }
        });
        /*-------------------------站点聚类*/
        $("#site_cluster").click(function (){
            //根据是否有“active类来添加或删除”
            $("#site_cluster").toggleClass("active");
            if($("#site_cluster").hasClass("active")){
              cluster.addMarkers(markers);
            }
            else{
                //清除已有的绘制内容
              cluster.removeMarkers(markers);
            }
        });
      /*-------------动态查询热力数据---------------*/
      $("#heatMap_search").on("click",function () {
        Myloading.showLoading();

        var day="2017-04-04 ";
        var sec=":00";

        var start_time=$("#start_time").val();
        var end_time=$("#end_time").val();

        setTimeout(function () {
          $.ajax({
            type: 'post',
            url: "dmc_get_data.php",
            async: false, //取消异步请求
            cache: true,
            data:{
              'start_time':day+start_time+sec,
              'end_time':day+end_time+sec
            },
            success: function(json){
              // console.log(json);
              heatmap.setDataSet({
                data: JSON.parse(json),
                max: 60,
                min:10
              });
              Myloading.completeLoading();
            },
            error: function(data){
              alert("加载失败");
            }
          });
        },100);
      });
    }

</script>
</body>
</html>